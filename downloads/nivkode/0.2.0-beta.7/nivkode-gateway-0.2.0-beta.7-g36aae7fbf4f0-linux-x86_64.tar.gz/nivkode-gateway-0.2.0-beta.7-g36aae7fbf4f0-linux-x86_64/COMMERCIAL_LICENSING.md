# Commercial licensing

NivKode is available under AGPL-3.0-only. Commercial licences that exempt
licensees from AGPL obligations are available from the copyright holder, Jake Evans (trading as YewForge). Contact:
https://yewforge-digital.co.uk/contact.html

No pricing is published here.
