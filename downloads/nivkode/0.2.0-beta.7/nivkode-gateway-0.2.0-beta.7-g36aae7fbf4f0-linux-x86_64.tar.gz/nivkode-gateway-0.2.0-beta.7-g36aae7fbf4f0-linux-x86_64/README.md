# NivKode 0.2.0-beta.7 desktop release

This Linux x86_64 archive installs the gateway, CLI/TUI and read-only Doctor
into your home directory. The source code is not publicly available yet. Python 3.9 or newer is needed by the
installer, Doctor and the config example. Rust, Cargo and an AI provider are not needed to install. To generate replies,
configure a local model or an external AI provider (e.g. Codex, Claude, Grok)
where a compatible route is available. Beta.7 route availability and test status
are listed in `docs/beta-limitations.md`.
Provider routes were tested on earlier builds; live use on this build is
**Not yet tested**. An additional route is in development. The desktop GUI needs a browser; `nivkode open` also uses
`xdg-open`.

## Quick start

1. For a signed release, keep the archive, its `SHA256SUMS` and matching
   `SHA256SUMS.minisig` together. The owner signs `SHA256SUMS` for an approved
   release using the offline procedure in `docs/RELEASE_KEY_CEREMONY.md`:

   ```sh
   tar -xzf nivkode-gateway-0.2.0-beta.7-g36aae7fbf4f0-linux-x86_64.tar.gz
   cd nivkode-gateway-0.2.0-beta.7-g36aae7fbf4f0-linux-x86_64
   ```

2. Run the bundled installer from that directory. For a signed release it
   verifies the signature and archive checksum before installation. It installs
   under your home directory; no `sudo` is needed:

   ```sh
   bash share/nivkode/install.sh ../nivkode-gateway-0.2.0-beta.7-g36aae7fbf4f0-linux-x86_64.tar.gz ../SHA256SUMS
   export PATH="$HOME/.local/bin:$PATH"
   ```

   For an unsigned beta.7 development archive you built yourself, use this
   command instead of the signed command above:

   ```sh
   bash share/nivkode/install.sh --insecure-allow-unsigned ../nivkode-gateway-0.2.0-beta.7-g36aae7fbf4f0-linux-x86_64.tar.gz ../SHA256SUMS
   ```

   It checks the exact archive name against `SHA256SUMS` and prints an
   insecure-install warning; it does not authenticate who made the archive.
   Never use this override for a download. The `export` line only affects this
   terminal. Run it in each terminal where you use NivKode, including the
   second terminal below, or add it to `~/.profile` (or `~/.bashrc` or
   `~/.zshrc`) and open new terminals. Installing again replaces the programs in place and says what
   it changed; it never changes your config, pairing or conversations, and files
   you edited are never overwritten (a newer copy is saved with a `.new` suffix).
   Restart a running gateway afterwards. To update later, run the installer
   this install keeps, `bash ~/.local/share/nivkode/install.sh NEW-ARCHIVE.tar.gz`:
   it checks the new archive with the release key it already trusts. It refuses
   an older version over a newer one; to go back on purpose, see "Go back to an
   earlier version" in `docs/install.md` (it uses `--allow-downgrade`). The installer writes only into real folders: if
   one it uses is a symbolic link, it stops before changing anything and names
   the link. The optional systemd user service template is installed but not
   enabled.

3. Create a workspace, copy the example config, and set absolute paths for your
   workspace and private state directory. The example holds placeholder
   `/home/CHANGE-ME/...` paths; the snippet replaces them:

   ```sh
   mkdir -p "$HOME/workspace" "$HOME/.local/share/nivkode"
   cp "$HOME/.config/nivkode/gateway.example.json" "$HOME/.config/nivkode/gateway.json"
   python3 - "$HOME/.config/nivkode/gateway.json" "$HOME" <<'PY'
   import json, pathlib, sys
   path, home = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
   data = json.loads(path.read_text())
   data["listen"] = "127.0.0.1:8789"
   data["state_dir"] = str(home / ".local/share/nivkode")
   data["workspaces"] = [{"id": "workspace", "name": "Workspace", "path": str(home / "workspace")}]
   path.write_text(json.dumps(data, indent=2) + "\n")
   PY
   chmod 600 "$HOME/.config/nivkode/gateway.json"
   ```

4. Run the Doctor preflight before starting the gateway:

   ```sh
   export PATH="$HOME/.local/bin:$PATH"
   export NIVKODE_GATEWAY_CONFIG="$HOME/.config/nivkode/gateway.json"
   nivkode-doctor
   ```

   Warnings about Rust, Cargo, Java or the Android SDK only matter when
   building from source. An invalid config or a missing or unreachable pinned
   model is a failure. Doctor checks `qwen2.5-coder:7b` by default; pass
   `--model MODEL` to check another installed model. If you do not use Ollama,
   its checks fail; that does not prevent using Codex. Doctor is meant to run
   before the gateway starts: a port held by a running NivKode gateway is
   reported as such, while a port held by another program fails the check.

5. Start the gateway and leave this terminal open:

   ```sh
   nivkode-gateway serve "$HOME/.config/nivkode/gateway.json"
   ```

   The gateway is quiet while it runs normally. Run it as
   `RUST_LOG=info nivkode-gateway serve ...` to see a start-up line, or check it
   from another terminal with `curl http://127.0.0.1:8789/health`. The default
   listen port is `8789`; a second gateway on this machine needs a different
   listen address. Export the installed command path in that terminal, then
   generate a one-time pairing code (it works once and expires after ten
   minutes):

   ```sh
   export PATH="$HOME/.local/bin:$PATH"
   nivkode-gateway pair-code "$HOME/.config/nivkode/gateway.json"
   ```

6. Pair the CLI with the one-time code, then open its one-use desktop handoff:

   ```sh
   nivkode --gateway http://127.0.0.1:8789 pair YOUR_ONE_TIME_CODE
   nivkode open
   ```

   `nivkode open` needs `xdg-open` and a graphical session. It launches a
   one-use handoff URL that pairs the browser without pasting the token. If no
   browser can be started it prints that link; paste it into a browser on this
   computer within 45 seconds. The `/desktop` page by itself is not a
   pairing-code form, and reloading the desktop tab disconnects it (run
   `nivkode open` again).

7. Create a conversation in the desktop GUI and select an available provider.
   For Ollama, install the service, run `ollama pull qwen2.5-coder:7b`, then
   select that model. Its download is about 4.7 GB and can take a while on a
   slow connection. It is licensed under Apache-2.0. Smaller research-only
   models remain available, but are not the default. The CLI starts new conversations on an installed local
   route; choose `--route codex` only when you want your Codex account. The package includes the local routes `text.general` and
   `code.explain`; local turns use the configured Ollama service and the
   bundled route table. The order of models in a route is not a ranking of
   answer quality. The local adapter returns generated
   text and does not run commands or write files, but during a turn it can list
   and read text files in your configured workspace (read-only, size-limited,
   skipping names that look like keys, tokens or credentials).

8. Try the conversation list and terminal UI:

   ```sh
   nivkode list
   nivkode run "Summarize this workspace" --live --route text.general
   ```

   Press `q` to leave the TUI. The route requires an available configured
   local provider.

9. If the gateway stops during a turn, restart it with the same command; the
   desktop reconnects and shows the history. The run that was in flight is
   marked "Outcome unknown"; if it was changing files, check the workspace. The
   conversation is not blocked: send the next message, or start a new
   conversation. If Send stays disabled, continue it from a terminal with
   `nivkode resume CONVERSATION_ID "your message"` (`nivkode list` shows ids).

10. Remove the programs and service template while keeping config and data:

    ```sh
    bash share/nivkode/uninstall.sh
    ```

    If you have deleted this folder, use the installed copy instead:
    `bash ~/.local/share/nivkode/uninstall.sh`. The uninstaller stops and
    disables the user service if you enabled it, removes the files the installer
    placed, keeps any you edited or replaced, never follows a symbolic link (a
    link, or anything in a linked folder, is left in place and reported), and
    tells you what it kept. To delete configuration
    and conversations too, run it with `--remove-data`: it lists exactly what
    it will delete and deletes nothing until you type `delete`.

See `docs/install.md` for the full guide, including running the gateway as a
user service. For source builds and Android setup, see `docs/GETTING_STARTED.md`.
The gateway binds only to loopback. Remote clients need a separately configured
private route; this archive does not set one up.
