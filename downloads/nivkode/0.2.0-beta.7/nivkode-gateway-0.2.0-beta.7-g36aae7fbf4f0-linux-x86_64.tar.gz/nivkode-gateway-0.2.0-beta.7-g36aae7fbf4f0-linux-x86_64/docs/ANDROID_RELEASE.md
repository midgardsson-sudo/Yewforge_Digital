# Android release builds

Owner decision 7b2ac40b §3.3. Debug builds are unchanged: `./gradlew assembleDebug`
signs with the usual Android debug key and needs nothing below.

## Version

The app has the product version, read from `nivkode-rusty/gateway/Cargo.toml`
(`versionName`, for example `0.1.0`). The `versionCode` is derived from it and
only ever grows, so Android's own downgrade check works:

    versionCode = ((major * 100 + minor) * 100 + patch) * 1000 + stage
    stage: alpha.N -> N, beta.N -> 300 + N, rc.N -> 600 + N (N < 300), release -> 900

| Version | versionCode |
|---|---|
| 0.1.0-beta.1 | 100301 |
| 0.1.0-rc.1 | 100601 |
| 0.1.0 | 100900 |
| 1.0.0 | 10000900 |

A version the scheme cannot order (for example `0.1.0-dev`, or a minor above
99) fails the build rather than guessing. A prerelease must include its numeric
suffix: `0.1.0-alpha` is refused because it would share a code with
`0.1.0-alpha.0` (and likewise for beta and rc). `./gradlew :app:nivkodeVersionInfo`
prints both values. Debug builds now carry the same values (before, every build
was `versionCode 1`, `versionName "1.0"`); a phone with an older debug build
installed treats the new one as an upgrade.

## Release signing

A release build (`./gradlew :app:assembleRelease`, `bundleRelease`, or any task
of the release variant) runs `nivkodeCheckReleaseSigning` first and fails unless
all four settings are given, as environment variables or as Gradle properties of
the same name in `~/.gradle/gradle.properties`:

| Setting | Meaning |
|---|---|
| `NIVKODE_ANDROID_KEYSTORE` | Absolute path of the release keystore (PKCS12). It must be outside the repository. |
| `NIVKODE_ANDROID_KEYSTORE_PASSWORD` | Keystore password |
| `NIVKODE_ANDROID_KEY_ALIAS` | Key alias in the keystore |
| `NIVKODE_ANDROID_KEY_PASSWORD` | Key password |

The build also fails if the keystore is inside the repository, or if the
repository's own `gradle.properties` names any of these settings. Passing a
password with `-P` on the command line shows it to other local users in the
process list; prefer the environment or `~/.gradle/gradle.properties` (mode 600).
Run release builds with `--no-configuration-cache`: Gradle's configuration cache
(on by default in this project) records the values a build read, and although
Gradle 9 encrypts its entries (a test password was not found in plain text),
a release build has no need to keep them.

The release keystore has **not been created**. It is made offline with the
desktop release key (`docs/RELEASE_KEY_CEREMONY.md`, section 6). Because Android
accepts an update only when it is signed by the same key, losing the keystore
means publishing under a new application id.

**Needs an owner decision:** where release APKs are built. The build needs the
keystore on the machine that runs Gradle, so either the offline machine gets an
Android SDK, or a build machine is accepted as trusted with that key.
