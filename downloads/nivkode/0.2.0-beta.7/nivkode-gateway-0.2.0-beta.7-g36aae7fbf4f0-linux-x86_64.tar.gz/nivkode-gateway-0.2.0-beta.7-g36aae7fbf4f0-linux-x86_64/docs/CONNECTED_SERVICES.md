# Connected services

**Status: DRAFT — requires the owner's legal review before publication.** The
owner handles legal review. This page describes the current implementation and
planned work; it is not legal advice or a final legal statement.

NivKode connects to services using accounts and software that you provide.
You sign in yourself and remain responsible for complying with each provider's
terms, policies, and usage limits.

## Codex — live use not yet tested on this build (experimental)

Install the Codex CLI and sign in on the computer running the gateway:

```sh
codex login
```

The gateway starts the installed `codex app-server` and sends it selected
conversation turns. Gateway configuration, conversation records, and event
history are stored on your computer. Codex and the provider your Codex
account uses (OpenAI for a ChatGPT sign-in or an API key, Amazon Bedrock for a
Bedrock account) process the requests sent through your account under the
terms that apply to it. Check the provider's current data, privacy, and billing
terms before use. NivKode does not supply a provider account or pay provider
charges for you.

## Ollama local models — tested on Linux desktop; not yet run from a phone

Install Ollama, download a model, and select the Ollama provider in NivKode.
The current default Ollama endpoint is `http://127.0.0.1:11434`. The gateway
sends the selected prompt to that endpoint. With Ollama running on the same
computer, the prompt and generated response stay on that computer unless your
Ollama setup or model separately connects to another service. NivKode's local
Local models answer questions, read workspace files, propose file changes for approval, and propose supported test and build commands for review and confirmation. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made. See [Privacy and
security model](privacy-and-security-model.md).

## Claude and Anthropic — Not yet tested

Claude has a route, but live use is **Not yet tested**. The app labels this provider "in development". Do not assume a successful provider run or broader access from the route alone.

## Grok — Not yet tested

Grok is not supported in this build. Naming an external AI provider (e.g. Codex, Claude, Grok) does not make every named provider selectable here.

## Your responsibilities

You choose which provider receives each turn. You are responsible for signing
in to your own account, protecting its credentials, checking and following the
provider's terms and usage rules, and paying any charges or managing limits on
that account. Review generated content before relying on it. Provider
availability and account features can change independently of NivKode.

## Third-party services

NivKode is software that can connect to services run by other companies. Those
companies operate and control their services, accounts, policies, availability,
and billing. **YewForge is not responsible for third-party services** such as
OpenAI's Codex service or Ollama distributions, and does not control their
terms, operation, outputs, or charges. This plain-English draft wording needs
the owner's legal review before publication.
