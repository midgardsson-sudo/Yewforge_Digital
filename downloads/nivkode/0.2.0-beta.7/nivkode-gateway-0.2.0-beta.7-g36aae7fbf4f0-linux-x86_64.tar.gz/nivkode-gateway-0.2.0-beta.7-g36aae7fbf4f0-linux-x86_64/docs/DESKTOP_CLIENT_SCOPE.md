# Desktop client scope for 2 November

> **Historical record.** This page is a decision input from 3 October 2026
> and is out of date. The gateway now serves a bundled desktop client at
> `/desktop`. See [Desktop client](desktop.md) for what exists today.

**Decision input, 3 October 2026.** This checkout starts from ROUTE-2 commit
`8e1b4ff`. It contains a native Android/Jetpack Compose client and an Axum
loopback gateway. It does not contain a desktop executable client or a web UI
served by that gateway. Gateway APIs already support authenticated conversation
list/read/create, turn submission, durable event replay, and local model routing.

## Existing material

- `nivkode-rusty/android/` is the functioning client implementation track; its
  screens and API client are Android-specific.
- `DESIGN/mockups/r1/` contains three editable SVG/PNG phone concepts plus two
  HTML design studies (provider picker and artifact diff). The PNGs are
  explicitly design mockups, not screenshots of a running client.
- `~/Nivren/worktrees/nivkode-rusty-mockup-20260929/` contains the preserved
  Rusty R1 phone mockups and Android/gateway source. Its history includes the
  R2 UI work and the 30 September preservation snapshot. The branch and history
  search found no desktop application source.
- `PRODUCT/PRODUCT_CHARTER.md` says desktop/mobile continuity is a goal, Linux
  is first-class, and NivKode is not intended to be a web app as its primary
  product. The gateway currently registers JSON/SSE API routes only; it has no
  static UI handler. The repository's internal development dashboard is not a
  NivKode client.

## 2 November options

| Option | Effort to a credible 2 Nov slice | Main risks | What users get |
|---|---:|---|---|
| **A. Loopback web client in the gateway** | 2–3 engineer-weeks for a deliberately small, tested Rusty slice; more for release polish | Browser token handling, same-origin/XSS and CSP hardening, keyboard/accessibility, reconnect and uncertain outcomes, desktop packaging/update story, risk of mistaking a web surface for the desktop product | A local browser UI for approved workspace conversations: list/open/create, outcome and route provenance, send a local routed turn, reload/resume from durable history. No shell or file-write controls. |
| **B. CLI-first plus the phone app** | 3–6 engineer-days, depending on CLI gaps | Weak discoverability and long-form reading; terminal experience is not a desktop GUI; desktop review and accessibility expectations remain unmet | Better documented commands for status, list, inspect, send and resume, with the already implemented phone app for visual conversation and review. Lowest new UI risk. |
| **C. Reuse the existing mockup** | 1–2 engineer-days to adapt screens and prepare a prototype; implementation still needed | It is phone-sized static design material, has illustrative provider/model data, and does not execute requests or demonstrate error/loading/accessibility behavior | A coherent visual direction for owner review and a clickable/static desktop proposal, but no usable desktop client. |

Effort ranges assume one engineer already familiar with the gateway and do not
include owner review, app-store work, or broad cross-distribution qualification.

## Recommendation

Choose **A as a bounded Rusty launch experiment**, not as a claim that the
desktop product is complete or that web is the long-term primary surface. Keep
the 2 November bar to the workflow users need immediately: select an existing
approved workspace, browse/open/create conversations, see each run's outcome
and explicit model/route provenance, send one text turn through the gateway,
and reload a conversation from durable history. Preserve the phone app as the
mobile companion and use CLI commands for diagnosis. Exclude arbitrary terminal
access, file mutation, approvals, hosted-provider setup, and automatic retry of
unknown outcomes.

Before expanding beyond this slice, decide the desktop packaging and trust
boundary, gateway pairing/onboarding for desktop, CSP and token lifetime, and
the experience for offline/reconnect and `OUTCOME_UNKNOWN`. If these do not
fit the release window, choose B for 2 November and ship C only as design
review material.

## Spike in this branch

The current spike adds `/desktop` as a same-origin, loopback-gateway page with
conversation list/create/open, text send via `text.general` or `code.explain`,
outcome and routing provenance display, and a password-masked token field held
in page memory. In the 3 October spike, the isolated gateway served `/desktop`
on `127.0.0.1:18794`; a browser connected, resumed the saved conversation,
showed its completed outcome and route provenance, and a real `qwen2.5:1.5b`
turn through the `text.general` MOS route returned `DESK1_OK`. The gateway
state/workspace lived under `/tmp/desk-1-final`; the temporary screenshot token
was rotated afterward. The thermal wrapper log and sanitized turn record are
kept outside Git, on the test machine.

The screenshot is [`EVIDENCE/launch/desktop-spike.png`](../EVIDENCE/launch/desktop-spike.png).
It shows the connected browser view with persisted messages, run outcome, and
expandable route provenance. Both new static-surface tests pass, and the full
gateway suite passed (68 tests). This remains a decision spike: it is not
packaged or qualified for multi-user/network exposure. Browser security review,
screen-reader review, broader loading/offline/reconnect behavior, and desktop
release packaging remain open.
