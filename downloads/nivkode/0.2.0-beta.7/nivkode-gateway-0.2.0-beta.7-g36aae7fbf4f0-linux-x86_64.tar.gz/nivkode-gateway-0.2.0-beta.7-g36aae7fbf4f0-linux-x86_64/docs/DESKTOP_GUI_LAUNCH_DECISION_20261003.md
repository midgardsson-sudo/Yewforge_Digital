# NivKode 0.1 Desktop Launch Decision

> **Status on 6 October 2026.** The bundled loopback desktop client now
> exists. See [Desktop client](desktop.md). This page is kept as the decision
> record.

**Date:** 2026-10-03  
**Owner decision:** desktop GUI required for 2 November launch  
**Canonical wider decision:** Nivren planning record for 2026-10-03 covering desktop GUI, hardware support and local-model accessibility.

## Decision

NivKode 0.1 is to launch with a **desktop GUI**.

A loopback web GUI is an accepted implementation path if it is bundled with NivKode and presented as one locally installed product. The user must not need a hosted YewForge frontend for normal operation.

The existing /desktop spike is therefore an implementation starting point, not evidence that the launch should fall back to CLI-only.

## Product boundary for launch

Ship a polished bounded GUI around the already-developed gateway/MoS/conversation infrastructure.

Minimum launch experience:

- onboarding / connect;
- workspace identity;
- conversation/session list;
- create/open/resume/rename;
- text work surface;
- supported route/provider selection;
- truthful model/provider/run-state display;
- durable history reload;
- provenance/details as secondary UI;
- clear reconnect/error/unknown-outcome handling;
- keyboard/accessibility basics.

CLI remains bundled for diagnosis, automation and power use.

## Design direction

Professional, restrained, functional and beautiful.

Do not turn the desktop client into a decorative futuristic dashboard. Avoid gratuitous neon, holographic/space-age motifs, HUD clutter, glass/particle effects or fake terminal aesthetics.

The interface should look like a serious developer/productivity tool with excellent typography, spacing, hierarchy, code/output readability and subtle purposeful Nivren identity.

## Release family

The public release plan should treat these as one coherent NivKode offering:

- shippable desktop NivKode package;
- bundled local GUI;
- CLI/Doctor;
- gateway/runtime/routing;
- NivKode Android APK/mobile companion;
- versioned release notes, hashes, known limitations and tested-hardware statement.

## Hardware claims

Publish only configurations that are actually tested as **TESTED**. Separate expected/experimental and untested configurations.

Limited hardware coverage is not a reason to hide the product; it is a reason to describe the evidence honestly and expand validation as additional hardware, sponsorship and donations become available.
