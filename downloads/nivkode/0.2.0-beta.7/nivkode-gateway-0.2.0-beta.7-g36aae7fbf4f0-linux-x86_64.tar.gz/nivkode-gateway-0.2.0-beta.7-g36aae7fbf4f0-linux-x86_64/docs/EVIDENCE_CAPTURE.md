# Gateway evidence capture

The gateway provides an offline desktop capture path. It opens the gateway SQLite database read-only, selects exactly one conversation, redacts event JSON with the gateway's shared credential redactor, and writes a `nivkode.evidence.v1` JSON manifest. Absolute paths are then rewritten: a path in the conversation's workspace (the folder named by an engine switch or a provider thread) becomes `<workspace>/…`, and any other path under a home folder (`/home/<user>`, `/Users/<user>`, `/root`, also under `/var`, a WSL `/mnt/<drive>` or an MSYS `/<drive>`; Windows `C:\Users\<user>` with either separator; `~<user>/`) becomes `<home>/…`, and this machine's user name as a segment of any other absolute path becomes `<user>` (`/tmp/<user>/…`), so the manifest does not carry user names. Other absolute paths, such as `/usr/bin/git` or `/tmp/build/…`, are kept. The rewrite covers the whole manifest, IDs included. Rewritten paths count towards `redactionCount`. Event sequence numbers, IDs, kind, timestamp, and redacted payload are retained. Artifacts are represented by ID, name, media type, size, SHA-256, and provenance; artifact bytes are not copied into the manifest. The disposition makes that limitation explicit.

```sh
nivkode-gateway evidence-export <gateway.sqlite3> <conversation-id> <manifest.json>
nivkode-gateway evidence-replay <manifest.json> > replay.jsonl
```

Replay validates the schema and strictly increasing sequence order, then emits one event JSON object per line in the exact manifest order. Replay reproduces the redacted manifest: paths come back as `<workspace>/…` and `<home>/…`, not as the original folders, and there is no import back into a live conversation. The manifest also records its replay command. Keep the source database and export destination within the owner's approved evidence handling boundary; review redaction output before sharing. The redactor covers bearer credentials, common `sk-` and `ghp_` keys, PEM private keys, and sensitive JSON key names, but review remains required before external publication.

## Phone capture procedure — PENDING-OWNER

1. Owner identifies the paired device, conversation ID, current gateway build, and approved capture window. Do not include pairing codes, access tokens, private keys, or unrelated personal content.
2. On the phone, perform one bounded task and note the conversation ID and final visible event cursor. Save a screenshot and the task outcome using the owner's approved device evidence process.
3. Owner exports the same conversation using the desktop commands above. Compare the phone's observed event IDs/cursor with the manifest and replay output; record any events the phone did not display.
4. Owner reviews screenshot, manifest, replay output, artifact hashes, and redaction disposition. Add the redacted evidence and counts to the launch capture record. This procedure has not been performed by the worker; the phone half remains pending owner execution.
