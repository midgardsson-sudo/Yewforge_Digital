# Features and status

NivKode 0.2.0-beta.7 is the current Linux x86_64 review candidate. We support a local model provider and experimental hosted-provider routes. Live use on this build is **Not yet tested**. Local models can answer questions, read workspace files, propose file edits for approval, and propose supported project test or build commands for approval. Approved commands run in bubblewrap. See [beta limitations](beta-limitations.md) for remaining limits.

| Status | Meaning |
|---|---|
| Available | Built, with automated tests. It may still lack a live-provider or device check, which the last column says. |
| Experimental | Built, but we have little or no live evidence. Expect problems. |
| Preview | Built for early testing. Not part of the 0.2.0-beta.7 package, or not tried on a device. |
| Optional | Works only if you set up something else. |
| Planned | Not built. |
| Unavailable | Deliberately not usable in 0.2. |

| Feature | Status | What the evidence covers |
|---|---|---|
|  Conversations, events and restart recovery | Available | Gateway tests with isolated servers and fake providers cover restart, event replay, dropped streams and ordered recovery after a Codex exit. A gateway exit can lose events still queued in memory. An ordinary conversation read can wait for Codex while a full restore waits for it to finish. |
|  Desktop client in the browser | Available | Unit tests, scripted browser runs against a fake provider, and axe scans with no violations. No real screen reader. |
|  Reconnect and offline queue | Available | Unit tests for event ordering and de-duplication, a regression script that repeats the suites repeatedly, and a packaged-build smoke run with a fake provider that replays a queued message exactly once. |
|  Local model provider | Available | Real-model runs on one machine: `qwen2.5:3b` on an earlier build, and two turns on this branch on an earlier build (one read a workspace file). Fake-Ollama tests in each recorded gate, including the current candidate's. No real Ollama run has used the current candidate. |
|  Local routes (`text.general`, `code.explain`) | Available | Route choice, fallback and provenance tests. A route never substitutes a model that is not on its list. The order of models in a route comes from a small keyword-scored prompt set per route, run once: a weak preference, not a quality ranking. |
|  Local workspace access | Available | Local models can read workspace files. |
|  Local hands | Available | The Local model provider can propose file edits shown in approval cards; approved changes can be undone for that turn if the files have not changed since. Approved project test and build runners execute inside bubblewrap. Commands are refused without bubblewrap or outside a Git repository. The gateway and desktop tests cover approvals, stale-proposal refusal, command receipts and undo. |
|  Codex through its app-server | Experimental | Tests with fakes, and one Codex CLI version. On the 6 October candidate, a live run after a clean install passed: a file-change approval was applied and listed, and the reply appeared. A four-turn live session ran on this branch earlier that day, and a phone ran live turns on an earlier build on 30 September. |
|  Approvals and the review card | Available | Tests that every Codex session and turn pins read-only, no network and owner approval, that turning approval off is refused, that one answer per request is forwarded, and a browser run where a keyboard approval reaches the review action. These use a fake provider or a scripted app-server. One live Codex session on an earlier build approved a command and a file change (both applied) and declined one (not run). |
|  Notes on runs and artifacts | Available | Gateway tests for limits and scoping, browser accessibility scans, Android unit tests. |
|  Worker roster with explicit `UNKNOWN` | Available | Tests that read only recorded runs and fill missing fields with `UNKNOWN`. Browser scans of every state. |
|  Provider-neutral delivery states | Available | Tests that `delivered` needs a recorded provider event, and that a changed request with the same key is refused. |
|  Switching engines (SOS) | Available | Tests for confirmation, the last 20 messages, and refusal while a run is active. The desktop switches through its own dialog, checked with keyboard and axe scans. |
|  Director chat panel | Optional | Tests with a fake service. It needs a separate local service that NivKode does not include. The desktop shows its button only when the gateway reports that service as configured. |
|  Evidence export and replay | Preview | Tested on a synthetic fixture. Nothing from a phone. |
|  Android client | Preview | We build the Android app from source. This release does not include an APK, and we have not run it on a phone; earlier phone checks do not establish beta.7 compatibility. |
|  External AI provider route | **Not yet tested** | No live run through an external AI provider (e.g. Codex, Claude, Grok) is verified on this candidate. |
|  Provider capacity and usage | Unavailable | The endpoint always answers unknown. |
|  A `validated` delivery state | Unavailable | No supported provider reports validation. |
|  Automatic route choice from your prompt | Planned | The route is whatever you select. |
|  Signed release archives | Release process | For an approved release, the archive is signed with the NivKode release key; the installer refuses an archive whose signature does not verify. |
|  Automatic updates and a rollback command | Planned | There is no rollback command; going back by running the earlier package's installer was tested between the 0.1.0 release candidates. |
|  Stop a running Codex turn or local reply | Available | Gateway tests with a fake Codex and a fake Ollama, desktop Node tests, state-matrix captures, and one stop of a real local model on one machine, where Ollama ended the request and cancelled generation. |
|  Windows and macOS packages | Unavailable | Linux only. |
