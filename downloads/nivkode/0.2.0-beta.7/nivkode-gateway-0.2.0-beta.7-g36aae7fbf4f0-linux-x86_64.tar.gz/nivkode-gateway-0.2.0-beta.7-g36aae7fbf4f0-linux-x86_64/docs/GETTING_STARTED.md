# Getting started

This guide walks through the checked-in NivKode source. The current desktop
target is **Linux only**. You need Ollama and a local model for local turns.
An external AI provider (e.g. Codex, Claude, Grok) is optional. Codex is Tested, experimental; Claude has a beta.7 route but no live run is verified (**Not yet tested**), and the app labels it "in development"; Grok is Not yet tested and unsupported. To use Codex, you need your own Codex account, connected
through the Codex CLI. The Android app needs a phone-reachable private HTTPS route to the gateway.
This source guide does not install a gateway service, create the route, pair a
phone, or install an APK; [Phone setup](PHONE_SETUP.md) covers those steps.

## 1. Install prerequisites

Install Rust stable/Cargo and Ollama, then pull the local model. Ensure the
tools are on `PATH`; rustup commonly installs Cargo under `$HOME/.cargo/bin`:

```sh
export PATH="$HOME/.cargo/bin:$PATH"
ollama pull qwen2.5-coder:7b
ollama list
```

The default model download is about 4.7 GB and can take a while on a slow
connection. It is licensed under Apache-2.0. The project model notes list
`qwen2.5:3b` and `qwen2.5-coder:3b` as smaller research-only models; they are
not the default. Download sizes do not specify RAM requirements.

Codex is optional. To use it, install the Codex CLI, then sign in to your own
Codex account:

```sh
codex login
```

NivKode does not provide an account. Your use of Codex is subject to your
account provider's terms and may incur charges on your account. Codex is
experimental. Claude has a route in beta.7, but no live run is verified (**Not yet tested**); the app labels Claude "in development" (see
[Providers](providers.md#claude)).

The gateway stores its configuration, conversation state, and event history
on your computer. Ollama prompts go to the configured Ollama service (the
default endpoint is local). In a conversation that uses Codex, prompts and
related turn data are handled by the Codex app-server with your own Codex
account, and are sent to your account's provider (OpenAI for a ChatGPT
sign-in) as required to serve the request. Choose the provider deliberately
and follow its terms; you are responsible for account access and usage costs.

Choose a local workspace directory that the gateway process can read and write. The gateway config must explicitly allowlist it.

## 2. Configure the gateway

From the repository root, copy the example config and restrict its permissions:

```sh
cp nivkode-rusty/gateway/config.example.json nivkode-rusty/gateway/gateway.json
chmod 600 nivkode-rusty/gateway/gateway.json
```

Edit the private config: the example's paths are `/home/CHANGE-ME/...` placeholders, so replace every one of them. Set `state_dir` to a private absolute directory, add the workspace path to the allowlist, and keep `listen` on loopback. Do not commit `gateway.json`. The gateway creates its state directory with mode `0700` and SQLite database with mode `0600`; token hashes are stored there.

## 3. Build, pair, and serve

Build the gateway and request a one-time pairing code:

```sh
cargo build --release --manifest-path nivkode-rusty/gateway/Cargo.toml
cargo run --release --manifest-path nivkode-rusty/gateway/Cargo.toml -- pair-code nivkode-rusty/gateway/gateway.json
```

Keep the code private. In a second terminal, start the server:

```sh
cargo run --release --manifest-path nivkode-rusty/gateway/Cargo.toml -- serve nivkode-rusty/gateway/gateway.json
```

`/health` returns sanitized status. Pair with `POST /v1/pair` and `{"code":"…","device_name":"Desktop"}`; keep the returned bearer token private. Authenticated routes require `Authorization: Bearer <token>`. See the [API reference](../nivkode-rusty/docs/API.md).

## 4. Send a local text turn

Create a conversation using an allowlisted workspace ID:

```sh
auth_header='Authorization: Bearer TOKEN_GOES_HERE'
curl -sS -H "$auth_header" -H 'Content-Type: application/json' \
  -d '{"workspace_id":"nivren"}' http://127.0.0.1:PORT/v1/conversations
```

Use the returned conversation ID to submit a turn with a fresh UUID as the `Idempotency-Key` header:

```sh
curl -sS -X POST \
  -H "$auth_header" \
  -H 'Content-Type: application/json' \
  -H 'Idempotency-Key: YOUR_FRESH_UUID' \
  -d '{"text":"Give me three concise shell commands for checking the Git branch, clean working tree, and latest commit.","provider":"ollama","account_id":"local","model":"qwen2.5-coder:7b","effort":null}' \
  http://127.0.0.1:PORT/v1/conversations/YOUR_CONVERSATION_ID/turns
```

Replace `PORT` with the configured listener port and use the workspace ID from your config. Ollama must be reachable at the configured loopback endpoint and the selected model must appear in `/api/tags`. Local models answer questions, read workspace files, propose file changes for approval, and propose supported test and build commands for review and confirmation. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made. Allowlist only folders you are willing to let a local model read.

## 5. Android (optional)

Build a debug APK:

```sh
cd nivkode-rusty/android
./gradlew testDebugUnitTest assembleDebug
```

The output is `app/build/outputs/apk/debug/app-debug.apk`. The Android app expects a private HTTPS gateway URL and one-time pairing code; a loopback listener alone is not reachable from a phone. [Phone setup](PHONE_SETUP.md) gives the route (Tailscale Serve), how to check and install the APK, pairing, a first task and recovery. One phone (a Samsung S20) passed an acceptance run of a 6 October build, run by an AI agent with a scripted provider. No release APK exists yet: the Android release keystore has not been created (`docs/ANDROID_RELEASE.md`). To get a pairing code for the phone, run `nivkode-gateway pair-code CONFIG` on the gateway computer. See [known limitations](KNOWN_LIMITATIONS.md).

## Troubleshooting

Run the read-only preflight from the repository root:

```sh
python3 nivkode-rusty/tools/doctor nivkode-rusty/gateway/gateway.json
```

It reports PASS/WARN/FAIL for local tools, configuration, port, Ollama reachability/model presence, state permissions, and optional Android prerequisites. It does not display credentials or device tokens. For more recovery guidance, see [original onboarding](../nivkode-rusty/docs/ONBOARDING.md).
