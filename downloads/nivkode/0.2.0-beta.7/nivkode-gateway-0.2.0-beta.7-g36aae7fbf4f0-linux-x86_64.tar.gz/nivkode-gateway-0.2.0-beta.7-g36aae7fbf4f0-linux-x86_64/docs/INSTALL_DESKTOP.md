# Linux desktop package install

This guide moved to [Install the Linux desktop package](install.md).
