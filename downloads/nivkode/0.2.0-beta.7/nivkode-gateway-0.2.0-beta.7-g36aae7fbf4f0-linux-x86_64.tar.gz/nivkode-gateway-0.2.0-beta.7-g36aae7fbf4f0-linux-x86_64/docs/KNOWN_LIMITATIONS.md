# Known limitations

This page moved to [Beta limitations](beta-limitations.md). For NivKode 0.2,
the supported platform is Linux only; live use through an external AI provider
(e.g. Codex, Claude, Grok) on this candidate is **Not yet tested**.
No undo in this build.
