# CAP-1: explain a short code snippet locally

## Task

From the NivKode phone app, ask the local `qwen2.5:3b` route to explain a short
snippet that the user pastes into the composer. This is useful for a quick,
private explanation when away from a desktop. The snippet stays on your
private gateway and is sent to Ollama on your computer; do not paste secrets, personal
data, or code the user is not allowed to share with that machine.

The task is read-only. It must not ask NivKode to edit files, run commands,
access tools, or make a consequential decision.

## Exact phone steps

Prerequisites: the owner has installed and paired the reviewed NivKode build,
the private gateway is available, and the gateway's local model catalog includes
`qwen2.5:3b`. CAP-1 does not install or pair the app.

1. Open NivKode and start a new conversation in the approved workspace.
2. Open the provider/model picker and choose **Ollama local model provider on your computer** and
   **qwen2.5:3b**. Confirm the composer identity chip says `qwen2.5:3b` and
   `LOCAL · YOUR COMPUTER`.
3. Paste this prompt and snippet:

   ```text
   For integer inputs, explain this code in plain English. State what it
   returns, how the expression determines that, and one boundary example. Use
   only the snippet; do not propose edits or claim to have run it.

   def is_even(n):
       return n % 2 == 0
   ```

4. Send once and wait for the completed answer. Do not retry if the UI says the
   outcome is unknown; inspect the conversation first.
5. Confirm the assistant card is labelled with `qwen2.5:3b` and `LOCAL · YOUR COMPUTER`.
   Capture the prompt and answer with the provider/model identity visible.

## Expected output

The answer should say that `is_even` returns a Boolean, true when the integer
remainder after division by 2 is zero. A valid boundary example is `0` (even,
so the function returns true); negative even integers also satisfy the test.
The answer may use different wording; it must not claim file access, tool use,
or code execution. Provenance is visible in the app's assistant identity and
composer chip as `qwen2.5:3b` / `LOCAL · YOUR COMPUTER`.

## Evidence to save

Save a bounded result under `EVIDENCE/launch/device-capability/`:

- A screenshot showing the prompt, completed answer, and local provider/model
  identity. Redact unrelated conversations and personal content.
- Conversation ID, run ID, and the ordered event IDs (or event sequence IDs if
  that is what the gateway exposes) for dispatch, acceptance, and completion.
- Gateway-reported provider/account/model, completion status, and timestamps.
- The model catalog digest if available from the approved read-only gateway
  evidence path; otherwise record `not captured` rather than infer it.
- A short pass/fail result against the checklist below. Do not include the
  bearer token, pairing code, or full unrelated conversation history.

Keep the phone interaction under five minutes. Evidence collation may happen
afterward. A screenshot alone does not prove which model answered; reconcile
it with the gateway's event/run record.

### Operator run and event lookup

The owner taps **Power + Volume Down** on the SM-G981B after the answer settles,
then checks the screenshot in Gallery. It must show the task and local identity;
take a second screenshot if the answer needs scrolling. The owner tells the
operator the session start and end times. The app does not expose a reliable
run/event ID control here, so the operator locates the exact run in the
gateway's SQLite database; the owner does not use a terminal.

On the gateway computer, set the UTC millisecond bounds from the observed
session and use the state directory in the running gateway config. This query
opens the database read-only and saves IDs, event kinds, provider/account,
model and status. Keep raw output in a private local staging directory until
reviewed. Run it from the checkout root and replace the time placeholders:

```sh
START_MS=SESSION_START_UTC_MILLISECONDS
END_MS=SESSION_END_UTC_MILLISECONDS
umask 077
REVIEW_ROOT="$HOME/.local/share/nivkode/onboarding-review"
install -d -m 700 "$REVIEW_ROOT"
REVIEW_DIR="$(mktemp -d "$REVIEW_ROOT/session-XXXXXXXX")"
python3 - "$HOME/.config/nivkode/gateway.json" "$START_MS" "$END_MS" > "$REVIEW_DIR/cap1-run-events.txt" <<'PY'
import json, pathlib, sqlite3, sys
config = json.loads(pathlib.Path(sys.argv[1]).read_text())
db = pathlib.Path(config['state_dir']) / 'nivkode.sqlite3'
con = sqlite3.connect(db.as_uri() + '?mode=ro', uri=True)
runs = con.execute('''SELECT r.id,r.conversation_id,r.provider,r.account_id,
 r.model,r.status FROM conversation_runs r JOIN conversation_messages m
 ON m.run_id=r.id AND m.role='user' WHERE r.created_at BETWEEN ? AND ?
 AND instr(m.text,'def is_even(n):')>0 ORDER BY r.created_at''',
 (int(sys.argv[2]),int(sys.argv[3]))).fetchall()
for run_id,conversation_id,provider,account,model,status in runs:
    print('RUN',run_id,'CONVERSATION',conversation_id,provider,account,model,status)
    for seq,event_id,kind in con.execute('''SELECT seq,event_id,kind FROM
      conversation_events WHERE conversation_id=? AND run_id=? ORDER BY seq''',
      (conversation_id,run_id)):
        print('EVENT',seq,event_id,kind)
PY
```

Exactly one run must match the phone task and session window; if none or
several match, narrow the observed window and compare the prompt privately.
Review `cap1-run-events.txt` before including it in the evidence index.
Record `not captured` for any unavailable field. In the same terminal, so
`REVIEW_DIR` still points to the private staging directory, from the checkout root,
export that conversation (replace the ID from the read-only lookup):

```sh
DB="$(python3 -c 'import json,pathlib,sys; print(pathlib.Path(json.load(open(sys.argv[1]))["state_dir"])/"nivkode.sqlite3")' "$HOME/.config/nivkode/gateway.json")"
CONVERSATION_ID=ID_FROM_LOOKUP
nivkode-gateway evidence-export "$DB" "$CONVERSATION_ID" "$REVIEW_DIR/cap1-manifest.json"
```

See [Gateway evidence capture](EVIDENCE_CAPTURE.md). The operator and reviewer
compare its ordered event IDs and completion state with the read-only lookup,
then review the screenshot, lookup and manifest for secrets, unrelated content
and paths before placing redacted copies in `EVIDENCE/launch/onboarding/`.
Keep raw files in the private staging directory; do not commit them. Create
an index under `EVIDENCE/launch/onboarding/` with the session time, reviewed
APK/gateway hashes,
redacted screenshot and manifest paths, conversation/run/event IDs, and a
`PASS`, `FAIL` or `OPEN` result with reasons. A missing event, uncertain match,
or incomplete export stays `OPEN`; do not infer success from a screenshot.

## OWNER-RUN (under five minutes)

Start only when the prerequisites above are already met. The task itself is
one short prompt and one answer; app install, pairing, gateway repair, or model
download are outside this timed run.

- [ ] Select Ollama local model provider on your computer / `qwen2.5:3b`; local identity is visible.
- [ ] Send the exact prompt and snippet once.
- [ ] Receive a completed answer that explains the Boolean result and gives a
      correct boundary example.
- [ ] Assistant identity shows `qwen2.5:3b` / `LOCAL · YOUR COMPUTER`.
- [ ] Save a redacted screenshot and reconcile the conversation/run/event IDs
      with the gateway record.
- [ ] No tool, file edit, command, external provider, or repeat submission was
      used.

**PASS** only if every applicable item is checked and the run/event record
confirms the local provider/model and completion. **FAIL** if the answer is
missing or materially wrong, provenance is absent/mismatched, the gateway
reports failure/unknown, or the turn used a different provider. Stop and
record the failure; do not retry an unknown outcome until inspected.

Current limitation: the read-only CAP-1 preparation check found no installed
`co.yewforge.nivren.nivkode` package on the reachable SM-G981B. The phone run
therefore remains pending owner installation/pairing through the owner's
approved process; this task makes no claim of on-device acceptance.
