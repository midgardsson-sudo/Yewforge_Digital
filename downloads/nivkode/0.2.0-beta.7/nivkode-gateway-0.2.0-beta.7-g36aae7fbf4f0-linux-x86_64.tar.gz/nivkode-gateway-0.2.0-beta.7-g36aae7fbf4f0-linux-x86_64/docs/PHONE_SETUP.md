# Set up the Android app with your computer

This page is the whole path a new user follows: set up the gateway on a Linux
computer, give the phone a private HTTPS route to it, install the Android app,
pair it, run a first task and recover when something goes wrong. Each step
names the command or the screen you will see.

The Android app is a preview that you build from source (see
[feature summary](FEATURES.md)). Earlier agent-run phone checks are not beta.7
acceptance; no phone run has used this build and Jake has not accepted phone
support for it.

<!-- REQUIRES-ADMIN-PROXY -->
> **This guide applies only to a build that includes the admin-socket
> change.** Check that your gateway and APK come from the same reviewed build. That
> change serves device administration only on an owner-only
> socket file, refuses it on the gateway's network port, and makes Doctor ask
> Tailscale Serve where it forwards. Earlier builds (r6f and before) serve
> device administration on the network port and their Doctor does not check
> Serve, so the security statements, Doctor results and lost-phone steps on
> this page are wrong for them. Do not follow this guide with such a build.
> The sections marked **Requires the admin-socket change** depend on it most.

## Not available yet: steps that wait for the release

These steps need actions only the project owner can take. Until they happen,
use the "today" path given in each section.

| Waits for | What it blocks | Today |
|---|---|---|
| Jake's approval to publish a signed release archive | Downloading a desktop archive and checking its signature (section 1) | Build from source for review; do not use an unsigned archive as a public download. |
| The Android release keystore (`docs/ANDROID_RELEASE.md`), the owner's decision on where release APKs are built, and a published APK | Downloading a release APK and checking its checksum and signing certificate (section 4) | Build a debug APK from source (section 4) |
| **Needs owner decision:** whether the release page publishes the APK's SHA-256 inside the signed `SHA256SUMS`, and the APK signing certificate's SHA-256 fingerprint | What section 4 checks the APK against | Check the APK you built yourself (section 4) |

## What you need

- A Linux x86_64 computer. It runs the gateway, the AI engines and your
  workspace. The phone only talks to it.
- Ollama with a local model, for local turns: install it from
  [ollama.com](https://ollama.com), then run `ollama pull qwen2.5:3b`. An
  external AI provider (e.g. Codex, Claude, Grok) is optional; Codex is Tested, experimental; Claude has a beta.7 route but no live run is verified (**Not yet tested**), and the app labels it "in development"; Grok is Not yet tested
  with your own Codex account ([Providers](providers.md)).
- A Tailscale account, with Tailscale on the computer and on the phone, both
  signed in to the same tailnet (section 3 explains why).
- An Android phone with Android 10 or newer. The app's `minSdk` is 29
  (`nivkode-rusty/android/app/build.gradle.kts`).
- To build the app today: JDK 17 and the Android SDK, with `ANDROID_HOME` set.
  Doctor reports both as "Android Java toolchain" and "Android SDK".

## 1. Install the gateway on the computer

**With a published archive** (not available yet), follow
[Install the Linux desktop package](install.md), sections 1 and 2, to check
and install it.

**Today (no published archive)**, build an unsigned archive yourself and
install it. You need a source checkout with no uncommitted changes (the build
refuses to package changed files), Rust with Cargo, and Python 3. From the top
of the checkout:

```sh
scripts/release/build-desktop.sh
cd dist
ARCHIVE="$(awk '{print $2}' SHA256SUMS)"
sha256sum -c SHA256SUMS
tar -xzf "$ARCHIVE"
cd "${ARCHIVE%.tar.gz}"
bash share/nivkode/install.sh --insecure-allow-unsigned "../$ARCHIVE" ../SHA256SUMS
export PATH="$HOME/.local/bin:$PATH"
```

The build writes the archive and a `SHA256SUMS` that lists only that archive
to `dist/`, and says the build is unsigned. `ARCHIVE` picks up the archive's
name from `SHA256SUMS`, so older archives in `dist/` do not matter.
`sha256sum` must print `OK`. The installer is run from inside the unpacked
archive, and warns that nothing proves who made it. Use
`--insecure-allow-unsigned` only for an archive you built yourself, never for
a download ([install.md](install.md#2-install-for-your-user)). The `export`
line works only in this terminal; install.md section 2 says how to keep it.

Then, either way, follow [install.md](install.md) sections 3 and 4. They
write `~/.config/nivkode/gateway.json` with `"listen": "127.0.0.1:18789"`, run
`nivkode-doctor` and start the gateway:

```sh
nivkode-gateway serve "$HOME/.config/nivkode/gateway.json"
```

Leave it running, or run it as a user service ([install.md](install.md#optional-run-the-gateway-as-a-user-service)).
Check it on the computer:

```sh
curl http://127.0.0.1:18789/health
```

It answers with `"status":"ok"`.

## 2. Keep the gateway on this computer only

The gateway listens on loopback (`127.0.0.1`) and nowhere else. It refuses to
start with any other `listen` address: "gateway must bind to loopback; expose it
only through the configured private HTTPS proxy"
(`nivkode-rusty/gateway/src/main.rs`). Do not try to change that. The phone
reaches the gateway only through the route in section 3.

## 3. Give the phone a private HTTPS route

### What the app accepts

- **HTTPS only.** The pairing screen enables **Pair device** only for a URL that
  starts with `https://`, and the app refuses plain HTTP traffic
  (`MainScreen.kt` `PairForm`; `DataRepository.kt` `pair`;
  `android:usesCleartextTraffic="false"` in `AndroidManifest.xml`).
- **A certificate the phone already trusts.** The app has no network security
  configuration of its own, so it trusts only the certificate authorities that
  come with Android. A self-signed certificate, or a certificate authority you
  install on the phone yourself, does not work.

### Supported setup: Tailscale Serve

[Tailscale Serve](https://tailscale.com/kb/1312/serve) gives the gateway an
HTTPS address that only devices on your tailnet can reach, with a certificate
from Let's Encrypt that Android trusts. It passes requests on to the gateway's
loopback port, so the gateway itself never listens on a network.

NivKode does not include Tailscale or set it up. The steps below use
Tailscale's own commands.

1. **Turn on HTTPS for your tailnet.** In the Tailscale admin console, turn on
   MagicDNS, then, under DNS → HTTPS Certificates, choose **Enable HTTPS**
   ([Tailscale: Enabling HTTPS](https://tailscale.com/kb/1153/enabling-https)).
   Read what that page says first: every certificate is recorded in the public
   Certificate Transparency logs, including your computer's full tailnet name.
   Do not turn it on if a machine name says something you would not publish.
   Rename the machine first.
2. **Serve the gateway on the tailnet.** On the computer, with the gateway's
   port from your config:

   ```sh
   tailscale serve --bg --https=8443 http://127.0.0.1:18789
   tailscale serve status
   ```

   The status shows `https://<computer>.<tailnet>.ts.net:8443 (tailnet only)`
   with `/ proxy http://127.0.0.1:18789`. If it does not say
   `(tailnet only)`, Tailscale Funnel is publishing the gateway on the
   internet: turn it off with `tailscale funnel --https=8443 off` and check
   the status again. If Tailscale says you lack
   permission, run the command with `sudo`, or let your user manage Tailscale
   once with `sudo tailscale set --operator=$USER`. You can use another HTTPS
   port if 8443 is taken. Serve the gateway at `/`, not under a path.
3. **Prepare the phone.** On the phone, open Play Store, search for
   **Tailscale**, tap **Install** (or **Update** if already installed), then
   open it. Tap **Get Started**, approve Android's VPN connection prompt, then
   choose **Sign in with Google** or **Sign in with other** for the account on
   the computer's tailnet. Complete sign-in. In Tailscale, check
   that it says **Connected** and shows the computer on the same tailnet.
   Update Tailscale to the latest version from Play Store before continuing.
   If sign-in, the tailnet, or VPN connection
   differs, stop and fix that before pairing.
4. **Check it from the phone.** Copy the exact tailnet-only URL printed by
   `tailscale serve status` in step 2 to the phone. In its browser, open that
   URL with `/health` appended:
   `https://<computer>.<tailnet>.ts.net:8443/health`. You should see
   `"status":"ok"` and no certificate warning. If MagicDNS does not resolve,
   update Tailscale, reconnect its VPN, and try again. If it still fails, stop;
   do not substitute a public URL, IP address, or unverified DNS workaround.

The URL you will type into the app is
`https://<computer>.<tailnet>.ts.net:8443`, with no path after the port.

### Why this setup is safe enough, and where it is not

<!-- REQUIRES-ADMIN-PROXY -->
**Requires the admin-socket change** (see the top of this page).

- **Two locks, not one.** Only devices on your tailnet can reach the URL. Even
  then, every request needs a device token, except `/health`, pairing, the
  desktop page files and the one-use desktop handoff claim. A device gets a token only with a one-time pairing code
  issued on the computer. The code works once and for ten minutes
  ([privacy and security model](privacy-and-security-model.md#pairing)).
- **Everyone on your tailnet can reach the gateway.** That includes devices
  shared into your tailnet and other members of a shared tailnet. They still
  need a pairing code, but keep the tailnet to your own devices, or restrict
  the port with Tailscale access controls.
- **The gateway sees every proxied request as coming from this computer.**
  Tailscale Serve connects to the gateway from `127.0.0.1`, so the gateway
  cannot tell a tailnet request from a local one by its address. That is why
  the device admin routes (`/v1/admin/devices`) are not on the gateway's port
  at all. There, every `/v1/admin/` request is answered
  `403 admin_routes_use_the_local_admin_socket`, with or without
  `admin_token`, so Serve cannot reach them. They are only on the admin
  socket, a socket file: `admin.sock` in the state directory, or, when that
  path is too long for a socket, a file in a private `nivkode` folder of
  `$XDG_RUNTIME_DIR`. `nivkode-gateway admin-socket` prints where it is. The
  gateway creates it only while
  `admin_token` is set, the state directory and the socket are open to your
  user only, and the gateway also checks that the program on the other end
  runs as the same user as the gateway (see "A lost or replaced phone" below).
  You can keep `admin_token` set while the route is on.
- **Serve adds identity headers.** It can tell the gateway who sent a request
  (for example `Tailscale-User-Login`). NivKode never grants anything because
  of them. Their presence only takes access away: the admin socket refuses a
  request that carries them or other forwarding headers, and so does the
  one-use desktop handoff claim.
- **Doctor checks this route** (only with the admin-socket change, which
  also changes Doctor). Doctor's "Tailscale
  route" line asks `tailscale serve status --json` whether Serve forwards to
  the gateway's port, and fails if Tailscale Funnel publishes it on the
  internet. When it cannot ask Tailscale, or when Serve forwards to the
  gateway's port at an address it does not recognise as this computer (such
  as `0.0.0.0` or a host name other than `localhost`), it warns that it cannot
  tell. It cannot see other proxies. In an earlier build, Doctor never asks Tailscale
  and reports "none configured" even with Serve on, so its `PASS` there says
  nothing about Funnel. Either way, `tailscale serve status` (section 3, step
  2) is the check to trust.

### Other setups

Any other route must meet the same conditions. It must be reachable only by
your own devices, use HTTPS with a certificate from a public certificate
authority, and pass requests to the gateway's loopback port. NivKode documents
no other setup step by step, and no other setup has been checked with the
current app.

The 6 October phone runs used a different route on the same tailnet: a small
TLS front with the computer's own Tailscale certificate, which forwarded bytes
to the loopback gateway. That route did not use Serve. No phone run has used
the Serve route above with the current app yet. An earlier build used it on
30 September.

### What not to do

- **Do not publish the gateway to the internet.** Do not use
  `tailscale funnel`, a public tunnel service or router port forwarding. Any of
  these would put the pairing endpoint on the internet.
- **Do not use plain `http://`, a self-signed certificate, or a certificate
  authority installed on the phone.** The app refuses the first two. Trusting
  your own certificate authority weakens every app on the phone, and this app
  ignores it anyway.
- **Do not change `listen` to `0.0.0.0` or a network address.** The gateway
  refuses to start.
- **Do not run `tailscale serve reset` or `tailscale serve --https=443 off`**
  if the computer serves anything else. Each one removes every route on the
  computer or on that port. To remove only NivKode's route, see "Remove the
  phone route" below.
- **Do not share a pairing code**, or a screenshot that shows one.

## 4. Get the Android app

### From a release: not available yet

No release APK exists (see the table at the top). When one is published,
download the APK with the release's `SHA256SUMS` and `SHA256SUMS.minisig`
into one folder on the computer, then check all three before you install:

```sh
minisign -Vm SHA256SUMS -P RELEASE-PUBLIC-KEY
sha256sum -c --ignore-missing SHA256SUMS
apksigner verify --print-certs NivKode-APK-FILE.apk
```

- `minisign` must say the signature is good. The release public key is the one
  in [install.md](install.md#1-verify-and-unpack).
- `sha256sum` must print `OK` for the APK.
- `apksigner` comes with the Android SDK build tools. The
  `Signer #1 certificate SHA-256 digest` must equal the fingerprint the release
  page publishes. **Needs owner decision:** the release does not publish this
  fingerprint yet, and the APK is not yet listed in `SHA256SUMS`.

If any check fails, delete the file and do not install it.

### Today: build a debug app from source

You need JDK 17 and the Android SDK (see "What you need"). If Doctor's
"Android Java toolchain" line is not `PASS`, point `JAVA_HOME` at a JDK 17
first, for example `export JAVA_HOME=/usr/lib/jvm/java-17-openjdk` (the folder
name differs between Linux distributions). `adb` and `apksigner` come with the
Android SDK but are not on your `PATH` by itself. The first line below adds
them, using the newest build tools you have installed.

From the top of your source checkout:

```sh
export PATH="$ANDROID_HOME/platform-tools:$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -n 1):$PATH"
cd nivkode-rusty/android
./gradlew testDebugUnitTest assembleDebug
sha256sum app/build/outputs/apk/debug/app-debug.apk
apksigner verify --print-certs app/build/outputs/apk/debug/app-debug.apk
```

Stay in `nivkode-rusty/android` for section 5. The app is
`app/build/outputs/apk/debug/app-debug.apk` there. It is signed with
the Android debug key of the computer that built it, and the certificate
`apksigner` shows includes `CN=Android Debug`. It proves only that you built it. Keep
the SHA-256 so you can tell later which build is on the phone.

## 5. Install the app on the phone

The app's package name is `co.yewforge.nivren.nivkode`, and it appears as
**NivKode**.

### Over USB (the way the agent phone runs installed it)

1. On the phone, turn on Developer options. Then, in Developer options, turn
   on **USB debugging**.
2. Before connecting the cable, on the computer run `adb start-server`, then
   display its ADB key fingerprint:

   ```sh
   set -o pipefail
   cut -d' ' -f1 "$HOME/.android/adbkey.pub" | base64 -d | md5sum
   ```

   Stop if the key file is missing or the command fails. Connect the phone.
   When it asks **Allow USB debugging?**, compare the complete MD5 value
   shown there with the computer's value (Android may separate hex pairs with
   colons). Allow only an exact match. Leave **Always allow from this
   computer** unticked.
3. On the computer, in the terminal from section 4 (it is in
   `nivkode-rusty/android`, with `adb` on its `PATH`):

   ```sh
   adb devices
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

   `adb devices` must list the phone as `device`. If it says `unauthorized`,
   answer the prompt on the phone first. `adb install` prints `Success`.

   To install a newer build later and keep the app's data, run
   `adb install -r app/build/outputs/apk/debug/app-debug.apk` from the same
   folder. When a release APK exists (section 4), you will install the file you
   checked there, by its path, instead.
4. When you have finished, you can turn USB debugging off again.

### By opening the file on the phone

Copy the APK whose checks in section 4 passed to the phone and open it in the
Files app or your browser.
Android asks before it installs an app from outside an app store:

- It says the app you opened the file with is not allowed to install unknown
  apps, and offers **Settings**. Allow **Install unknown apps** for that one
  app only, then go back.
- It asks whether you want to install NivKode. Choose **Install**.
- If Play Protect offers **Scan app**, let it scan. Install only an APK whose
  checks in section 4 passed. Stop if Play Protect blocks it.

The exact wording differs between Android versions and phone makers. No
NivKode phone run has used this path yet; the runs so far installed over USB.
When the app is installed, turn **Install unknown apps** off again for that
app.

### Switching between a debug build and a release build

Android installs an update only when it is signed by the same key. A release
APK cannot replace a debug build, and the reverse is also true. Uninstall the
app first, then pair again (section 6). Your conversations are kept on the
computer, not on the phone.

## 6. Pair the phone

1. Open NivKode. Step 1 of 4 says "Your AI workspace, on your terms."
   Tap **Get started**.
2. Step 2 of 4 is **Connect your gateway**. On the computer, issue a
   one-time code in a private, non-recorded terminal. Pause screen and
   terminal capture before running this command:

   ```sh
   nivkode-gateway pair-code "$HOME/.config/nivkode/gateway.json"
   ```

   Note the issue time and enter the code and the checked tailnet URL directly
   on the phone. Clear the terminal view before resuming capture. Keep the code out of chat, transcripts,
   screenshots and screen recordings. Record only `issued`, `used` or
   `expired`, never the value. If ten minutes pass or the code fails, issue a
   new code and hand it over the same way.

3. On the phone, type the **Private HTTPS gateway URL**
   (`https://<computer>.<tailnet>.ts.net:8443`) and the **One-time pairing
   code**. Then tap **Pair device**.
4. The app says "Gateway connected securely." Tap **Continue**.
5. Step 3 of 4, **Connected services**, explains that you sign in to each
   provider yourself. Tap **Continue**. Then, on step 4 of 4, tap **Finish**.

The code works once and expires after ten minutes. Issuing a new code cancels
an unused earlier one. The phone stores its device token encrypted with an
Android Keystore key. The token expires after 90 days unless
`device_token_ttl_seconds` in the gateway config says otherwise.

## 7. First task

This is a read-only example task. It runs on the
local model on your computer.

1. Tap **New conversation**. A new conversation starts on a local model when
   one is installed. Otherwise the app asks you to **Choose an engine**.
2. Tap **Choose provider** next to the composer and pick **Ollama local model provider on your
   computer** and `qwen2.5:3b`. The chip next to the composer shows that the model is on this
   computer.
3. Paste this, then tap **Send** once:

   ```text
   For integer inputs, explain this code in plain English. State what it
   returns, how the expression determines that, and one boundary example. Use
   only the snippet; do not propose edits or claim to have run it.

   def is_even(n):
       return n % 2 == 0
   ```

4. The answer says that `is_even` returns true when the number divides by 2
   with no remainder, and false otherwise. A good boundary example is `0`.
   The reply card names the model that answered.

The local model can only write a reply, and it may read text files in the
workspace you allowlisted. Local models can propose file changes for approval and supported test or build commands for review and confirmation. Codex is an
explicit choice: a conversation goes to an external AI provider (e.g. Codex, Claude, Grok) only when you
pick that provider for it.

## Recovery

| What you see | What to do |
|---|---|
| **Offline · reconnecting**, or "Offline. Reconnecting to your computer." | On the computer, check the gateway with `curl http://127.0.0.1:18789/health` and the route with `tailscale serve status`. On the phone, check that Tailscale is on. The app reconnects by itself. **Sync now** retries at once. |
| The gateway stopped during a turn | Start it again with the same command. The run that was in flight shows its outcome as unknown, because NivKode cannot tell whether the engine finished. Do not just send it again. Read the conversation first. After a Codex run, check the workspace. Then send your next message. ([install.md](install.md#if-the-gateway-stops-during-a-turn)) |
| The app was closed or the phone restarted | Open NivKode. It stays paired and reconnects. |
| The code was not accepted, or it expired | Issue a new code with `nivkode-gateway pair-code`, then pair again. |
| "This phone is no longer paired with your computer." | Its token expired or was revoked, or the gateway's state was reset. The app has already forgotten the token and shows the pairing screen. Issue a new code and pair again. |
| The `/health` page does not open on the phone | Check that Tailscale is on in the phone's Tailscale app and signed in to the same tailnet as the computer. Check that the address matches `tailscale serve status` and that the gateway is running. |
| You need to pair with a different gateway address | The app has no "unpair" control. In Android Settings → Apps → NivKode → Storage, clear its storage, then pair from the start. Conversations stay on the computer. This path has not been walked in a NivKode phone run. |

For more, see [Troubleshooting](troubleshooting.md).

### A lost or replaced phone

<!-- REQUIRES-ADMIN-PROXY -->
**Requires the admin-socket change** (see the top of this page).

Revoke the phone's device token on the computer. 0.2.0-beta.7 has no CLI command for
this; it uses the admin routes
([privacy and security model](privacy-and-security-model.md#listing-and-revoking-devices)).
The phone route can stay on: the admin routes are never reachable through it.
Run every step on the computer, as the user that runs the gateway. The steps
never show the admin token on screen, and never put it in your shell history,
in an environment variable or on a command line that other users could see
with `ps`.

1. **Give the gateway an admin token, once.** This adds a random 43-character
   `admin_token` to the config if it has none, leaves an existing one alone,
   and keeps the file readable by you only (the gateway refuses an
   `admin_token` that other users can read):

   ```sh
   python3 - "$HOME/.config/nivkode/gateway.json" <<'PY'
   import json, os, pathlib, secrets, sys
   path = pathlib.Path(sys.argv[1])
   data = json.loads(path.read_text())
   if not data.get("admin_token"):
       data["admin_token"] = secrets.token_urlsafe(32)
       path.write_text(json.dumps(data, indent=2) + "\n")
   os.chmod(path, 0o600)
   PY
   ```

2. **Restart the gateway** so it reads the token. Wait until no turn is
   running, because a restart marks a running turn's outcome as unknown. If
   you started the gateway in a terminal, press Ctrl+C there and run the same
   `nivkode-gateway serve "$HOME/.config/nivkode/gateway.json"` command
   again. If it runs as a user service, run
   `systemctl --user restart nivkode-gateway`. The gateway now creates its
   admin socket: `admin.sock` in its state directory, or, when that path is
   too long for a socket, a file in a private `nivkode` folder of
   `$XDG_RUNTIME_DIR`. Do not type the path yourself:
   `nivkode-gateway admin-socket` prints it while the gateway runs. Check that
   it is there:

   ```sh
   ls -l "$(nivkode-gateway admin-socket "$HOME/.config/nivkode/gateway.json")"
   ```

   The line starts with `srw-------`: a socket that only you can open.

3. **Add a small helper to this terminal.** Each time, it asks
   `nivkode-gateway admin-socket` where the socket is, reads the token from the
   config and passes the token to `curl` through a pipe:

   ```sh
   nivkode_admin() {
     local config="$HOME/.config/nivkode/gateway.json" socket
     socket="$(nivkode-gateway admin-socket "$config")" || return
     python3 -c 'import json, sys; print("Authorization: Bearer " + json.load(open(sys.argv[1]))["admin_token"])' "$config" |
       curl --silent --show-error --unix-socket "$socket" -H @- "$@"
   }
   ```

   The helper lasts until you close this terminal.
4. **List the paired devices:**

   ```sh
   nivkode_admin http://localhost/v1/admin/devices | python3 -m json.tool
   ```

   Each device has a `deviceId`. Phones are named `Android device`, and the
   terminal client `nivkode-cli` unless you gave it another name. `createdAt` is when the device paired and
   `lastSeen` when it last used the gateway, as Unix times: `date -d @NUMBER`
   shows one as a date. A device with a `revokedAt` time is already revoked.
   If you cannot tell which phone is the lost one, revoke every
   `Android device` and pair the phones you still have again (section 6).
5. **Revoke the lost phone,** with its `deviceId` in place of `DEVICE_ID`:

   ```sh
   nivkode_admin -X DELETE http://localhost/v1/admin/devices/DEVICE_ID
   ```

   It prints nothing when it worked. List the devices again: the phone now has
   a `revokedAt` time.

| What you see | What to do |
|---|---|
| `nivkode-gateway admin-socket` says `admin_token is not set` | The config has no admin token. Do step 1, then step 2. |
| `nivkode-gateway admin-socket` says `no gateway is running with this config` | The gateway is not running, or it started before the config had `admin_token`. Restart the gateway (step 2). For its other messages, see [Troubleshooting](troubleshooting.md). |
| `curl: (7) Failed to connect …` (the list command then also prints `Expecting value`) | Nothing answers on the admin socket: the gateway is not running, or it started before the config had `admin_token`. Restart the gateway (step 2). |
| `{"error":"unauthorized"}` | The running gateway has another token than the config. Restart it (step 2). |
| `{"error":"admin_socket_peer_is_not_the_gateway_user"}` | Run the command as the user that runs the gateway. |
| `{"error":"device_not_found_or_revoked"}` | The `deviceId` is wrong, or that device is already revoked. List the devices again. |
| The gateway does not start, and names the admin socket | See [Troubleshooting](troubleshooting.md). |

You can leave `admin_token` set afterwards.

The revoked phone forgets its token and shows the pairing screen the next time
it reaches the gateway.

To lock out every paired device at once, remove the phone route. Then no
device can reach the gateway from outside the computer.

## Remove the phone route

```sh
tailscale serve --https=8443 off
tailscale serve status
```

This removes only the route on port 8443. The gateway keeps running on
loopback, and the desktop and terminal on the computer keep working. To
uninstall the gateway, see [install.md](install.md#uninstall). To remove the
app, uninstall NivKode on the phone.
