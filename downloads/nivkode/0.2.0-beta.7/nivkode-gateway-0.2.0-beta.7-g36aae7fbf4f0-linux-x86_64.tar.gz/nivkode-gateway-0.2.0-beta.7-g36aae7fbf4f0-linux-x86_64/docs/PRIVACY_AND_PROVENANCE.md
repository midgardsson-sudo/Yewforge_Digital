# Privacy and provenance

This page covers where each run came from and how to export a record of it.
For the wider picture (what stays local, credentials, pairing and approvals),
read [Privacy and security model](privacy-and-security-model.md).

## Local model behavior

The gateway and its SQLite state run on the host you configure. The gateway
listens on loopback and only works inside the workspaces you list in its
config.

Local Ollama turns send prompts and workspace context to Ollama on that host.
Local models answer questions, read workspace files, propose file changes for approval, and propose supported test and build commands for review and confirmation. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made. The local-only switch
refuses external AI providers (e.g. Codex, Claude, Grok) at the gateway.

Keep the gateway config, state directory, one-time pairing codes and device
tokens private. The gateway stores device-token hashes in its private state
database. The Android client encrypts the returned device token with an Android
Keystore key. Configure any phone-accessible private HTTPS route separately;
NivKode does not create one.

## External models

When you choose the Codex provider, the gateway talks to the installed Codex
app-server. Whether a request leaves the machine depends on the provider and
account you choose. The local Ollama path is the local model option. A provider
option in the list is not proof that a particular account is configured or that
a request stayed local. Check the selected provider and model for each turn.

## Provenance: where each run came from

Each run records what NivKode observed about it. The desktop shows this under
**Details** in the latest-run panel, and the API returns it with the run.

| Field | What it tells you |
|---|---|
| Provider and account | The selected provider, currently local Ollama or external Codex. A local account is called `local` in API output and shown as "Your computer". |
| Model | The model NivKode recorded for that run. A restored Codex turn can show no model when Codex did not report one. NivKode does not guess. |
| Status | The run status the gateway stored. |
| Route, selection and decision ID | For a local route: the route name, and whether it was chosen by the route table (`mos`) or by you (`explicit`). |
| Specialist and model digest | Which entry of the route table answered, and the digest Ollama reported for that model. |
| Fallback reason | Why a later model on the route answered, such as a missing first choice. |

Artifacts carry their own origin. Today every artifact is recorded as coming
from the Codex app-server, together with its name, type, size and SHA-256.

The worker roster adds a source label, `nivkode_gateway_run_events`. It means
the row was built from the gateway's own saved runs and events. It does not
mean a worker was observed running.

These fields describe where data came from. They do not say that an answer is
correct or complete.

## Evidence exports and redaction

The offline evidence exporter opens SQLite read-only, selects one
conversation, redacts event payloads, and writes a JSON manifest of ordered
events and artifact metadata, including hashes and origin. A second redaction
pass runs over the whole manifest before it is written. Notes are not
included.

The checked-in EVID-1 evidence used a synthetic fixture, found four
redactions, and verified replay order and digest. It did not use a live service
or a phone. Review an export before you share it, because redaction cannot
promise to find every sensitive value.
