# NivKode 0.2.0-beta.7 release draft

**Draft only.** This Linux x86_64 beta.7 candidate has no Android package.

We support a local model provider or an external AI provider. Local models can
answer questions, read workspace files, propose file edits and propose
supported project test and build commands for approval. In beta.7, general
questions to the local model now get a plain answer instead of an edit proposal.
This applies to questions; file questions and actions still go through the
proposal and approval flow. The command-line client command
`nivkode approve <conversation> <request>` accepts one pending local request
by its id. It accepts only; it does not prompt or decline requests.

The Local only switch is enforced by the gateway for external-provider turns
and second opinions. Enabling it stops active external-provider runs. NivKode
will not apply a file proposal if its files changed since the proposal was
made. After you stop a reply, NivKode shows it as interrupted and no longer
shows it as running.

No release date or platform other than Linux is claimed here. A person must
approve any release.

## Install

If a release is approved and signed, download the Linux desktop archive and
its signed `SHA256SUMS` file. Follow [Install the Linux desktop package](install.md),
which includes the release public key and signature checks. Run
`nivkode-doctor` to check the setup. Run `nivkode-doctor --report` to create a
redacted local report; read it and remove private information before sharing.

## Report a problem

The **Report a problem** screen lets you review a redacted report before
opening your email app or copying it for GitHub. Nothing is sent until you
choose to send it. For support, contact
[support@yewforge-digital.co.uk](mailto:support@yewforge-digital.co.uk).

Read [Beta limitations](beta-limitations.md) for the full list. NivKode source
and binaries are offered under the GNU Affero General Public License, version
3 only. See `LICENSE` and `THIRD_PARTY_NOTICES.md`; third-party components keep
their own licences.
