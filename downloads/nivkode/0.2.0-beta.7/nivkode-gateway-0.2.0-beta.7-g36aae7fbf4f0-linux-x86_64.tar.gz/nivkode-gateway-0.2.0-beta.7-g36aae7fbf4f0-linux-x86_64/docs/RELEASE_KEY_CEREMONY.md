# Release key ceremony (offline)

This runbook creates the NivKode release signing key, pins its public half, and
signs releases with it. **No agent and no build creates this key.** The owner
runs it by hand. The private key is never committed, never copied to an online
machine, and never pasted into a chat, an issue or a log.

Two keys are covered:

- the **desktop release key** (Ed25519, minisign format) that signs
  `SHA256SUMS` and is pinned in `scripts/release/install.sh`;
- the **Android release keystore**, which signs APKs; see the last section.

## What you need

- An offline machine: a laptop with networking disabled (or a live USB system
  booted with no network). It must not be the build machine.
- Two removable drives for the encrypted key copies, stored in two different
  places, plus a written note of the passphrase kept apart from both.
- On the offline machine: Python 3.9 or newer and a copy of
  `scripts/release/release-signing.py` from a reviewed commit (check its SHA-256
  against the commit on another machine), plus `gpg` or LUKS for encryption.

## 1. Generate (offline)

```sh
umask 077
mkdir -p /dev/shm/nivkode-key && cd /dev/shm/nivkode-key   # memory only
python3 release-signing.py keygen --secret-key release.key --public-key release.pub
```

`keygen` refuses to write inside a git work tree and never overwrites a file.
It prints the key id and the public key line. The secret key file is
unencrypted (minisign's `-W` layout), so encrypt it at once and wipe the plain
copy:

```sh
gpg --symmetric --cipher-algo AES256 --output release.key.gpg release.key
shred -u release.key
```

## 2. Store

- Copy `release.key.gpg` to both removable drives. Label them with the key id
  and the date only.
- Keep the passphrase on paper, apart from the drives.
- Write down the key id and the public key line (`release.pub`, second line) on
  paper as well; you will compare them when pinning.
- Never store the key or the passphrase in the repository, a password manager
  that syncs to the build machine, cloud storage, or chat.

## 3. Pin the public key (online, reviewed change)

On the normal machine, add the public key line, and only that line, to
`PINNED_RELEASE_KEYS` in `scripts/release/install.sh`:

```sh
PINNED_RELEASE_KEYS=(
  'RWSTLdUN4lyCUF75ANlaa4La4nvfZC8wvtuEeYLx0AxjR2sibpTjQmee' # NivKode release key, owner-confirmed 2026-10-24
)
```

Commit it on its own, with the key id in the message, and have it reviewed
(Tier A or Codex): this line decides what every future install trusts. Then:

- update `scripts/release/test_release_signing.py`
  to parse this key and reject a file signed by a throwaway key;
- publish the same public key line and key id on the official release page and
  in the repository README, so users can check a first install themselves;
- compare all three copies with your paper note.

## 4. Signing a release

1. On the build machine, build the release unsigned from a reviewed, clean
   commit: `bash scripts/release/build-desktop.sh`. Note the SHA-256 of
   `dist/SHA256SUMS`.
2. Copy only `dist/SHA256SUMS` to the offline machine (a fresh USB stick).
3. On the offline machine, check its SHA-256 matches, read it (one line per
   archive, nothing else), and sign it without writing the key to disk:

   ```sh
   gpg --decrypt release.key.gpg | python3 release-signing.py sign --key - \
     --trusted-comment "nivkode-release archive=nivkode-gateway-VERSION-gSHA-linux-x86_64.tar.gz version=VERSION" SHA256SUMS
   ```

   The archive name and version in the comment must be exactly the archive's
   file name and the version in `share/nivkode/VERSION`; the installer refuses
   anything else.
   Sign each version once. Another build of the same version is not a
   downgrade, so a second signed build of a version could later be served in
   place of the first; bump the version (for example `-beta.N`) for every
   signed archive.
4. Copy `SHA256SUMS.minisig` back next to the archive, and check it on the build
   machine against the pinned key:

   ```sh
   python3 scripts/release/release-signing.py verify --pinned scripts/release/install.sh dist/SHA256SUMS
   ```

5. Install it in a disposable home with the packaged installer, and refuse to
   publish if any step fails. Publishing remains a separate owner approval.

`NIVKODE_RELEASE=1 NIVKODE_RELEASE_SIGNING_KEY=- build-desktop.sh` does build
and signing in one step, but only on a machine trusted with the key; the offline
route above is the default.

## 5. Rotation and compromise

- **Planned rotation:** create the new key as above. Ship one release signed by
  the **old** key whose installer pins **both** keys. Installs that updated to it
  then trust the new key; sign later releases with the new key, and remove the
  old key from the list in a later reviewed change.
- **Suspected compromise:** stop signing. Remove the key from
  `PINNED_RELEASE_KEYS`, create a new key, and announce on the official page that
  archives signed by the old key id must not be installed. There is no
  revocation channel: installs that still pin the old key keep trusting it until
  the user installs a release with the new installer, which they must check by
  hand against the newly published key, as for a first install.
- **Lost key:** as for compromise, minus the warning. Users re-anchor by hand.

## 6. Android release keystore

The Android build reads the keystore from outside the repository
(`docs/ANDROID_RELEASE.md`). Create it on the same offline machine:

```sh
keytool -genkeypair -keystore nivkode-release.p12 -storetype PKCS12 -alias nivkode-release \
  -keyalg EC -groupname secp256r1 -validity 10000 -dname "CN=NivKode release"
```

Store it encrypted like the desktop key. Android requires every update of an
installed app to be signed by the same key, so a lost keystore means a new
application id. Record its SHA-256 certificate fingerprint
(`keytool -list -v -keystore nivkode-release.p12`) with the desktop key note.
