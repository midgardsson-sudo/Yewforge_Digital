# NivKode 0.1.0 release notes

> **Candidate r7. Not published.** A person must approve any release.
> These notes describe candidate r7 at `release/candidate-r7-20261024`, commit
> `9132029b`. Its automated gate passed on that tree with fake providers. It
> has not been installed on a phone. Check every statement against
> [Public claims and evidence](PUBLIC_CLAIMS.md) before publication.

NivKode 0.1.0 is an unpublished review candidate for a Linux desktop package
and an Android preview built from source. It is designed to start with a local
model when one is installed. The default model is
`qwen2.5-coder:7b` (Apache-2.0); its download is about 4.7 GB, downloaded once
for local use. An external AI provider is also a choice for a conversation.
This build offers experimental Codex; Claude and Grok are not available.

0.1.0 is a beta. Each release archive is signed; verify it before installing.

## Platforms

- The review package targets Linux x86_64 and installs into your home
  directory.
- The Android app is a preview that you build from source. It is not included
  in the public download.

## Choose an engine and work

- New conversations use the installed local default when one is available.
  Otherwise, choose an engine. Reopened conversations may keep their existing
  engine.
- **Switch engine** opens the plain engine chooser. Switching is confirmed by
  choosing the engine; no message is sent just by opening the chooser.
- Start an empty workspace with **Start a conversation**.
- When an approval is waiting, **Jump to decision** takes you to it. Approval
  requests name the action, including the command or file changes to review.
- If the gateway stops during a run, its outcome is shown as **Outcome
  unknown**. NivKode cannot tell whether the provider finished, and does not
  retry the run automatically. Check your workspace before continuing.

## Known limitations

- The Android app is not in the public download; it must be built from source.
- The Android model list loads when the app connects. A model list may be
  stale until the next connection.
- Using an external engine requires signing in to its provider.
- The candidate gate used fake providers. No live-provider run or phone
  installation has been made from this candidate.

## Install and verify

Follow [Install the Linux desktop package](install.md) and the
[release signing guide](RELEASE_SIGNING.md). Before installing, verify the
release signature with the pinned NivKode key whose key ID is
`50825CE20DD52D93`, then check the archive against the signed checksum file.
The checksum detects changes to the archive; the signature on the checksum
verifies its origin. Verify it before installing.

## Licence

NivKode is licensed under **AGPL-3.0-only**. The default local model is
licensed separately under Apache-2.0.
