# NivKode 0.2.0-beta.4

**Provisional Linux x86_64 candidate; unsigned and unpublished.**

## Beta.3

- Local fixes remain off by default and are more reliable in preview. They refuse edits that would quietly cut a file by more than half.
- Fixed how the model chooses which file to edit.

## Beta.4

- CLI approvals are bound to both requestId and conversationId; local responses require conversationId.
- General questions use the plain-text route.
- Launch-truth documentation reflects the accepted fixes in this candidate.

The Linux x86_64 archive for this beta is built unsigned for review. Signing and
publication remain owner-controlled. The Android app remains a preview built from
source; no Android package was built.

## Changes

- The install guide now shows the release public key and how to check the
  signature before unpacking an archive.
- The Android app has a **Report a problem** screen. It shows a redacted local
  report and lets you review it before opening your email app or copying a
  report for GitHub. Nothing is sent until you choose to send it yourself.
- `nivkode-doctor --report` prints a redacted report on your computer. You can
  review it before sharing it.
- When pasted code is going to a local model, NivKode says in plain language
  that local models may misread it and suggests describing the change in words
  or naming the file.
- `nivkode open` returns without waiting for the browser to finish starting.
  If the browser cannot be opened, it reports the problem and gives you the
  one-use link.
- Pairing output labels the one-time code so it is clear which value to enter.
- The desktop footer in that candidate read **No telemetry · Signed builds**. This is historical 0.1.1 copy and is not a current 0.2 claim.

## Support

For help, contact [support@yewforge-digital.co.uk](mailto:support@yewforge-digital.co.uk).
Remove private information from reports before sharing them.
