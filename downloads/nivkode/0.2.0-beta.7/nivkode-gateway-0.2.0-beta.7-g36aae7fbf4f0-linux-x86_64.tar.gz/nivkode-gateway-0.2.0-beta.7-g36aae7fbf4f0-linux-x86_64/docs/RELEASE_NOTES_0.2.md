# NivKode 0.2.0-beta.7 release notes

**Candidate for Linux x86_64.**

We run on Linux and store conversation history on your computer. Choose a
local or external provider. When you choose an external
provider, your conversation is also sent to that provider.

## Review changes before they happen

- With a local model, we can answer questions and read workspace files.
- We can propose file edits and supported project test and build commands.
  We show changes and commands for review; commands run inside bubblewrap
  after approval.
- On desktop, turn on “Local fixes (preview)” in Settings to enable local
  model fixes; it is off by default.
- Local model file changes need a Git workspace. Undo restores the saved
  state only while the files still match the state recorded when the changes
  were applied.
- In the command-line client, `nivkode approve <conversation> <request>`
  accepts one pending local request by its id. It accepts only; it does not
  prompt or decline requests.
- General questions to the local model now get a plain answer instead of an
  edit proposal. This applies to questions; file questions and actions still
  go through the proposal and approval flow.

Live use on this build has not yet been tested for local or hosted providers.
One hosted-provider route is labelled "in development". These notes describe
the release archive will be signed by the pinned NivKode key after owner approval. Signing is not publication approval.

## Keep use on this computer

The Local only switch is enforced by the gateway. While it is on, requests to
external AI providers and external second opinions are refused. Turning it on
also stops active external-provider runs.

Stop signals a local reply right away and records the request afterwards, so
Stop stays prompt even when saving to history is slow.

After you stop a reply, NivKode shows it as interrupted and no longer shows it
as running.

These notes describe the beta.7 candidate; they do not announce publication.
