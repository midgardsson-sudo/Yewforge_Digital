# Release signing

Owner decision (directive 7b2ac40b §3, 10 October 2026): public beta and release
release archives are signed after owner approval, and the installer verifies them against a pinned public key
before it installs anything. Each release archive is signed with the NivKode
release key, and the installer refuses an archive whose signature doesn't
verify. The release public key is pinned in
`scripts/release/install.sh`; its secret half remains offline under the owner’s
control, following [RELEASE_KEY_CEREMONY.md](RELEASE_KEY_CEREMONY.md). The
Verify an archive's signed checksum file against the pinned release key before
installing, as described in [the install guide](install.md).

## What is signed

The release build writes `SHA256SUMS` (the archive's SHA-256) and signs it as
`SHA256SUMS.minisig`:

- **Algorithm:** Ed25519 over the BLAKE2b-512 hash of `SHA256SUMS`, in the
  [minisign](https://jedisct1.github.io/minisign/) file format (public key
  `base64("Ed" + key id + key)`, signature `base64("ED" + key id + signature)`,
  then a trusted comment and a global signature over signature + comment).
- **Trusted comment:** `nivkode-release archive=<archive file name> version=<version>`.
  It is signed, so the version the installer compares is the version that was
  signed.
- **Tool:** `scripts/release/release-signing.py` (`keygen`, `sign`, `verify`,
  `public-key`), Python standard library only. Its Ed25519 is the RFC 8032
  reference algorithm, tested against the RFC 8032 vectors and against OpenSSL
  in both directions. It is not constant time, so the real key is only ever used
  on an offline machine.
- **Tested with the `minisign` program** (0.12, the Arch Linux package), on
  10 October 2026, in both directions. `minisign -V` (with or without `-H`)
  verifies this tool's signatures. The installer and `release-signing.py verify`
  accept signatures made by `minisign -S`. Unencrypted (`-W`) secret keys work in
  either program. The installer refuses minisign's legacy (`-l`) signatures, and
  refuses minisign's default trusted comment. To sign with `minisign`, pass the
  NivKode comment with `-t`.

## What the installer checks

`scripts/release/install.sh` carries its own verifier (it never runs code from
the archive it is checking) and the list `PINNED_RELEASE_KEYS`. Before anything
is written it requires that:

1. `SHA256SUMS.minisig` sits next to `SHA256SUMS` and is signed by a pinned key;
2. the signature matches `SHA256SUMS` and the trusted comment is unchanged;
3. the trusted comment names a NivKode archive and a version;
4. the signed `SHA256SUMS` gives that archive this archive's digest (so a
   browser-renamed download still matches, by content);
5. after unpacking, the package folder is that archive's, and its `VERSION` file
   agrees with the signed version;
6. the version is not older than the installed one (semantic-version order;
   `--allow-downgrade` overrides this, see `docs/install.md`).

The install keeps this installer at `~/.local/share/nivkode/install.sh`.
Updates run with it, so a new archive is checked against keys that came with the
already-verified version, not against anything in the new download. A first
install has no such anchor: the installer that checks the archive came inside
it. `docs/install.md` therefore asks users to check the signature themselves
first, against the public key published on the release page.

`--insecure-allow-unsigned` (developers, their own builds) installs an unsigned
archive with a loud warning and records `signature=none` in `installed-release`.
It never accepts an archive whose signature by a pinned key fails.

## How the build signs

| Setting | Effect |
|---|---|
| none | Unsigned development build; the installer refuses it without the override. |
| `NIVKODE_RELEASE_SIGNING_KEY=FILE` or `-` | Signs `SHA256SUMS` (with `-`, the key is read from standard input into memory), then verifies the signature against the keys pinned in `scripts/release/install.sh`; the build fails if they do not match. |
| `NIVKODE_RELEASE=1` | A release: fails before building unless `NIVKODE_RELEASE_SIGNING_KEY` is set and a key is pinned. Refuses a test key. |
| `NIVKODE_TEST_SIGNING_KEY=FILE` | Test builds only, for acceptance harnesses: signs with a throwaway key and pins its public half in the **packaged** installer (never in the repository). Prints a warning; the trusted comment carries `channel=test`. Never publish such an archive. |

The release key normally stays offline, so a release is built unsigned on the
build machine and `SHA256SUMS` is signed on the offline machine
([RELEASE_KEY_CEREMONY.md](RELEASE_KEY_CEREMONY.md), "Signing a release").

## Not covered

- No update channel: nothing fetches or announces updates. "Update" means
  running the kept installer on an archive you downloaded.
- No revocation list. A compromised key is handled by rotation (runbook), which
  installed copies learn only through a release signed by a key they trust.
- The 0.1.0 release candidates and the 9 October candidate are unsigned and
  their installers do not check signatures or versions.
- Android APKs are signed by the Android release keystore, a separate key
  (`docs/ANDROID_RELEASE.md`).
