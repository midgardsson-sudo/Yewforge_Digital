# ROUTE-2 gateway routing integration

> **Terms.** A *route* is a named task type such as `text.general`. *MOS* is the
> Mixture-of-Specialists component in this repository's `mos/` folder. It
> exports the bundled route table. The order of models in that table comes from
> a small check (eight prompts per route, scored by keywords, run once). It is a
> weak preference, not a ranking of answer quality, so make no quality claim
> from it. For a plain-language description, see [Concepts](concepts.md#local-routes).
> In API output the local account is called `local`, and the desktop shows it as
> "Your computer".

## Decision

The gateway accepts an optional MOS capability route on a conversation turn.
When `model` is supplied, that explicit selection remains authoritative for
backwards compatibility. Otherwise, the bundled MOS binding table maps the
route to a local Ollama model. An explicit `route_bindings` path can override
it. The table is exported ahead of request handling
by MOS (`python3 -m mos.export_bindings`); Python is never launched per turn.
Each exported route contains its first-choice model, the local fallback models
in order, model specialist IDs, and policy/registry digests. The gateway validates the table at startup and fails closed if a
requested route is absent or not local.

Regenerate the table from checked-in measured inputs before deploying a new
router policy:

```sh
python3 -m mos.export_bindings \
  --measurements evidence/mos/measurements_20261001T151706Z.json \
  --output mos/registry/bindings.json
```

The release bundles the checked-in table, so a fresh installation needs no
MOS configuration. After regenerating it, build a new release to update the
bundled defaults, or set `route_bindings` to an alternate exported table path.

## Development/candidate profile (Quark on qwen2.5:3b)

The owner decision of 10 Oct 2026 (nivren `7b2ac40b`, section 4; `37c59d15`,
section 3) makes `qwen2.5:3b` the development/candidate Quark model. It is
**not** the public default. The public table above is unchanged: `text.general`
still starts with `qwen2.5:1.5b`.

The candidate table is exported from the same measured inputs plus a route
profile:

```sh
python3 -m mos.export_bindings \
  --measurements evidence/mos/measurements_20261001T151706Z.json \
  --profile mos/registry/profiles/candidate.json \
  --output mos/registry/bindings.candidate.json
```

A profile only moves an owner-pinned, router-vetted model to the front of a
route. In `candidate`, `text.general` starts with `qwen2.5:3b`, and the
`qwen2.5:1.5b` baseline is its first fallback. Every other route and model
keeps the router's order. The pinned route gets its own decision id, which
records the profile digest. To run a gateway on it, set
`"route_profile": "candidate"` in the gateway config. You cannot combine it
with `route_bindings`.

The profile carries no authority. The export and the gateway both refuse a
profile that:

- claims to be the public default;
- turns the keyword escalation net on (this gateway has none);
- asks for anything but strict tool-call JSON;
- drops its baseline;
- has a field they do not know.

High-risk or uncertain requests are not trusted to the model under any
profile. A local turn keeps its two read-only workspace tools, and approval
boundaries stay where they are. Local tool calls are strict JSON. A call
whose arguments are not exactly the declared object (extra fields, JSON
inside a string, wrong types) is refused before it runs, with no repair.

Runs on a profile record `routeProfile` in their `run/dispatching` routing
provenance, and `/v1/routes` names the profile. At startup the gateway logs
a warning that names the active profile and its pins.

## Availability and fallback

The gateway checks local Ollama's catalog before dispatch and records the
model's catalog digest. A missing primary may use only the first available,
router-vetted local fallback, with the missing-primary reason recorded. If no
vetted fallback is available, the run fails as unavailable and emits route
provenance with no chosen model. Transport errors and timeouts remain errors;
they do not trigger substitutions. This preserves ROUTE-1's distinction
between an unavailable model (no silent substitute) and an explicit fallback
attempt (a separately identified fallback model from the route's list).

Every `run/dispatching` conversation event includes route, specialist, chosen
model, SHA-256 digest, policy and registry digests, and fallback reason. An
explicit client model records `selection=explicit` and is not rerouted.

## Boundaries and validation

The integration is limited to conversation turns using local `ollama` /
`local` bindings. It does not alter Codex routing, provider catalogs, the live
gateway, gateway data, or device state. Tests use temporary SQLite state,
loopback listeners, and fake provider/catalog responses. The desktop CAP-1
simulation is repeated against a separate temporary gateway configuration and
state directory; the inference is executed only through the pinned GPU guard.
