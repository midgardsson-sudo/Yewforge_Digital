# SEC-2 systemd startup check

The worker sandbox has no user systemd bus (`systemd-run --user` returns
`Failed to connect to user scope bus via local transport: No data available`).
The gateway process therefore has not been observed running under the sandboxed
unit in this environment. You can run this bounded check in a session
with a user systemd manager. It uses a temporary HOME, state directory, and
loopback port; it does not touch the normal gateway unit or device.

Build the binary, then run from the repository root:

```bash
mkdir -p "$HOME/.cache"
tmp_home="$(mktemp -d "$HOME/.cache/nivkode-sec2.XXXXXX")"
mkdir -p "$tmp_home/.local/share/nivkode" "$tmp_home/workspace"
cat > "$tmp_home/gateway.json" <<EOF
{"listen":"127.0.0.1:18789","state_dir":"$tmp_home/.local/share/nivkode","codex_bin":"/definitely/missing/codex","workspaces":[{"id":"check","name":"Check","path":"$tmp_home/workspace"}]}
EOF
systemd-run --user --unit=nivkode-sec2-check --collect \
  --property=Type=simple --property=NoNewPrivileges=yes \
  --property=PrivateTmp=yes --property=ProtectSystem=strict \
  --property="ReadWritePaths=$tmp_home/.local/share/nivkode" \
  --property=ProtectHome=read-only \
  --property="RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6" \
  --property=LockPersonality=yes --property=MemoryDenyWriteExecute=yes \
  --setenv=HOME="$tmp_home" \
  "$PWD/nivkode-rusty/gateway/target/debug/nivkode-gateway" serve "$tmp_home/gateway.json"
curl --fail http://127.0.0.1:18789/health
systemctl --user stop nivkode-sec2-check
rm -rf "$tmp_home"
```

Pass means the transient user unit becomes active and `/health` returns HTTP
200; the expected Codex-unavailable warning is harmless for this startup-only
check. If it fails, save `systemctl --user status nivkode-sec2-check` and its
journal before changing sandbox directives. The packaged template uses the
same sandbox properties and its conventional writable data directory.
