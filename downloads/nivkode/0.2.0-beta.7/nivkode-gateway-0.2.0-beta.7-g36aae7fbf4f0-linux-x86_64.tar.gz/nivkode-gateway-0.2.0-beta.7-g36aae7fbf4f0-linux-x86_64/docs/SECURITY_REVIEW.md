# SEC-1 Gateway Security Review

**Reviewed:** 2026-10-03  
**Scope:** NivKode RC `62f4acd` gateway, release installer and unit template. Read-only review plus isolated Rust tests. No live gateway, device, or external scanning was used.

> **Scope note.** This review covers the gateway as of 3 October. The bundled
> desktop client and its one-use handoff (added that afternoon), the local-model
> workspace tools (4 October), notes and the Director proxy (6 October) came
> after it. A second review on 6 October covers the gateway source of that day;
> its record is `EVIDENCE/security-review-20261006.md`. The Director proxy and
> the note edit and delete routes were added after its starting point. See
> [Privacy and security model](privacy-and-security-model.md#where-the-protections-stop).

## Threat model and controls observed

The gateway serves workspace content and can start or interrupt Codex work, so a stolen device token or exposed listener grants substantial local authority. The shipped server rejects non-loopback bind addresses at startup; the default is `127.0.0.1:8789`. Public or tailnet reachability therefore depends on an explicitly configured private HTTPS proxy. The app has no CORS middleware and uses bearer tokens rather than cookies. Pairing and `/health` are intentionally unauthenticated; data and command routes require a paired device token, while device administration requires its separate loopback-only admin token.

Pairing codes are random UUIDs, single use, expire after ten minutes, and are stored as hashes. Access tokens are random UUIDs; only their hashes are stored in `nivkode.sqlite3`. The state directory is set to mode `0700` and the database to `0600`; the token itself is returned once during pairing or rotation and held by the Android client in encrypted storage. SEC-2 adds a configurable 90-day default expiry and last-used tracking. `GET /v1/admin/devices` lists metadata and `DELETE /v1/admin/devices/{id}` revokes a device; both require a configured admin bearer token and are served only on the owner-only Unix socket `STATE_DIR/admin.sock`, or `$XDG_RUNTIME_DIR/nivkode/admin-<hash>.sock` in a checked owner-only directory when that path is too long for a socket address (never an abstract socket; `nivkode-gateway admin-socket` prints it) (peer must be the gateway's own user; proxy headers refuse the request), never on the TCP listener, because Tailscale Serve and other local proxies make every forwarded request a loopback TCP peer (ADMIN-PROXY). Existing database tokens receive a full configured lifetime starting at migration. There is no standalone token file.

Axum's body limit defaults to 12 MiB (config maximum 16 MiB); image payloads are separately capped at 8 MiB, four images, and supported MIME types. Workspace ids are resolved against configured ids, not interpreted as paths. Artifact ids are resolved from the database; artifact files are canonicalized and must remain regular files under the canonical workspace root. Evidence export includes redacted event payloads and artifact metadata only; bytes are excluded. Learning Curve capture redacts before bundling and applies a final text redaction pass. Tracing does not currently emit request bodies or authorization headers.

Local model routing is restricted to a credential-free loopback HTTP Ollama origin. The route table requires the expected schema and provenance digests, and entries can bind only to the local `ollama/local` provider (tables that still use the old name for the local account load as `local`). A caller-selected model remains caller-controlled but is bounded in length and must appear in the Ollama installed-model catalog. MOS selection uses the configured route and installed catalog; no caller-supplied endpoint is used.

The optional systemd user unit runs as the user, restarts on failure, and is not enabled by installation. SEC-2 adds `NoNewPrivileges`, `PrivateTmp`, `ProtectSystem=strict`, `ProtectHome=read-only`, `ReadWritePaths=%h/.local/share/nivkode`, restricted address families, `LockPersonality`, and `MemoryDenyWriteExecute`. Installation creates the conventional state directory so systemd can apply its writable exception; custom `state_dir` values require adjusting the unit's `ReadWritePaths`. `install.sh` checks the archive against exactly one matching filename entry in `SHA256SUMS`, rejects unsafe archive paths and links/special files, and verifies required package contents. The checksum manifest is not itself authenticated, so this detects corruption relative to the supplied manifest but does not establish publisher authenticity.

## Findings

### P2 — Long-lived device tokens have no expiry or last-used revocation interface — fixed in SEC-2

SEC-2 adds configurable token expiry, records last use, and provides loopback plus admin-token protected listing and revocation routes. Legacy tokens are granted one configured lifetime from migration time. Tests cover migration, last-used tracking, expiry, and revocation.

### P2 — Optional systemd unit has no service sandbox — fixed in SEC-2

The user unit now enables the sandbox directives above. This worker environment has no user systemd bus, so runtime startup under the sandbox is pending the documented manual check in [SEC2_SYSTEMD_CHECK.md](SEC2_SYSTEMD_CHECK.md). This will not establish compatibility for arbitrary Codex extensions or workspace paths.

### P2 — Release checksum is not an authenticity mechanism

The installer verifies the archive against a neighboring `SHA256SUMS` supplied by the same channel. An attacker able to replace both can provide a matching malicious package. Sign the manifest or publish an independently authenticated digest before treating this as a supply-chain trust check.

## Validation

Added isolated tests for all registered data routes rejecting requests without a bearer token (pairing and health explicitly excluded), authenticated oversize body rejection, opaque workspace/artifact id lookup, credential DB permissions and hash-only token storage. Existing artifact canonical-path and evidence-export redaction tests cover parent/symlink escape and secret removal from exported event data; existing redaction tests cover common credential forms. Test results and commit provenance are recorded by our development process after the full gateway test suite completes.

## Release hardening review — 2026-10-06

**Scope:** gateway source on `security/nov2-hardening-20261006`. Source review plus isolated Rust tests, including a scripted Codex app-server. No live provider, browser, phone or proxy was exercised. Full record: [EVIDENCE/security-review-20261006.md](../EVIDENCE/security-review-20261006.md).

### P1 — Codex sessions could inherit host approval and sandbox policy — fixed

Resuming a Codex thread, which the Android client does for every send to a thread not active in the current gateway process, sent no approval or sandbox policy. No path pinned the approval reviewer. The host Codex configuration and folder trust therefore decided the policy, and a configured automatic reviewer could have answered approvals in place of the owner. Every thread start, resume and turn now pins `on-request` approvals routed to the user, a read-only sandbox without network access, and the configured workspace directory.

### P1 — Approval requests must be shown exactly — fixed

Secret redaction must never change what the owner is asked to approve: a redacted command can hide the part that would run. Open approval requests are shown verbatim and redacted in storage once answered or stale. Only one answer per request is forwarded, even when two devices answer at the same time.

### P1 — Repository-local Codex configuration — refused by default

Codex loads a project `.codex/` (MCP servers, hooks, exec-policy rules, sandbox defaults) for folders it trusts, and that configuration can run code without a model request or an approval. Before opening a Codex session, the gateway now refuses a workspace whose project `.codex/` contains anything beyond skills, prompts, a README or `.gitignore`. To allow it, list the workspace id in the optional gateway config key `codex_project_config_workspaces`.

### P2 — Browser and content hardening — fixed

API routes refuse requests that a browser marks as cross-site or that come from an opaque origin. Responses that carry tokens are `no-store`. Workspace artifacts are served as inert plain text or images, with `nosniff` and a sandboxing CSP.

### Residual risk to read before deploying

- **Codex folder trust still matters.** The gateway refuses repo-local `.codex/` configuration unless the workspace is opted in, but its detection follows current Codex behaviour. Trust only repositories you own, and avoid broad trust entries such as `/`.
- **Every paired device has owner authority.** It can read all workspaces and answer approvals until revoked. Behind a same-host proxy, the admin token is the only admin control.
- **No Host allowlist yet.** DNS rebinding can reach only pairing and handoff claim, which need one-use, high-entropy codes.
- **No per-device rate or concurrency limits.** Event history has no retention policy.
- **Dependency audit (6 October).** `cargo audit` found no vulnerabilities; one yanked crate was replaced. Two advisories remain in libraries used only by the terminal view (`lru` unsound, `paste` unmaintained); fixing them needs a breaking `ratatui` upgrade. Record: `EVIDENCE/security-wave2-20261006.md`, section 6.
