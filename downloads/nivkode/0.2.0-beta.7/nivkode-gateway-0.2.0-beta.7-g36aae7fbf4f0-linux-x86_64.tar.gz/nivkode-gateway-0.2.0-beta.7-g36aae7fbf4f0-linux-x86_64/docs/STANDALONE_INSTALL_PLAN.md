# Standalone install plan

**Status: roadmap; owner decisions are called out below.** Estimates are
engineering sizes, not delivery promises. Owner decision (21 October 2026):
Friday 13 November 2026 is the release target; it may move if testing finds
issues. The milestones marked **before 2 Nov** are the original planning
window and have not been rescheduled here.

## Starting point

The current Linux x86_64 tarball contains the gateway (with the desktop client
built in), the `nivkode` CLI, the `nivkode-doctor` wrapper, example
configuration, an optional systemd user unit template and these docs. It does
not contain the separate Android app or Codex CLI. The
existing install script takes a local archive and optional SHA-256 file; it is
not a one-command network installer. Users configure the gateway, install and
sign in to Codex CLI themselves, and install Ollama themselves.

## Where this stands (6 October 2026)

| Milestone | State |
|---|---|
| 1. Installer foundation | Partly done. The installer works from a local archive and a checksum file, and an uninstaller exists. There is no one-command network install. |
| 2. Bundled NivKode CLI | Mostly done. `nivkode` ships with the gateway and has `status` and `doctor`. There are no service lifecycle commands. |
| 3. Ollama detection and guided setup | Partly done. Doctor checks for Ollama and a model. There is no guided setup. |
| 4. Provider connection wizard | Not built. There is no `nivkode connect`. |
| 5. Signed releases | Not done. The tool choice is an open owner decision. See [Release signing](RELEASE_SIGNING.md). |
| 6. Auto-update and rollback | Not built. |
| 7. Additional platforms | Not started. |

## Milestones

| Milestone | Scope | Size | Before 2 Nov? |
| --- | --- | --- | --- |
| 1. Installer foundation | One-command Linux x86_64 install script; fetch a versioned release, verify its published checksum, install under the user's home, preserve existing config, and provide uninstall instructions. Fail safely on unsupported systems. | M | Yes |
| 2. Bundled NivKode CLI | Include a stable `nivkode` command alongside the gateway and doctor. Add subcommands for status/doctor and service lifecycle; document managed files and user-data preservation. | M | Yes |
| 3. Ollama detection and guided setup | Detect an existing Ollama install and local endpoint/model. Explain options and guide the user to install Ollama and pull a model; do not silently install system packages or download large models without clear user action. | M | Yes |
| 4. Provider connection wizard | Add `nivkode connect codex`: check whether Codex CLI exists, launch its supported `codex login` flow for the user, and confirm app-server readiness without capturing or printing credentials. Show provider data/terms and usage-cost reminders. Claude has a beta.7 route, but no live run is verified (**Not yet tested**); the app labels Claude "in development". Grok is not supported; no integration date is promised. | M/L | Initial Codex flow: Yes |
| 5. Signed releases | Sign release artifacts and publish verification instructions and key rotation/revocation policy. **Owner decision pending: minisign or GPG.** Select the tool and trust-root distribution before implementation. | M | Decision + initial signing: Yes |
| 6. Auto-update and rollback | Opt-in update checks, release channel/version display, signature verification, staged install, retained previous version, explicit rollback command, and failure recovery. Never replace user config or state. | L | Design and first opt-in updater: possible; rollback hardening later |
| 7. Additional platforms | Port packaging, service integration, and install/upgrade recovery to other Linux distributions; then investigate macOS packaging, permissions, signing, and notarization. | L per platform | No; later roadmap |

## Suggested order and gates

Deliver milestones 1–3 as the first usable standalone install slice. Add the
Codex connection wizard after its sign-in/readiness checks can be performed
without reading credentials. Release signing can proceed once the owner chooses
minisign or GPG and approves key custody and distribution. Keep updates opt-in
initially; do not enable automatic installation until signature verification,
rollback, and preservation of configuration/state have been reviewed.

The original 2 Nov plan estimated that the target could include the Linux installer, bundled CLI,
guided Ollama setup, initial `nivkode connect codex`, and a signed release if
the owner resolves the signing choice early. Complete updater rollback and
additional platforms are later work unless scope is explicitly expanded.
