# NivKode UI language and spec

**Version 1, 7 October 2026.** Written by the Wave 5 UI/UX lane (fable-uiux) under the approved direction recorded at 02:10 to
upgrade the UI language for every client to follow. Reference implementation: the desktop client,
`nivkode-rusty/gateway/static/desktop.css` and `desktop.html` on `ux/wave5-20261007`. Where this document and the
desktop differ, this document wins and the desktop is fixed.

**Scope.** The desktop, the Android app, the CLI and TUI, and the workspace activity and review views. Each client renders the
same facts with the same meaning; the medium changes, the language does not.

**Limits that no reading of this document relaxes:** accessibility (WCAG 2.2 AA; the HighContrast palette at AAA
contrast), the four colour palettes and three reading fonts, and correctness. Copy that carries product semantics
(engine choice, refusals, approvals) is owned by Lead · Product's cross-client spec (`EVIDENCE/p1-30-cross-client-spec.md`, branch `product/wave5-20261007` at `83921c73`);
this document says where and how that copy appears, never what it says.

---

## 1. The bar

Elegant, professional, powerful, realtime, no bloat. In practice:

1. **A work tool, not a chat app.** NivKode supervises an assistant working in a workspace. The screen shows the
   instruction, what the run is doing, what it changed, and the decision it needs. No chat bubbles, no typing
   indicators, no avatars, no "AI" sparkle.
2. **State is a sentence, never a colour alone.** Every state is written in words, next to its indicator, in the
   place the person is already looking.
3. **Realtime, in three tiers** (section 7): always visible, on demand, only on change. Nothing else moves.
4. **Hierarchy over inventory.** One primary action per surface. One eyebrow per card. Detail behind "Details".
5. **Calm under failure.** What is known, what is uncertain, what happened, the safe next step; the same chrome
   as a healthy state, with the warning or danger colour carrying the difference.
6. **Where a reply goes is visible.** Where a reply goes (on this computer, or off it) is said as text beside the choice,
   every time a message can be sent.
7. **Keyboard and pointer are equals.** Shortcuts are shown where they apply; focus is always visible and never
   covered.

---

## 2. Identity

- **Mark:** the NivKode mark (brand R1.12: the Nivren N + a cursor block), drawn once in the sidebar wordmark, once on the first-run panel, and in the favicon. Cyan + ember on dark, teal + ember-deep on light; accessibility palettes use their accent; CanvasText in forced colours.
- **Brand colours in the interface:** teal is the accent. The mark uses the brand's cyan and ember (or the palette's accent).
  Violet appears only in the one brand hairline under the header (`--brand-line`, teal to violet). It is never text, never a surface, never a state.
- **Wordmark:** "NivKode", 16 px, weight 600, letter-spacing −0.01em, beside a 24 px mark.
- **Voice:** plain, calm, factual, second person ("you"), present tense. Sentences, not labels, wherever a state
  is explained. No exclamation marks. Numbers as digits. British spelling.
- **Signature line:** "No telemetry · Signed builds" (shipped sidebar footer). Released builds are signed (minisign, pinned key). This wording was retained by decision; the telemetry statement is supported by a source scan, not a runtime telemetry test.

---

## 3. Tokens

The desktop stylesheet is the machine-readable source (`desktop.css`, section 1). Every client maps these names.
Colour tokens are hex per theme and palette so `tests/theme_contrast.test.cjs` can verify every pair; derived tints
are `color-mix()` on `<body>`.

### 3.1 Colour roles

| Token | Role | Rule |
|---|---|---|
| `--bg` | Page | The only full-bleed colour. |
| `--rail` | Sidebar | One step from `--bg`. |
| `--surface` | Cards, header pill, composer | Content sits here. |
| `--surface-2` | Nested cards (requests, files, notes), buttons | One step above `--surface`. |
| `--line`, `--line-strong` | Hairlines; field and default-button borders | `--line-strong` only where a border carries meaning (fields, buttons, "no longer waiting"). |
| `--text`, `--muted` | Primary and secondary text | `--muted` is for labels and explanations, never for the fact itself. |
| `--accent` | Primary action, live indicator, links, selection | The teal. Also the role label of the assistant's turns. |
| `--on-accent` | Text on accent | |
| `--focus` | Focus ring | 2 px, offset 2 px; inset where a scroll container would clip it. |
| `--success` | Completed; verified; **local** | Also `--local`. |
| `--warning` | Needs a decision; uncertain; reconnecting; **external** | Also `--external`. |
| `--danger` | Failed; offline; Stop; removal | |
| `--user-surface`, `--user-border` | The person's own instruction | |
| `--selected-surface`, `--selected-border` | The selected list item and option | |
| `--brand-line` | The header hairline | A gradient; a solid line in HighContrast. |

Semantic aliases, on `<body>`: `--local: var(--success)`, `--external: var(--warning)`. **Local stays green,
external stays amber, in every palette.** Tints: `--accent-tint`, `--success-tint`, `--warning-tint`, `--danger-tint`,
`--hover`, `--pressed`.

**Themes and palettes.** Two themes (dark, light; follows the system) × four palettes (Default, ColourSafe,
TritanopiaSafe, HighContrast) = eight resolutions, all pinned in `desktop.css` and verified at 4.5:1 for every text
token on every surface, 7:1 in HighContrast. A client adding a colour must add it to all eight, or derive it from
these tokens with a verified mix.

### 3.2 Type

Family: Inter, then "Segoe UI", system-ui. Monospace: Cascadia Code, JetBrains Mono, Consolas. Reading fonts
(Atkinson Hyperlegible, OpenDyslexic) apply to message bodies only, through `--reading-font`.

| Role | Size / weight | Where |
|---|---|---|
| Eyebrow | 11 px / 600, uppercase, 0.08em, `--muted` | Section labels: WORKSPACE, ACTIVITY, LATEST RUN, REVIEW. One per card. |
| Caption | 11–12 px / 400–500 | Chips, hints, timestamps, counts. |
| UI | 13 px / 400 (600 on buttons) | Controls, lists, notes. |
| Body | 14 px / 400 | Explanations, dialog copy. |
| Reading | 15 px × text scale / 400, line-height 1.65 | Message bodies; measure 72ch. |
| Card title | 15 px / 600 | An approval request's title. |
| Section | 16 px / 600 | "Run review", dialog headings. |
| Panel | 18 px / 600 | Onboarding, workers. |
| Title | 20 px / 600, −0.01em | The conversation title. |
| Hero | 20–24 px / 600 | The first-run heading. |

Identifiers (paths, models, routes, run ids, counts, diff stats) are monospace. Numbers in chips and counts use
tabular figures. Text scale runs 90–145 %; layouts reflow, never clip.

### 3.3 Space, radius, size

- **Grid:** 4/8. Tokens `--s-1` 4, `--s-2` 8, `--s-3` 12, `--s-4` 16, `--s-5` 20, `--s-6` 24, `--s-8` 32, `--s-10` 40.
- **Rhythm:** 8 px between items in a row, 12 px between stacked cards, 16 px card padding (20 px on the review),
  16 px between transcript entries.
- **Radius:** `--r-xs` 4 (code, test badges), `--r-sm` 6 (buttons, fields, chips' squarer kin), `--r-md` 8 (nested
  cards, notices), `--r-lg` 12 (top-level cards, dialogs, the composer), `--r-pill` for chips, flags and status pills.
- **Controls:** 32 px tall on fine pointers (28 px for the small variant); **44 px on touch or under 768 px**,
  including disclosure summaries and list rows. No interactive target under 44 × 44 px on those devices.
- **Widths:** rail 280 px (248 under 1100 px); content column at most 1120 px, centred; reading measure 72 ch;
  dialogs 440 px (onboarding 600, message panel 720).

### 3.4 Motion

- One duration, `--dur` 120 ms, one curve `cubic-bezier(0.2, 0, 0, 1)`, for hover, chevrons and border changes.
- **Pulse** (opacity to 0.35 and back, 1.2–1.4 s) is the only continuous animation, and it means **live**: a
  reconnecting dot, the active step, the reply in progress. Nothing else loops.
- No entrance or exit animation. No skeleton shimmer. State changes are instant and reserve their space, so the
  layout does not jump when a status line appears.
- `prefers-reduced-motion: reduce` stops every animation and transition.

### 3.5 Elevation

Flat surfaces separated by hairlines and one tonal step. The single shadow, `--shadow-overlay`, belongs to things
that float: toasts and dialogs. Nothing else casts one.

---

## 4. Layout

### 4.1 Desktop shell

```
┌ rail ──────────┬ main ─────────────────────────────────────────┐
│ wordmark        │ header (sticky): eyebrow · title · rename · SOS │ status pill
│ LOCAL GATEWAY   │ ──── brand hairline ─────────────────────────── │
│   state, form   │ notice (only when something needs attention)    │
│ WORKSPACE       │ view switch: Conversation · Workers             │
│ CONVERSATIONS + │ transcript: role gutter | text                  │
│   list          │ run stack: ACTIVITY · LATEST RUN · REVIEW       │
│ Getting started │ composer: text · [where it goes] Use … · Send   │
│ Reading & colour│                                                 │
│ footer          │                                                 │
└─────────────────┴─────────────────────────────────────────────────┘
```

- The page scrolls as a whole; the rail and the header stay. `scroll-padding-top` equals the header height so a
  focused element is never hidden under it.
- **Transcript.** Each entry is a grid: a 96 px role gutter (80 px under 1100 px, stacked under 768 px) and the
  text. The person's instruction is a panel on `--user-surface`; the assistant's reply is prose with its role label
  in `--accent`. Entries are separated by a hairline, never by alignment or bubbles.
- **Run stack.** Activity, Latest run and Review share one chrome (`--surface`, `--line`, `--r-lg`, 12 px apart).
  It collapses entirely when the conversation has no run.
- **Composer.** One card: text area, then a footer with where the reply goes, the engine choice and Send with its
  shortcut, then one sentence of capability. Hidden until the desktop is paired.
- **Console layout (≥ 1340 px, v1.1).** While a run has anything to show, the main area becomes a supervision
  console: transcript and composer on the left, the run stack in a right column (`clamp(400px, 31vw, 500px)`,
  32 px gap) that stays in view (sticky under the header, its own scroll) while the transcript scrolls. The composer
  pins to the bottom of the left column. DOM, reading and focus order are unchanged (transcript, run, composer);
  `scroll-padding-bottom` keeps focus clear of the pinned composer. With no run, the single centred column stays.
  Matrix state `console-layout` measures the geometry at 1440 and 1280 px and that a focused decision is on screen.
- **Outage.** Offline: the status pill and the sidebar gateway card take `--danger-tint` / a danger edge; the
  composer's border turns dashed danger and its offline sentence becomes a band with a dot. Reconnecting: the same
  in warning. The words are unchanged; colour is additive (section 1, rule 2).
- **Empty review sections.** A section with nothing in it (no test results, no artifacts yet) is its heading and its
  sentence on one row, so decisions and changes stay near the top.

### 4.2 Breakpoints

| Width | Change |
|---|---|
| ≥ 1340 px, a run showing | Console layout (4.1): run stack in a sticky right column; composer pinned under the transcript. |
| ≤ 1100 px | Rail 248 px; content padding 24 px; gutter 80 px; shorter selects. |
| ≤ 768 px, or coarse pointer | 44 px targets; header wraps; transcript gutter stacks above the text; activity steps stack above Stop; shortcut hint hidden on touch. |
| ≤ 700 px | Single column: rail above main; header static; conversation list capped at 180 px. |

### 4.3 Android and TUI

- **Android:** the same tiers and semantics (section 7), the same colour roles, 44 dp targets everywhere, the role
  gutter becomes a label above each entry, the run stack becomes cards in the same order, the engine flag sits above
  the composer. Detail in `EVIDENCE/ux-android-direction-20261007.md`.
- **Android direction for the console layout (v1.1):** phones keep the stacked order. On a tablet or unfolded
  screen (≥ 840 dp, Compose `WindowWidthSizeClass.Expanded`) use the same two panes: transcript and composer left,
  the run cards in a right pane of 360–440 dp that scrolls independently; decisions never leave the screen while a
  request is pending. Empty review sections collapse to one row (heading and sentence), as on the desktop.
- **TUI:** the header line is the status pill (connection first, then run); the transcript is a role-prefixed log;
  activity steps are one line of `✓ ● ✗` chips; the engine flag is the composer prompt's prefix (`local ›` or
  `codex ›`). With no engine chosen the prefix shows nothing and the status line says T10, "No engine selected"
  (P1-30 spec). Colour is additive: every state is also a word.
- **CLI:** `nivkode status` and run output use the same state words as the desktop (section 6), in the same order.

---

## 5. Components

Each component names its desktop class. Clients implement the same anatomy and states.

| Component | Anatomy | Rules |
|---|---|---|
| **Status pill** `.state-pill` | dot · connection text · ⎪ · "Run: …" | The dot follows the connection only. The run label's tone: `working` = accent, `attention` = warning and 600, `idle` = text. Always visible (sticky header). |
| **Eyebrow** `.eyebrow` | uppercase label | One per card, at the top left. |
| **Chip** `.run-chip` | pill, mono, 24 px | Facts about a run: status (with a dot, coloured by status), route, model, local/provider, fallback. |
| **Step chip** `.work-step` | icon · label · target | A run's steps as a wrapping row. `active` has the pulsing dot and the accent border; `complete` a green tick; `failed` a red cross and border; a step that already happened is quiet. |
| **Engine flag** `.engine-flag` | dot · text | "On this computer" (`--local`) or "Leaves this computer" (`--external`). Exactly one shows, only while a message can be sent. Driven by the chosen engine, never by a stored default. |
| **Notice** `.notice` | strong title · sentence · actions | One per page, under the header, warning tint; `.offline` uses danger. Actions are underlined text buttons. A technical code only behind "Details". |
| **Toast** `.toast` | one sentence | Only on change (reconnected, switched, decision sent). 3.2 s. One at a time. Under the header, right. |
| **Request card** `.review-request` | title · what it names (path, diff, command, where, why) · policy line · actions | 4 px left border in `--warning` and a warning-mixed border while live; `.waiting-input` accent (no controls: this desktop cannot answer it yet, and its copy names Stop); `.unsupported` keeps the warning border, says no device can answer it, has no controls, and the notice offers "Stop this run"; `.stale` quiet with a "No longer waiting" badge and a Refresh. Approve is the only primary button. Hidden-character warning (W1) is the first line when a marker is shown. |
| **Review card** `.review-gate` | eyebrow · "Run review · state" · status pill · files · requests · tests · artifacts · notes · empty line | Carries the warning border while any request needs a decision. The status pill says the count. |
| **File row** `.review-file` | chevron · path · kind · +n −n | A disclosure; the diff is a labelled, focusable region with each line on its own row. |
| **Activity bar** `.live-work` | eyebrow · step chips · Stop | Stop is an outlined danger button; "Stopping…" keeps focus with `aria-disabled` and a status sentence. |
| **Transcript entry** `.message` | role · body (· status) | `.user` panel, `.assistant` prose, `.assistant-progress` muted text with three pulsing bars. |
| **Composer** `.composer` | textarea · footer (flag, Use, selects, kbd, Send) · note · hint | Border lifts toward accent while writing. The hint (pasted code) is a warning-tinted block with the one explicit way to Codex. |
| **Dialog** `dialog` | eyebrow · heading · copy · fields · actions | Modal, focus inside, Escape cancels unless a send is in flight, focus returns to the opener. 44 px options. |
| **Buttons** `.button` | default (`--surface-2`, strong border) · `-primary` (accent) · `-quiet` (transparent) · `-danger` (outlined) · `.text-button` (accent text) · `.icon-button` (32 px square) | One primary per surface. Disabled is 50 % opacity and `not-allowed`; "in flight" is `aria-disabled` with a progress cursor and keeps focus. |
| **Fields** | 32 px, `--field`, strong border, 6 px radius | Hover border `--muted`; focus border and ring `--focus`. Selects draw their own chevron. |
| **kbd** | bordered key cap | Shows a shortcut where it applies; hidden on touch. |
| **First-run panel** `.welcome-card.first-run` | mark · heading · sentence · numbered ways in | The only hero on the product. |
| **Empty states** | illustration · heading · one sentence | Say what will appear here and how to make it happen. Line illustrations in `--muted` with the accent as the only colour. |

---

## 6. State patterns

Every state is text in a fixed place. Clients use the same words (desktop-core `labels`, `eventLabels`,
`connectionPresentation`), in this order of precedence when several apply: connection, then the run, then requests.

### 6.1 Connection (status pill, sidebar presence, composer note)

| State | Dot | Words | Also |
|---|---|---|---|
| Not connected | grey | "Not connected" | Connect form and first-run panel; composer hidden. |
| Connected | green | "Connected · host" | |
| Reconnecting | amber, pulsing | "Reconnecting to gateway…" | Toast once; composer note says messages wait in this window. |
| Offline | red | "Offline" | Notice `.offline`; queued messages marked "Queued · waiting for connection". |
| Gateway restarted | green | "Gateway restarted · connected" | Toast once; returns to Connected after 7 s. |
| Signed out | grey | "Not connected" | Notice "Signed out" with the reason; connect form returns. |

### 6.2 Run (status pill run label, activity, latest-run chip, review status)

Starting → Accepted → working ("Waiting for response") → waiting for a person ("Waiting for your approval",
"Waiting for your answer") → Stopping… → a final state: Completed, Failed, Interrupted ("Run stopped" when the person
stopped it), Outcome unknown. Rules:

- The progress entry ("Working on a response…") exists only while the run is unfinished and is removed on the next
  render after it ends.
- "Waiting for …" is the pill's `working` tone; failures, interruptions and unknown outcomes are `attention`.
- An unknown outcome keeps Send off only while the gateway still holds the run; the notice offers "Check again".
- Failure copy says what happened, then what to do; the raw reason never appears.

### 6.3 Requests (review card)

Live (decisions offered) → answered ("Approve sent.", toast) → stale ("No longer waiting", explanation, Refresh)
or ended (the run finished; no decisions). A question the client cannot answer is shown with its text and where to
answer it. Decision buttons are disabled together while one decision is being sent, and while the gateway is
reconnecting or offline (the card then says "Offline. You can answer this request once the gateway is back."; D10-10).

### 6.4 Per-surface loading, empty, error, offline

| Surface | Loading | Empty | Error | Offline |
|---|---|---|---|---|
| Conversation list | (fast; no state) | Illustration + "No conversations yet." | Notice | "Connect to load your history." |
| Transcript | — | "Start with a message" + the shortcut | Notice | Queued entries marked |
| Workers | "Loading worker activity…" | "No worker runs recorded for this workspace." | `data-state="error"` sentence | "Offline · connect to the gateway to load worker activity." |
| Artifacts | "Loading artifacts…" | "No artifacts reported for this run." (only when nothing can still arrive) | sentence + Retry | "Offline. Reconnect to load artifacts." |
| Notes | "Loading notes…" | "No notes yet." | sentence + Retry | "Offline. Reconnect to the gateway to load notes." |
| Messages | "Loading messages…" | "No messages yet." | "Service unavailable" + error line | "Connect to the gateway to see messages." |

Loading text appears only when a wait is likely to be noticed (about 300 ms and more); nothing spins without words.

---

## 7. Realtime, not noisy: the three tiers

**Always visible** (one place each; never duplicated on the same screen beyond the header pill and its sidebar twin):
1. Connection state (dot + words).
2. The latest run's state (words).
3. Where the next reply goes (the engine flag), whenever a message can be sent.
4. How many decisions are waiting (review status pill), and the decision cards themselves.
5. The conversation's title and workspace.

**On demand** (one click, one disclosure, never a modal):
provenance (account, model digest, decision id, raw JSON); each file's diff; a request's where and why; notes; the
technical code of an unrecognised error; the identity details (recorded workspace and branch); the optional message panel.

**Only on change** (said once, then quiet):
toasts for reconnected, restarted, switched engine, decision sent, copied; a new step chip when the run reaches it;
the "Checking for files the approved command changed…" line while a follow-up read is open.

Rules that keep it quiet:
- One live indicator per surface. When the header pill pulses, nothing in the transcript needs to.
- Finished steps go quiet (muted); only the current step is coloured.
- No counters that tick, no elapsed timers, no token counts, no per-event log lines in the transcript.
- A toast never repeats a notice, and a notice never repeats the pill.
- Information that the person did not ask for and cannot act on is not shown. Facts that change the next decision
  (where a reply goes, that a request is waiting, that an outcome is uncertain) are never hidden.

---

## 8. Density

- Desktop: 32 px controls, 8 px gaps in rows, 12 px between stacked cards, 16 px card padding, 20 px on the review.
  Lists are 32 px rows. Chips are 24–26 px.
- Touch and narrow: 44 px controls and rows; the same gaps.
- One eyebrow, one heading and at most one status pill per card. At most three sections of a card are open by
  default (files, requests, tests); artifacts and notes follow.
- A row of chips wraps; it never truncates a chip. A path truncates with an ellipsis in a summary and wraps in a
  card.
- Text measure 72 ch for prose and 64 ch for explanations; wider only for code and diffs, which scroll.

---

## 9. Accessibility, non-negotiable

- Contrast 4.5:1 for text and 3:1 for non-text in every theme × palette; 7:1 in HighContrast, which also uses
  2 px borders on decision surfaces.
- Focus: `2px solid var(--focus)`, 2 px offset (inset inside scroll containers), never obscured by sticky chrome.
- Targets: 44 × 44 px on touch and under 768 px, including summaries and radio options (the label counts).
- Every state is text; colour and motion only reinforce it. Live regions: the pill (`role=status`), the notice
  (`role=alert`), the transcript (polite, additions), decision status lines.
- Hidden and control characters in anything that decides what runs are shown as real-text markers (`⟨U+202E⟩`),
  never stripped, never as CSS content (P1-30 spec §7).
- Dialogs are modal, trap Tab, return focus, and cannot be dismissed while a send is in flight.
- The reading fonts, the palettes and the text scale apply everywhere, including dialogs, chips and diffs.
- Forced colours: dots and the hairline keep their meaning (`forced-color-adjust: none`, `CanvasText`).
- No icon without a text label or an accessible name. Decorative SVG is `aria-hidden`.

---

## 10. Conformance

- `nivkode-rusty/gateway/tests/theme_contrast.test.cjs` pins the token table and every contrast pair.
- `tests/ui_states_matrix.mjs` renders every state at 1280 and 768 px (and 1440 with `UI_STATES_WIDTHS`), dark and
  light, runs axe-core (WCAG 2.0/2.1/2.2 A, AA and best practice), measures targets under 44 px at 768, horizontal
  overflow, raw gateway codes and restricted surfaces. Strict mode fails on any of them. New UI adds a state.
- `tests/a11y_audit.mjs` scans the first-run, onboarding, empty, active and offline states in every theme ×
  palette × reading font.
- Android: the JVM parity tests for copy and the Compose UI tests for 44 dp targets and TalkBack labels.

**Changing this document:** propose the change with a rendered capture of the affected screen; update the desktop
stylesheet and this file in the same change; add or adjust the matrix state that proves it.

## Changelog

- **v1 (2026-10-07, fable-uiux):** first version. Introduces the transcript gutter, the unified run stack, the engine
  flag, the sticky header with the brand hairline, the three-tier realtime doctrine, density and motion rules.
- **v1.1 (2026-10-07, fable-uiux, batch 2):** console layout at ≥ 1340 px (run column beside the transcript, pinned
  composer), one-row empty review sections, decision tint on the status pill and review status, the joined
  activity/latest-run card, a larger conversation title, "No telemetry · Signed builds" in the signature line; a connection outage
  tints the status pill and the sidebar card and gives the composer a dashed danger edge with its sentence as a
  band; the first-run panel is framed with a 64 px mark. Android direction for expanded widths.
