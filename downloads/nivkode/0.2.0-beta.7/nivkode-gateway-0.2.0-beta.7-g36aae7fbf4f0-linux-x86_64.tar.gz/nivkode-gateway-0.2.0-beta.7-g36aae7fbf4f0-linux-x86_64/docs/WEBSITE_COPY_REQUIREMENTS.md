# Historical 0.1 website copy requirements

This document records 0.1 decisions and is not the source of current 0.2
claims. Use [PUBLIC_CLAIMS.md](PUBLIC_CLAIMS.md) and [RELEASE_DRAFT.md](RELEASE_DRAFT.md)
for current 0.2 wording.

**A text-only handoff for updating the site.** Keep this copy
consistent in the NivKode section and press kit.

## Status wording

Describe 0.1.0 as a **beta**. Owner decision (21 October 2026): Friday
13 November 2026 is the target; it may move if testing finds problems. Lead with local models and an optional external AI provider (e.g. Codex, Claude, Grok). Label Ollama **Tested on this computer; not yet run from a phone** and Codex **Tested, experimental** within the documented limits; say Claude has a beta.7 route but is **Not yet tested** (no live run is verified), and that the app labels it "in development"; Grok is **Not yet tested** and unavailable in this build. Say that the Android app is a preview that users build themselves, and
the package is Linux x86_64 only (the only system it has been tested on). Name
RC17 as the latest numbered review candidate, describe later work as "since
RC17", and say nothing has been published. Link to
[Beta limitations](beta-limitations.md). Do not claim that a real screen reader
has been tested, that live providers have been tested widely (live runs on one
machine passed on 6 October), or that the owner has confirmed the 6 October
acceptance runs. AI agents ran them. A 6 October Android build passed an
acceptance run on one phone with a scripted provider. Do not
show provider capacity, usage or quota figures: NivKode has no source for them
and reports them as unknown. Make no quality claim about local models ("good
at", "as capable as", rankings or benchmark wording): say they run on your
computer through **Ollama — local model provider**. Do not call the second RC17 verification pass
independent, an audit or human-reviewed; an AI agent ran it. Each of these
statements and its evidence is in [Public claims and evidence](PUBLIC_CLAIMS.md).

## NivKode section

**Requirements:** Linux x86_64 computer; Ollama installed for local-model turns. An external AI provider is optional: this build supports experimental Codex with the Codex CLI and your own Codex account. To use the Android app,
you also need a phone-reachable private HTTPS route to your gateway, configured
separately. Claude has a beta.7 route, but no live run is verified (**Not yet
tested**); the app labels Claude "in development". Grok is not supported.

**Bring your own account:** If you choose the supported external provider, NivKode connects Codex through the Codex CLI using
your own Codex account, which sends conversations to that account's provider
(for example OpenAI or Amazon Bedrock). You sign in yourself and are responsible for following
the provider's terms and usage rules, and for any charges on your account.
Local turns use **Ollama — local model provider**, configured on your computer.

## Press kit

Use the same requirements and bring-your-own-account statement above. Do not
describe Claude as available, imply that a NivKode subscription includes
provider access, or suggest that YewForge provides, pays for, or controls
third-party accounts. Keep the connected-services page marked draft until the
owner completes legal review.

## Corrections needed on the live site

Read-only check of the public site on 6 October 2026 at 08:44 BST. Nothing on
the site was changed. Each line conflicts with
[Public claims and evidence](PUBLIC_CLAIMS.md); the row number is in brackets.

| Page | The site says | Problem | Suggested wording |
|---|---|---|---|
| Home, NivKode, Nivren, About, Press, Updates | "NivKode 0.1.0 RC8 is a review candidate" | Out of date. The newest review candidate is RC17, from 5 October [11]. | "NivKode 0.1.0 RC17 is a review candidate. Release approval and publication are pending." |
| NivKode, Known limitations | "The Android app has passed unit tests and built, but has not been installed or accepted on a physical device." | Outdated: the 6 October evidence includes scripted and live Codex runs on one S20 [9], run by AI agents without owner confirmation. | "The Android app is a preview that you build yourself. AI-run checks passed on one S20, including two live Codex turns. The owner has not confirmed those runs, and no screen-reader session was recorded." |
| NivKode, intro and "Bring your own accounts" | "you bring your own provider accounts"; "NivKode connects to provider accounts you already have, or to local models." | The plural suggests several hosted providers. Codex has bounded earlier-build evidence [1, 4]; Claude's beta.7 route is present but untested. | "We provide a local model route, and you may choose an external provider for a conversation. Live use of provider routes on this build is **Not yet tested**. An additional route is labelled in development." |
| NivKode, "Bring your own accounts" | "It never runs suggested commands for you." | Can be read as "no command ever runs". Codex runs inside a read-only, no-network sandbox and asks before it changes files, but read-only commands run there without asking (seen in the live session on 6 October) [6]. | "Codex asks before it changes your files, and a local model cannot run anything." |
| NivKode, "Open source"; Updates, 3 October entry | "Open source: licensed AGPL-3.0-only."; "Open source (AGPL-3.0), launching 2 November." | The source repository is not public yet, so "open source" cannot be checked by a reader. The dated entry also states the date without the condition [14]. | "Licence: AGPL-3.0-only. The source code is not publicly available yet." PR #14 does not correct the conflicting source-availability promise. Do not say "open source" until the owner publishes the source. Leave the dated 3 October entry as a record; the next Updates entry restates the target and its condition. |
| Home, NivKode card; Updates, 3 October entry | "Free automated tests run on every change." | Continuous integration runs on pushes to release-candidate (`launch/**`) branches and by hand, not on every change. It last passed on the RC17 branch on 5 October. | "Automated tests run on every release candidate." |

The 6 October site check found no Claude mention. Any owner-visible update should show provider labels with their bounded evidence and keep usage or quota figures unknown. Publication requires owner approval and happens outside this repository.
