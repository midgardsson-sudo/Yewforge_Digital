# Beta limitations

NivKode 0.2.0-beta.7 is the Linux x86_64 candidate. An approved release
archive carries a checksum signed with the NivKode release key, verified
against the pinned key before installation. Signing does not establish
publication, public availability, or owner acceptance. We support local models
and provider routes; live use on this build is **Not yet tested**. This
page lists remaining limits and behaviors that may surprise users.

Earlier builds had agent-run sessions on one machine and one phone. Beta.7 has
automated tests, but live providers and phone use of this build have not been
accepted by Jake. These are scoped observations, not broad compatibility claims.

## What we have not proven

| Area | What we have | What we do not have |
|---|---|---|
| Live providers | Automated tests with fake providers, plus earlier agent-run Codex and local-model sessions on one machine. | Live runs on other machines, accounts or CLI versions; owner acceptance of beta.7. |
| Screen readers | Automated accessibility scans and keyboard checks on earlier builds. | A real screen-reader session and human review of incomplete automated checks. |
| Android | Automated tests and earlier agent-run acceptance sessions on one real phone, including pairing, approvals, reconnect and live Codex turns. | A phone run of beta.7, broader device coverage, TalkBack review and Jake's confirmation. |
| Fresh installs | Earlier clean installs in disposable home directories on one machine. | Installation on other machines or distributions, or of the beta.7 candidate. |
| Release trust | For an approved beta.7 release, the archive is signed with the NivKode release key and the checksum signature is verified against the pinned key. | Publication and owner acceptance remain open. A valid signature does not establish that a download page is live or that the product has been accepted. |

Earlier desktop checks used a fake loopback provider and headless Chromium. They do not establish live-provider access, physical-device pairing or screen-reader speech and navigation. A separate agent verification pass covered a clean checkout, isolated-home install and accessibility scan of an earlier build; human review remains outstanding.

## Current limits

| Feature | Limit or test status |
|---|---|
| Claude | Route present; **Not yet tested**. The app labels the additional provider route "in development"; no live run is verified. |
| Automatic route choice | You pick the route, or the provider and model. NivKode does not choose from your prompt. |
| Provider capacity | The capacity endpoint always answers unknown. NivKode shows no usage bars or reset times, because it has no trustworthy source. |
| A `validated` delivery state | None of the supported providers reports validation, so the state is never shown. |
| Windows and macOS | NivKode 0.2.0-beta.7 targets Linux only. |
| One-command install, automatic updates, a rollback command | The installer takes a local, signed archive with its checksum file and signature. Nothing fetches updates and there is no rollback command. It refuses an older version over a newer one unless you pass `--allow-downgrade`; see [Go back to an earlier version](install.md#go-back-to-an-earlier-version). |
| Android release build | The package contains no APK. You build a debug app from source. A release build needs the release keystore, which has not been created ([Android release guide](ANDROID_RELEASE.md)); there is no update path, and the Android dependency licence inventory still needs a resolved release SBOM. |
| Terminal approvals | The terminal client cannot answer approval requests. |
| Answering Codex questions on the desktop | The desktop shows a question Codex asks, says this version can't answer it, and offers **Stop**. If you use only the desktop, press **Stop** to end the turn. The Android app can answer the question, if you use it. |
| Phone or remote access | You must supply your own private HTTPS route. NivKode does not set one up; [Phone setup](PHONE_SETUP.md) documents one with Tailscale Serve. No phone run has used that route with the current app yet. |

## Codex support is experimental

- The Codex adapter talks to `codex app-server` over standard input and
  output. That protocol is marked experimental by Codex and is version
  sensitive. We wrote and checked the adapter against `codex-cli
  0.155.0-alpha.16.3`. A different version may not work, and we have not
  tested one.
- On 30 September a phone completed real text and image turns and an artifact
  preview against an earlier build. On 6 October one desktop session on this
  branch ran four live turns, including approvals for a command and a file
  change. Files that an approved command
  creates or changes in the workspace are now listed as artifacts of its run
  (at most 32 files of up to 10 MiB, never through a link, never a file with
  more than one hard link and never under `.git`; in a workspace with more than
  20,000 files, or more than 20,000 folders, links and other entries, none are
  listed).
- If Codex is missing, signed out or incompatible, the gateway reports
  `codex_unavailable`. NivKode's status line cannot tell these apart.
- The gateway hides the Codex program's own error output.

The Codex adapter source and [provider guide](providers.md) describe the supported boundary.

## Things that behave differently from what you might expect

- **Undo refuses rather than overwrites a file you changed afterwards.**

### Runs and reviews

- **An unknown outcome stays unknown.** If the gateway or Codex restarts
  mid-run, or a Codex request times out or loses its connection, the run is
  marked "Outcome unknown". NivKode does not retry it and cannot find out what
  the provider did. Check your workspace, then decide. A local-model request
  that times out is marked failed instead.
- **When the gateway takes new messages again.** After the gateway or Codex
  restarts, or when Codex refused to start the turn, the gateway accepts new
  messages in that conversation, and the old run keeps its "Outcome unknown"
  label. After a timeout or a lost connection while the gateway keeps running,
  it refuses new messages in that conversation until it restarts. Our tests of
  this used a fake provider.
- **The desktop follows the gateway.** While the gateway may still be running
  the turn, **Send** stays off in that conversation and the notice says so;
  press **Check again** later, or start a new conversation. Once the gateway
  knows the run ended, **Send** comes back, and the notice keeps "Outcome
  unknown" and says the run is no longer running. Other conversations are not
  affected.
- **The review card reports; it does not verify.** It lists changes, diffs and
  approval requests that the provider reported. It does not run tests, prove
  the code is right or undo changes. "Test results" are guessed from commands
  whose text looks like a test and that returned an exit code.
- **Decline carries no text.** It declines the request (on the phone the button
  is **Reject**). Say what you want changed in your next message. The phone has
  no **Decline and stop**.
- **Codex runs read-only, with no network.** Codex cannot fetch packages or
  call services from its sandbox, and it cannot write without your approval.
  Approval cannot be turned off: the desktop has no such setting, and the
  gateway refuses a message sent without it (`owner_approval_required`).
- **Some repositories are refused for Codex.** A project `.codex` folder with
  executable settings blocks Codex runs in that workspace until you opt it in
  by ID (`codex_project_config_workspaces`).
- **Pending approvals go stale on restart.** If the gateway or Codex restarts
  while a request is waiting, the request can no longer be answered, and a
  late answer is refused rather than reported as delivered. The desktop shows
  a request whose run has ended as no longer waiting, without decision
  buttons. Send the task again if you still want it done.
- **Approval requests close when their turn ends.** When Codex settles a
  request itself, or the turn completes or is interrupted, the request leaves
  the pending list.
- **A large burst can make every conversation wait.** While the gateway
  catches up on a large backlog of Codex events, every conversation waits,
  including new approval cards and Stop confirmations. On a slow disk this
  can take tens of seconds. Nothing is lost while it catches up.
- **Run one gateway per state directory.** A second gateway on a state
  directory that another gateway is already serving, on any port, refuses to
  start and names the process that holds it. Stop the other one first.
- **Model output needs review.** A completed run does not mean the answer is
  correct.

### Local models

- Replies appear all at once when the model finishes. There is no streaming.
  A local request times out after 180 seconds.
- The first reply after switching to a local model that is not loaded yet
  includes loading it, which can take several seconds. The desktop shows this
  as its own step, "Starting the local model".
- If a local model returns an empty reply, NivKode sends the same request
  again, at most twice, before the run fails. A reply that keeps stopping at the
  length limit is returned as far as it got, ending with "[This answer hit the
  local model's length limit and may be incomplete.]"
- The default route, `code.explain`, often tries to read workspace files
  instead of answering about code you pasted, and can tell you that a file is
  missing. When a message looks like pasted code and **Use** points to a local
  model, the desktop shows a hint under the message box: "Local models often
  misread pasted code. Describe the change in words, or name the file you
  mean." If Codex is signed in, the hint also offers to use Codex for that
  conversation.
- Quality depends on the model. Small models are often wrong.
- The order of models in a bundled route comes from a small check: eight
  prompts per route, scored by keywords, run once. It is not a ranking of
  answer quality.
- **Local hands need a Git repository.** Ollama can propose file edits, shown
  in approval cards. Approved file changes can be undone from that turn's
  review while the files still match the applied result; Undo refuses if a
  file changed afterwards. Approved project test and build runners execute
  inside bubblewrap. Commands are refused when bubblewrap is unavailable or
  the workspace is outside a Git repository. The receipt labels the model
  `local · <model>` and reports each run as `ran N · exit X`. Local models can
  also read some workspace text files through two read-only tools. The file
  listing only works in a workspace with 64 files or fewer, and files over
  32 KiB are refused. The name filter is not a secret scanner. See
  [Privacy and security model](privacy-and-security-model.md).
- Tool use depends on the model. In an earlier local-model check, `qwen2.5:3b` listed and
  read files, and `qwen2.5-coder:3b` printed the tool call as text instead of
  running it. That check used one machine and a handful of prompts.
- Doctor currently reports a failure if Ollama is not running or the checked
  model is missing, even if you only plan to use Codex.
- A local run has no provider session and no delivery signal, so the roster
  shows `UNKNOWN` for its session and `unknown` for its delivery.

### Notes, roster and history

- Notes are plain text up to 4,000 characters, attached to a run or an
  artifact. There are no conversation-wide or file-line notes. They are not
  encrypted and are not in evidence exports.
- Artifact notes need an artifact, and only Codex runs create artifacts.
- You cannot delete a conversation or a run from the app. You can delete a note.
  To erase your history, stop the gateway and delete its state directory.
- The desktop shows notes in the review card of the latest run only.
- The conversation list shows the 100 most recently updated conversations in a
  workspace. Older ones stay in the database but are not listed. A
  conversation view shows up to 500 messages and 200 runs.
- The worker roster lists recorded runs. It is not a live view, and it does not
  list sessions started outside NivKode. Its branch is the branch recorded when
  the conversation was created.

### Desktop client and Director panel

- Reloading the desktop page disconnects it. Run `nivkode open` again.
- A message queued while offline lives in that tab only. Closing the tab loses
  it.
- The **Director** button appears only when the gateway is set up for a
  separate local service that NivKode does not include, so a default install
  does not show it. When it is set up, the page checks the panel every 3
  seconds while you are connected.
- The desktop follows your system light or dark setting. The colour palette,
  reading font and text size are in the sidebar's display settings.
- Pairing takes two commands: `nivkode-gateway pair-code <gateway.json>` prints
  the one-time code, then `nivkode pair <ONE_TIME_CODE>` pairs the CLI. The
  desktop hint should show both complete commands. See
  [Troubleshooting](troubleshooting.md).

### Setup and operations

- The gateway prints almost nothing by default. Start it with `RUST_LOG=info`
  to see startup and Codex messages.
- The uninstaller never follows a symbolic link: a link, and anything inside a
  linked folder, is left in place and reported. If `~/.local/bin` is itself a
  link, remove the three `nivkode` programs there yourself.
- The systemd user unit is a template. It is not enabled by the installer, and
  its sandbox settings have not been checked under a real user service manager.
- Pairing, tokens and the admin routes work as described in
  [Privacy and security model](privacy-and-security-model.md#where-the-protections-stop).
  The written security review predates several features.
- Evidence capture and replay are tested on a synthetic fixture only. Nothing
  here shows phone-side capture.

## How to report a problem

Open an issue from the templates, and leave out tokens, pairing codes,
configuration files and conversation data. For a suspected vulnerability, use
the repository's private security reporting, as described in `SECURITY.md`, and
not a public issue. See [Troubleshooting](troubleshooting.md) for common
failures.
