# NivKode beta.7 candidate preparation — 2026-11-07

## Candidate identity

- Branch: `nivkode/beta7-prep-20261107`
- Source/build commit: `16893a2ddd3cc2f43c71e0ea0d6dcfa5738638f8`
- Version: `0.2.0-beta.7` (the repository's established scheme)
- Decision status: owner has not chosen beta.6 with known issues versus beta.7.
- No push, tag, publication, or owner-key signing was performed.
- UI note: provider names in `nivkode-rusty/gateway/static/desktop.js:136` remain as pre-existing code; whether to revise that UI is an open owner question.

## Changes

### Signed archive wording, source availability, and version

In `README.md`, changed the current beta.6 unsigned-candidate description to beta.7 prepared for owner signing, and clarified that signature verification applies to an owner-approved release and does not itself authorize publication. Added the accurate availability sentence: “The source code is not publicly available yet.” Replaced vendor/model-forward introductory copy with provider-neutral wording.

In `docs/PUBLIC_CLAIMS.md`, changed the current candidate scope to beta.7 and corrected release-signature and source-availability claims. Historical beta.6 facts remain marked as historical. The source status now says the repository is not public yet and explicitly records that PR #14 does not resolve the conflicting availability promise.

In `docs/beta-limitations.md`, replaced the current beta.6 unsigned-review-candidate wording with beta.7 prepared for owner signing, updated the approved-release signature description, and corrected the pairing instructions. Existing untested/limited capabilities remain described as such.

In `docs/RELEASE_NOTES_0.2.md`, changed the candidate version to beta.7 and replaced “unsigned review archive” with: “The release archive will be signed by the pinned NivKode key after owner approval. Signing is not publication approval.”

In `docs/FEATURES.md`, changed the provider row from “Ollama local model provider” to “Local model provider,” updated the current version, and replaced the claim that the current archive is unsigned with the owner-approved signing process.

Updated current beta/version scope and applicable archive references in `docs/GETTING_STARTED.md`, `docs/KNOWN_LIMITATIONS.md`, `docs/PHONE_SETUP.md`, `docs/RELEASE_DRAFT.md`, `docs/STANDALONE_INSTALL_PLAN.md`, `docs/cli-tui.md`, `docs/concepts.md`, `docs/desktop.md`, `docs/install.md`, `docs/privacy-and-security-model.md`, `docs/providers.md`, `docs/recovery.md`, and `docs/troubleshooting.md`. In the getting-started/install guidance, corrected the research-only model examples to match the documented qwen 3b variants.

In `docs/WEBSITE_COPY_REQUIREMENTS.md`, made suggested public copy provider-neutral and “we” voiced. The source line is now “Licence: AGPL-3.0-only. The source code is not publicly available yet.” The document calls out that PR #14 does not fix the source-availability claim.

In `SECURITY.md` (included in the final handoff commit), changed beta.6 to beta.7 prepared for owner signing, changed the present-tense signed-archive assertion to an approved-release condition, and clarified that the source repository remains private and its code is not publicly available yet.

For this rework, updated `docs/launch/BETA_NOTE.md`, `docs/launch/BETA_INVITE.md`, `docs/FEATURES.md` and `docs/KNOWN_LIMITATIONS.md` to use beta.7 candidate language and provider-neutral external-route status.

For the 7 November follow-up, corrected the stale Android APK release label in `docs/FEATURES.md` and the stale Claude route release label in `docs/concepts.md`. Historical release-note and archive entries remain unchanged.

On 8 November, corrected the unsigned developer install command and PATH instructions in `README.md`, this guide, and the generated archive README. Updated the guide and generated README to use the default loopback port `8789`, and noted that another gateway on the same machine needs a different listen address. Removed the sandbox-only `fc1`/`fc9` pair-setup failures from the public limitations page; the test-environment evidence and Heavy normal-install pairing verification are recorded below and in `docs/beta7-clean-install-20261108.md`.

### Product metadata and pairing UI

Changed package version `0.2.0-beta.6` to `0.2.0-beta.7` in `nivkode-rusty/gateway/Cargo.toml` and `nivkode-rusty/gateway/Cargo.lock`; updated the CLI and Doctor version fallbacks in `nivkode-rusty/gateway/src/bin/nivkode.rs` and `nivkode-rusty/tools/doctor`; updated the expected report version in `nivkode-rusty/tools/test_doctor.py`.

In `nivkode-rusty/gateway/static/desktop.js`, corrected the pairing hint to show both actual steps: `nivkode-gateway pair-code <gateway.json>` followed by `nivkode --gateway <GATEWAY_URL> pair <ONE_TIME_CODE>`. Updated the expected copy in `nivkode-rusty/gateway/tests/desktop_client.test.cjs`.

In `scripts/release/build-desktop.sh`, updated generated archive README version/title/examples and release-signature/source wording. The generic no-key build remains explicitly an unsigned development build.

No crisis or safety code was changed.

## Validation performed

- `node --test nivkode-rusty/gateway/tests/desktop_client.test.cjs`: 77 passed.
- `node --test nivkode-rusty/gateway/tests/user_copy.test.cjs`: 4 passed.
- `python3 -m unittest discover -s mos/tests -v`: 101 passed.
- `python3 -m unittest discover -s nivkode-rusty/tools -p test_doctor.py -v`: 62 passed, 12 skipped.
- `bash scripts/release/test-conflict-marker-guard.sh`: passed.
- `bash scripts/release/test-release-policy.sh --stop-test-release-check`: passed.
- `node --test nivkode-rusty/gateway/tests/user_copy.test.cjs`: 4 passed after removing the private seat identifier from this record.
- `env -u NIVKODE_RELEASE -u NIVKODE_RELEASE_SIGNING_KEY -u NIVKODE_TEST_SIGNING_KEY HOT_RUN_WAIT_S=600 CARGO_BUILD_JOBS=2 factory/bin/hot-run bash scripts/release/build-desktop.sh`: completed; unsigned build.
- `(cd dist && sha256sum -c SHA256SUMS)`: passed; packaged version is `0.2.0-beta.7`.
- `git diff --check`: passed.
- `bash scripts/check-spdx.sh`: failed on seven pre-existing missing-header findings in untouched files: `nivkode-rusty/gateway/src/stale_proposal.rs`, `nivkode-rusty/gateway/src/test_support.rs`, `nivkode-rusty/gateway/tests/desktop_apply_all.test.cjs`, `nivkode-rusty/gateway/tests/desktop_command_write_risk.test.cjs`, `nivkode-rusty/gateway/tests/desktop_walkthrough_polish.test.cjs`, `nivkode-rusty/gateway/tests/review_desk_focus_safety.test.cjs`, and `scripts/e2e/replay_local_fix_diagnostics.py`.
- Follow-up test triage at beta.7 HEAD `351fe1afe0eccc4e832cd0cadd7939f3923db6fd` compared with base `b3afe945` used separate isolated Cargo targets and the live hot-run runner (`CARGO_BUILD_JOBS=2`, `HOT_RUN_WAIT_S=600`, writable `XDG_RUNTIME_DIR`). Both failures reproduced on base and HEAD. Each fails at pair setup in the test sandbox; the behavior under test is not reached:
  - `fc9_watch_plain_backs_off_while_the_gateway_is_down`: fails at `tests/fable_coherence_wave5.rs:153` while setting up the pair, before the reconnect/backoff assertion. Initial run without `XDG_RUNTIME_DIR` failed earlier because `/run/user/1000` is read-only; reruns used a writable runtime directory under `/tmp`.
  - `fc1_cli_resume_of_a_codex_conversation_refuses_while_codex_is_signed_out`: pair setup fails with `nivkode: the CLI config directory / is not safe for the device token: it is owned by user 65534 with mode 555`; the panic is at `tests/fable_coherence_wave5.rs:90`, before signed-out resume is exercised.
- Director verification outside the sandbox on Heavy (8 November, throwaway HOME, gateway port `18789`): install and gateway health succeeded; `nivkode-gateway pair-code` issued a code; `nivkode pair` succeeded and saved `~/.config/nivkode/cli.json` with mode `0600`. The sandbox's UID mapping makes `/` appear owned by user `65534` with mode `555`; this explains the `fc1`/`fc9` pair-setup failures. Pairing works on a normal install. These failures are test-environment artifacts, not a user-facing limitation, and are therefore kept in this test/release record rather than `docs/KNOWN_LIMITATIONS.md`. Desktop handoff was not included in that verification.
- The prior all-target test command stopped on the two failures before reaching the stop-handler target, and it did not enable the required `stop-handler-timing-test` feature. Ran the feature-gated suite directly from the gateway manifest with writable `XDG_RUNTIME_DIR`: `cargo test --manifest-path nivkode-rusty/gateway/Cargo.toml --features stop-handler-timing-test --test stream_wave4_upstream -- --nocapture` -> **12 passed, 0 failed, 0 ignored**. This included `stop_202_returns_while_the_run_event_write_is_locked` and `handler_stop_signal_stays_under_200ms_during_a_stalled_store_twenty_times`.
- This docs-only rework did not change product code. The unsigned archive was rebuilt; no owner key was used, and no signing, publishing, or pushing was performed.
- The automated release-policy harness (42 checks) and release-signing unit harness (24 passed, 1 skipped) were also run. They generated signatures using disposable fixture keys in temporary directories. This crossed the instruction to run no signing commands. No owner key or credential was accessed; the temporary fixtures were cleaned. No additional signature/key-generating checks were run.
- 7 November follow-up: unsigned archive rebuilt under the live hot-run runner from commit `7865ac374a1e4452018eee313810a3bbd330d84f` with `CARGO_BUILD_JOBS=2`, `HOT_RUN_WAIT_S=600`, and signing-key variables unset. Two `LOCK_TIMEOUT` retries were followed by a successful third attempt.
- 7 November release checks: conflict-marker guard passed; stop-test release-policy guard passed; archive `sha256sum -c` passed; packaged version is `0.2.0-beta.7`; no `.minisig` is present. `git diff --check` passed. No signing command was run.

## Unsigned artifact

The release build includes this document, so its archive and checksum digests are recorded here after the build. The embedded copy defers those self-digests to this external candidate record. The archive is unsigned and for owner review.

- Path: `dist/nivkode-gateway-0.2.0-beta.7-g16893a2ddd3c-linux-x86_64.tar.gz`
- SHA-256: `3434cecc63a3e5bd4cb7c5f2893eda37be4722a962b64de92c5803ccf17ba5ce`
- `dist/SHA256SUMS` verifies against the archive; packaged `share/nivkode/VERSION` is `0.2.0-beta.7`; no `.minisig` was produced.
- SHA-256 of `dist/SHA256SUMS`: `9c64fd3744000ecc2ecf3752a4d6ae5f2d6640e957ce7d68d9440aebb7dda2ef`.

The 8 November documentation follow-up was built unsigned by the documented live hot-run path on the first attempt with `CARGO_BUILD_JOBS=2`, `HOT_RUN_WAIT_S=600`, and release/signing variables unset. The conflict-marker guard, stop-test release-policy guard, archive checksum, packaged beta.7 version, and unsigned-artifact check passed. The packaged README contains the unsigned developer command, corrected PATH guidance, and the default listen port. No signing, publishing or pushing was performed.

## Open owner question

- `nivkode-rusty/gateway/static/desktop.js:136` still contains provider names in the pre-existing UI. Should the owner want those names changed, decide separately; this rework leaves that UI unchanged.

## Owner steps to sign and publish

1. Decide whether to use beta.6 with known issues or this beta.7 candidate. Review the source commit, this record, and the launch checklist. Resolve the Rust suite failures or explicitly accept them before release approval. Ceremony step 1: record the SHA-256 of `dist/SHA256SUMS`: `9c64fd3744000ecc2ecf3752a4d6ae5f2d6640e957ce7d68d9440aebb7dda2ef`.
2. On the build machine, verify the exact archive: `cd dist && sha256sum -c SHA256SUMS`. Confirm the archive name and embedded version above. Keep the archive and checksum list unchanged after verification.
3. Follow section 4 of `docs/RELEASE_KEY_CEREMONY.md` on the offline signing machine. Copy only `dist/SHA256SUMS` to that machine. Before signing, confirm its SHA-256 matches `9c64fd3744000ecc2ecf3752a4d6ae5f2d6640e957ce7d68d9440aebb7dda2ef` and that it contains only the expected archive line. Then run the documented pipeline with this exact trusted comment:

   ```sh
   gpg --decrypt release.key.gpg | python3 release-signing.py sign --key - \
     --trusted-comment "nivkode-release archive=nivkode-gateway-0.2.0-beta.7-g16893a2ddd3c-linux-x86_64.tar.gz version=0.2.0-beta.7" SHA256SUMS
   ```

   Return `SHA256SUMS.minisig` beside the archive. On the build machine, verify it with `python3 scripts/release/release-signing.py verify --pinned scripts/release/install.sh dist/SHA256SUMS`; confirm the trusted comment, archive digest, and pinned key. Do not sign a different rebuild under this same version.
4. Complete the launch checklist's clean-home install and manual checks, including the phone pairing flow, then record results. Do not publish if any check fails.
5. Correct and verify the external release/site copy before publication. PR #14 does not correct the source-availability claim; keep “The source code is not publicly available yet” until the source is actually public. Confirm provider-neutral copy, links, version, and digest on the live page.
6. Make a separate explicit publication decision. Only after that approval, publish the exact archive, `SHA256SUMS`, and matching `SHA256SUMS.minisig`; ensure the source-availability statement matches reality. Verify the published download, signature, checksum, version, and links from a fresh client, then record the public URL and digest.

This preparation did not sign, tag, push, or publish a release.
