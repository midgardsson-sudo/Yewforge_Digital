# beta.7 clean-home install smoke test — 2026-11-08

## Result

**Sandbox run:** install and gateway health passed; pairing was blocked by sandbox filesystem ownership. **Normal-install follow-up:** pairing passed; desktop handoff was not verified.

- Worktree branch: `nivkode/beta7-prep-20261107`; tested source HEAD: `873cd1b3b6668d1da423ac39c6005f09a3ec281c`.
- Artifact: `dist/nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz`.
- SHA-256: `e7ed9c26aa561c603e66e87bb63884efd930f78d08cdd057d089eb73c8873667`; matches `docs/beta7-candidate-20261107.md`.
- Install used a new empty HOME at `/tmp/nivkode-beta7-home.gPH9pY`. No real `~/.config`, credentials, signing keys, network, signing, publishing, pushing, or source changes were used. The archive and code were not modified.
- No build artifact was produced.

## Steps and evidence

Commands below ran from the worktree unless the command changes directory. The generated one-time pairing code is omitted because it is a credential.

1. Checked identity and artifact:

   ```sh
   git status --short --branch
   git rev-parse HEAD
   sha256sum dist/nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz
   ```

   Result: clean branch `nivkode/beta7-prep-20261107`, HEAD `873cd1b3b6668d1da423ac39c6005f09a3ec281c`; archive digest exactly matched the candidate record.

2. Created the empty HOME, unpacked the archive, and placed the archive and a checksum file alongside the unpacked directory as the install command expects:

   ```sh
   TASK_HOME=$(mktemp -d /tmp/nivkode-beta7-home.XXXXXX)
   mkdir -p /tmp/nivkode-beta7-unpack
   tar -xzf dist/nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz -C /tmp/nivkode-beta7-unpack
   (cd dist && sha256sum nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz) > /tmp/nivkode-beta7-unpack/SHA256SUMS
   cp dist/nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz /tmp/nivkode-beta7-unpack/
   ```

   The checksum output was `e7ed9c26aa561c603e66e87bb63884efd930f78d08cdd057d089eb73c8873667  nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz`.

3. Followed the archive README's install command, adding the unsigned developer flag documented later in the full guide (the omission is listed below):

   ```sh
   cd /tmp/nivkode-beta7-unpack/nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64
   HOME="$TASK_HOME" bash share/nivkode/install.sh --insecure-allow-unsigned ../nivkode-gateway-0.2.0-beta.7-g7865ac374a1e-linux-x86_64.tar.gz ../SHA256SUMS
   ```

   Result: exit 0. Installer printed the two `WARNING: INSECURE INSTALL` lines, installed beta.7 under the temporary HOME, reported the example config and disabled systemd unit, and warned that `$HOME/.local/bin` was not on PATH. It suggested `export PATH="$HOME/.local/bin:$PATH"` for this terminal and adding it to a shell profile for new terminals.

4. Followed the README config snippet (also present in `docs/install.md`):

   ```sh
   mkdir -p "$HOME/workspace" "$HOME/.local/share/nivkode"
   cp "$HOME/.config/nivkode/gateway.example.json" "$HOME/.config/nivkode/gateway.json"
   python3 - "$HOME/.config/nivkode/gateway.json" "$HOME" <<'PY'
   import json, pathlib, sys
   path, home = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
   data = json.loads(path.read_text())
   data["listen"] = "127.0.0.1:18789"
   data["state_dir"] = str(home / ".local/share/nivkode")
   data["workspaces"] = [{"id": "workspace", "name": "Workspace", "path": str(home / "workspace")}]
   path.write_text(json.dumps(data, indent=2) + "\n")
   PY
   chmod 600 "$HOME/.config/nivkode/gateway.json"
   ```

   Result: exit 0; config created under the temporary HOME.

5. Ran the documented Doctor check with the temporary HOME and PATH:

   ```sh
   export HOME="$TASK_HOME" PATH="$TASK_HOME/.local/bin:$PATH" NIVKODE_GATEWAY_CONFIG="$TASK_HOME/.config/nivkode/gateway.json"
   nivkode-doctor
   ```

   Result: exit 0. PASS: Cargo, rustc, Codex, Ollama; loopback-only bind; config parse and permissions; port available; state directory; token store not yet created; pinned Ollama model installed; Tailscale not forwarding port. WARN: Java 26 detected instead of verified Java 17, and Android SDK not configured. Per the guide these Android build warnings do not matter for this package.

6. Started the gateway as documented:

   ```sh
   RUST_LOG=info nivkode-gateway serve "$HOME/.config/nivkode/gateway.json"
   ```

   Startup output included `WARN ... Codex app-server is unavailable at gateway startup ...` and `INFO ... NivKode gateway listening address=127.0.0.1:18789`. Health check:

   ```sh
   curl --fail --silent --show-error http://127.0.0.1:18789/health
   ```

   Output: `{"codexConnected":false,"gatewayInstanceId":"a754b611-b579-45b8-8ef1-ce78edfe3024","status":"ok"}`.

7. Attempted the documented pairing command in the sandbox. The CLI rejected the token destination before saving anything:

   ```sh
   nivkode --gateway http://127.0.0.1:18789 pair YOUR_ONE_TIME_CODE
   ```

   Output: `nivkode: the CLI config directory / is not safe for the device token: it is owned by user 65534 with mode 555; each directory on the way to it must be owned by you or root and not writable by others, so nothing was saved`.

   Retried with both `HOME="$TASK_HOME"` and `XDG_CONFIG_HOME="$TASK_HOME/.config"`; same error. A newly issued pairing code also failed with the same error. `nivkode open` then reported `nivkode: not paired; run `nivkode pair <one-time-code>` first`. This result came from the sandboxed environment and does not establish a normal-install product failure.

8. Stopped the foreground gateway with Ctrl-C. The process exited; logs had repeated `Codex app-server restart failed; will retry ... response channel closed` warnings while running. No lingering gateway process was observed from the tool session.

## Follow-up verification and documentation defects

On 8 November, the Director verified the install outside the sandbox on Heavy
with a throwaway HOME and gateway port `18789`: installation succeeded, the
gateway health check passed, `nivkode-gateway pair-code` issued a code, and
`nivkode pair` succeeded and saved `~/.config/nivkode/cli.json` with mode
`0600`. The earlier `65534`/`555` error is a sandbox artifact caused by the
test environment's UID mapping. The `fc1` and `fc9` failures have the same
environmental cause; their test bodies were not reached. Pairing works on a
normal install. Desktop handoff remains unverified.

The following documentation defects were found in the sandbox run and have
since been corrected:

1. The README and full guide now show the developer-only unsigned install command with its checksum file, warning, and separation from the signed-release path.
2. The full guide now tells users to add the installed binary directory to PATH in each terminal, including the second terminal used for health and pairing commands.
3. The full guide now identifies `8789` as the default listen port and explains that another gateway on the same machine needs a different listen address.

## Launch blockers and limits

- Pairing succeeded on a normal install in the Director's 8 November verification. The sandbox failure is not evidence of a user-facing pairing limitation.
- Gateway installation and health endpoint passed. No provider turn, browser handoff, desktop interaction, or offline behavior was validated.
- This was an unsigned developer-path test; the warnings mean the publisher was not verified. No signing or owner key use occurred.
