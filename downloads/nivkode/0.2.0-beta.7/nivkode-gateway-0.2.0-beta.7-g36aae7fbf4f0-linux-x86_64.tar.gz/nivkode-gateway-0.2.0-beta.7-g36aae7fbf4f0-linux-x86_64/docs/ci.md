# GitHub Actions CI

The CI workflow uses standard `ubuntu-latest` GitHub-hosted runners. Pushes to
`launch/**` run the gateway, desktop, MOS/doctor, and SPDX jobs. Use
**Actions → NivKode CI → Run workflow** to start those checks manually and to
include the Android unit-test job. Android tests are not run on pushes.

## Private-repository allowance

GitHub includes a monthly allowance of standard-hosted runner minutes for
private repositories. The allowance belongs to the account or organization
that owns the repository and is shared according to its plan: GitHub Free
includes 2,000 minutes/month; Pro and Team include 3,000; Enterprise Cloud
includes 50,000. Minutes reset at the start of each billing cycle. Standard
Linux runner minutes count at the Linux rate. These allowances and billing
rules can change; check the owner's current plan and [GitHub Actions billing
documentation](https://docs.github.com/en/billing/concepts/product-billing/github-actions).

## Check usage and keep overage disabled

The repository owner can check current usage in GitHub under **Settings →
Billing and licensing → Usage** (or the account/organization billing page),
then review Actions minutes and cache storage. Repository run history is
available under **Actions**.

Before enabling this workflow, the owner must verify **Settings → Billing →
spending limit** and keep paid Actions overage disabled. If included minutes
are exhausted, runs should stop until the next billing cycle or until the
owner makes an explicit billing decision. Do not raise the spending limit to
allow this CI to continue automatically.
