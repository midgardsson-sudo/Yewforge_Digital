# CLI and terminal view

The `nivkode` command talks to the gateway with your paired device token. It
defaults to `http://127.0.0.1:8789`. Use `--gateway URL` or the
`NIVKODE_GATEWAY` environment variable for another address. After you pair,
the CLI remembers the address you paired with.

## Pair once

On the gateway computer, ask for a one-time code, then use it:

```sh
nivkode-gateway pair-code CONFIG
nivkode pair CODE
```

The code works once and expires after 10 minutes. The CLI keeps its device
token in `~/.config/nivkode/cli.json` (or under `$XDG_CONFIG_HOME`). It refuses
to run if other users can read that file, and pairing refuses to write it into
a `nivkode` config folder that is a symbolic link. Keep it private.

## Commands

| Command | What it does |
|---|---|
| `nivkode status` | Shows the gateway state, whether Codex is installed and signed in, the installed Ollama models, and the engine a new conversation starts on |
| `nivkode list` | Lists conversation IDs and titles in a workspace |
| `nivkode show CONVERSATION` | Prints one conversation |
| `nivkode rename CONVERSATION "New title"` | Renames it (1 to 120 characters) |
| `nivkode chat "task"` | Starts a new conversation and streams the run |
| `nivkode run "task"` | Same as `chat`. Add `--live` for the terminal view. |
| `nivkode resume CONVERSATION "task"` | Sends a new task in an existing conversation, on the engine it already uses |
| `nivkode watch CONVERSATION` | Follows a conversation, and keeps following after a reconnect |
| `nivkode open` | Opens the desktop client in your browser through a one-use handoff |
| `nivkode doctor` | Runs the read-only setup checker (also installed as `nivkode-doctor`) |
| `nivkode approve <conversation> <request>` | Accepts one pending local request by its id; accepts only, with no prompt or decline |

Examples:

```sh
nivkode status
nivkode run "Summarize this workspace" --live --route text.general
nivkode watch CONVERSATION_ID
nivkode watch CONVERSATION_ID --plain
nivkode --palette high-contrast watch CONVERSATION_ID
```

Useful options:

- `--workspace ID` picks a workspace. Without it the CLI uses the first
  workspace in the gateway config.
- `--route` takes `text.general`, `code.explain` or `codex`. Without `--route`,
  a new conversation starts on a local model and `resume` keeps the
  conversation's engine. `--route codex` sends that one conversation to Codex.
  See [Which engine a conversation uses](#which-engine-a-conversation-uses).
- `--json` prints machine-readable JSON on standard output for `pair`,
  `status`, `list`, `show`, `rename`, `chat`, `run` (not with `--live`) and
  `resume`. Messages, such as the engine line, and errors go to standard error.
- `--palette` takes `default`, `cb-safe`, `tritan`, `high-contrast` or `none`
  (also `NIVKODE_PALETTE`). `--no-color` on `run` and `watch` is the same as
  `none`.
- `--plain` on `run` and `watch` prints a timestamped event log.

## Terminal view

`run --live` and `watch` open a full-screen view of the conversation. Press
`q` or `d` to leave it, `r` to rename the conversation, the arrow keys to
scroll and `Tab` to move between panes. For a conversation that has no engine
yet (no run, and no engine switch from the desktop or the app), the view says
"No engine selected".

## Which engine a conversation uses

New conversations start on your computer. Codex is used only when you choose it
for a conversation.

- **`chat` and `run` without `--route`** use the first bundled local route
  whose model is installed: `code.explain`, then `text.general`. If neither
  route has an installed model, they use the first model Ollama reports. They
  never choose Codex. The engine is chosen before the conversation is created.
- **No local model installed:** `chat` and `run` without `--route` create
  nothing and send nothing. They print the choices and exit with status 2:

  ```
  nivkode: no local model is installed, so no engine was chosen and nothing was sent.
  Choose one:
    install a local model: ollama pull qwen2.5:3b, then run this again
    or use your Codex account: add --route codex (Codex sends this conversation off this computer)
  ```

  When the gateway reports where Codex sends conversations, the last line names
  it, for example `(Codex sends this conversation to OpenAI)`. When Codex is not
  signed in, the last line reads `or sign in to Codex with codex login, then add
  --route codex (Codex then sends conversations off this computer)`.
- **`--route codex`** chooses Codex for that one conversation. A later
  conversation does not inherit the choice. It works only while the gateway
  reports Codex as signed in. Otherwise nothing is created or sent, and the CLI
  exits with status 2:

  ```
  nivkode: Codex is not signed in on the computer running NivKode, so nothing was sent.
  Run codex login there, then try again, or leave out --route codex to use a local model.
  ```

  With no local model installed, the second line ends `or install a local
  model: ollama pull qwen2.5:3b` instead.
- **`resume` without `--route`** continues on the engine the conversation
  already uses: the route or model of its latest run, or the engine an engine
  switch in the desktop or the app recorded. That includes Codex. A
  conversation with no run and no engine switch starts like a new one. With
  `--route`, `resume` uses the engine you name, with the same Codex check.
- **The engine line.** Before anything is sent, `chat`, `run` and `resume`
  print the engine on standard error:
  - `Engine: code.explain on this computer` for a route, or
    `Engine: MODEL on this computer` for a model;
  - `Engine: Codex. Codex sends this conversation to OpenAI.` The destination
    is the one the gateway reports for your Codex account, such as `OpenAI` or
    `Amazon Bedrock`. If the gateway reports none, or a value that is blank,
    longer than 40 characters or contains a line break or another control
    character, the line reads `Engine: Codex. Codex sends this conversation off
    this computer.`

`--route text.general` and `--route code.explain` use the local routes, which
need Ollama running with at least one of the route's models installed. The CLI
cannot pick an Ollama model by name; it names one only when no route has an
installed model. The desktop can pick any model. See [Providers](providers.md).

If the gateway refuses Codex because it is not signed in, the CLI says: "Codex
is not signed in on the computer running NivKode. Run codex login there, then
try again, or keep using a local model."

The final output shows the provider, model and any fallback that were observed.

## Status

`nivkode status` prints four lines, for example:

```
Gateway: ok
Codex (external · Tested, experimental): installed yes · signed in no
Ollama (local · Tested) models: qwen2.5:3b
New conversations: code.explain (local)
```

"Signed in" comes from the gateway's own check of your Codex account. "No"
includes a Codex helper that is running but signed out, and a gateway that does
not report the check. "New conversations" names the local route or model a new
conversation would start on, or reads `no local engine (choose with --route)`.
With `--json`, `codex.signedIn` and `newConversations` (`provider`, `route` and
`model`, or `null`) report the same.

## Exit status

- `0`: the command finished.
- `1`: something failed, such as the gateway, pairing or the run.
- `2`: nothing was sent because you need to choose an engine first (see
  above), or the command line was mistyped.

## Approvals

The terminal cannot answer a Codex approval request. Terminal runs start
read-only. If Codex needs approval, open the same conversation in the desktop
client (`nivkode open`) and answer there. If Codex asks a question instead,
the desktop cannot answer it in 0.2.0-beta.7: open the conversation there and press
**Stop** to end the turn. If you use the Android app, you can answer the
question there instead. See
[Concepts](concepts.md#approvals-and-the-review-gate).

## Doctor

```sh
nivkode-doctor CONFIG
nivkode-doctor CONFIG --model NAME
```

Without a path it uses `NIVKODE_GATEWAY_CONFIG`, then
`~/.config/nivkode/gateway.json`. When you add `--model`, give the config path
first. Doctor is read-only. See [Troubleshooting](troubleshooting.md) for
recovery steps and the messages you may see.
