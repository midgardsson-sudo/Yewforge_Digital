# NivKode concepts

This page explains the words NivKode uses. The other guides assume you have
read it once. Everything here describes 0.2.0-beta.7; where
something is missing or unproven, the text says so. The full list is in
[Beta limitations](beta-limitations.md).

## At a glance

| Term | Meaning |
|---|---|
| Gateway | The program that runs on your computer, stores your data and talks to providers. It listens on loopback only. |
| Desktop client | The NivKode screen you use in your browser. The gateway serves it from `/desktop`. |
| `nivkode` CLI | The command-line client, with a live terminal view (TUI). |
| Android app | A preview client for your phone. It is built from source and is not part of the 0.2.0-beta.7 package. |
| Doctor | A read-only checker that reports problems with your setup. |
| Workspace | A folder you have listed in the gateway config. NivKode only works inside these. |
| Conversation | A saved thread of messages and runs in one workspace. |
| Run | One request sent to a provider, with a status. |
| Provider | Where a run goes: **Ollama — local model provider** or an external AI provider (e.g. Codex, Claude, Grok). Claude has a beta.7 route, but no live run is verified (**Not yet tested**); the app labels it "in development". Grok is not supported. |
| Local route | A named choice such as `text.general` that maps to a local model, with fallbacks. |
| Approval | Your decision on a change or command a provider asks to make. |
| Review gate | The desktop card where you read a run's changes and answer approval requests. |
| Artifact | A file a provider reported, registered by the gateway so you can look at it. |
| Note | Your own text, attached to a run or an artifact. |
| Worker roster | A read-only list of runs, with `UNKNOWN` where NivKode has no record. |
| Director panel | An optional chat panel for a separate local service. You can ignore it. |

## The parts

NivKode is a studio for working with AI coding tools. The desktop
client, the CLI and the Android app all talk to one gateway on your computer.
The gateway talks to Codex (through your own account) and to Ollama (local
models). It keeps its state in a SQLite database on your computer. The
local-only switch refuses external AI providers (e.g. Codex, Claude, Grok) at the gateway.

- **Gateway.** One program, `nivkode-gateway`. It keeps conversations, runs,
  notes and device records in a SQLite database in its state directory. It
  refuses to start on a non-loopback address.
- **Desktop client.** A web page served by your own gateway. It is the main
  screen for reading replies, reviewing changes and managing notes. It only
  talks to the gateway that served it.
- **CLI and terminal view.** `nivkode` can pair, list, run and watch
  conversations. See [CLI and terminal view](cli-tui.md).
- **Android app.** A native client for a phone. It needs an HTTPS address that
  you set up yourself. It is a preview; see [Beta limitations](beta-limitations.md).
- **Doctor.** `nivkode-doctor` checks configuration, permissions, the port and
  the local model. It changes nothing.

## Workspaces

A workspace is a folder on your computer that you list in the gateway config
with an ID, a name and an absolute path. Clients never send a file path to
choose a workspace; they send the ID. If an ID is not in the config, the
gateway answers `workspace_not_found`.

The desktop client lets you pick one workspace at a time. A conversation
records the workspace ID and, when the folder is a Git repository on a branch,
the branch name at the moment the conversation was created. That branch is a
note, not a live check.

## Conversations and runs

A conversation holds messages and runs. Each message you send creates a run.
Every run has a status, and the status is written to disk as it changes.

| Status shown | Gateway status | Meaning | What you can do |
|---|---|---|
| Starting | `DISPATCHING` | The gateway has recorded the request and is sending it. | Wait. |
| Accepted | `ACCEPTED` | Codex accepted the request, or, for a local model, the gateway started the Ollama request. | Wait for a reply. |
| Completed | `COMPLETED` | The provider finished. This does not mean the answer is right. | Read and check it. |
| Failed | `FAILED` | The run ended with an error. | Open the run details, then try again. |
| Interrupted | `INTERRUPTED` | The run stopped before it finished: the provider stopped the turn, or you pressed **Stop**. | Check what changed in the workspace. |
| Outcome unknown | `OUTCOME_UNKNOWN` | NivKode cannot tell whether the provider finished. | Check the conversation and workspace before you send again. |

These rules follow from this design:

- **Every send has an idempotency key.** If the same request is retried with
  the same key, the gateway returns the original record instead of sending it
  twice. If the same key is used for a different request, it answers with a
  conflict.
- **Uncertain runs are never retried automatically.** After a Codex timeout or
  lost connection, or a gateway or Codex restart, an in-flight run becomes
  `OUTCOME_UNKNOWN`. Only you decide whether to send it again.
- **History survives restarts.** The gateway stores messages and events, and
  the clients resume from the last event number they saw.
- **Nothing Codex sends is dropped while the gateway is running.** The
  gateway stores every event and request from Codex in the order Codex sent
  it, so a burst of events, even from other conversations, cannot push out the
  end of a run or an approval request. If the gateway falls behind, for
  example on a slow disk, it stops reading from Codex until it catches up.
  Codex waits, and so does every conversation: new events, approval cards and
  Stop confirmations can take tens of seconds to appear on a slow disk.
  Nothing is lost while they wait. If Codex stops, the gateway first stores what Codex had
  already sent, then marks any run Codex did not finish as "Outcome unknown".
  One exception is known: if the gateway itself exits, events still queued in
  memory (up to 4,096 messages or 16 MiB) are lost, and those runs show
  "Outcome unknown" when it starts again.
- **One active run per conversation.** While a run is starting or accepted,
  the gateway refuses a new message in that conversation
  (`idempotency_or_active_driver_conflict`). A run of unknown outcome counts as
  active until the gateway knows its driver ended: after a gateway or Codex
  restart, or when Codex refused to start the turn, the conversation takes new
  messages again and the run keeps its `OUTCOME_UNKNOWN` status. After a Codex
  timeout or lost connection, the conversation stays blocked until the gateway
  restarts. The desktop follows the same rule: **Send** is off only while the
  gateway still holds the run. The code can settle a Codex run from Codex's
  saved history, but we have not seen that work in a recorded run.

## Providers

| Provider | Status in 0.2.0-beta.7 | What it needs |
|---|---|---|---|
| Ollama local model provider | **Tested on earlier builds; live use on beta.7 Not yet tested** | Ollama running on the same computer, and at least one model installed. |
| Codex | **Tested on earlier builds (experimental); live use on beta.7 Not yet tested** | The Codex CLI installed and signed in on the computer that runs the gateway, with your own account. |
| Claude | **Not yet tested** | The beta.7 route is present, but no live run is verified. The app labels Claude "in development". |
| Grok | **Not yet tested** | Not supported. |

NivKode does not sell or pay for provider access. You sign in yourself and
follow each provider's terms. See [Providers](providers.md).

Claude has a beta.7 route, but no live run is verified (**Not yet tested**); the app labels it "in development". Grok is **Not yet tested**
and is not supported.

Local models answer questions, read workspace files, propose file edits and
propose supported project test and build commands for approval. The current
implementation and regression coverage are in `nivkode-rusty/gateway/src/local_turn.rs`,
`local_command.rs` and `nivkode-rusty/gateway/src/main.rs`. Read [Privacy and
security model](privacy-and-security-model.md) before you point a workspace at
a folder that holds private files.

## Local routes

A local route is a name for a kind of task. NivKode ships two:

| Route | First choice | Later choices, in order |
|---|---|---|
| `text.general` | `qwen2.5:1.5b` | `qwen2.5-coder:3b`, `qwen2.5-coder:7b`, `qwen2.5:3b`, `qwen3:8b` |
| `code.explain` | `qwen2.5:3b` | `qwen2.5-coder:7b`, `qwen3:8b`, `qwen2.5-coder:3b`, `qwen2.5:1.5b` |

When you pick a route, the gateway asks Ollama what is installed and uses the
first model in the list that is present. If the first choice is missing, the
run record says so (for example, "Fallback: primary model qwen2.5:3b is not
installed"). If none of the listed models is installed, the run fails and
nothing is substituted. If you name a model yourself instead of a route, that
model is used as given.

Each run keeps its route details: the route, the model chosen, the model's
digest, and any fallback reason. The desktop shows them under **Details**.

In API output, local runs show the account `local`, and the desktop shows it as
"Your computer".

Local routes only ever point at Ollama on your own computer. NivKode does not
choose a route for you from your prompt. The route, or the provider and model,
is whatever is selected next to the **Send** button.

## Approvals and the review gate

Every Codex session and turn is **read-only** with **no network access**, and
Codex has to ask before it changes files or runs a command that needs more
than that. It can run read-only commands, such as checking the current folder,
inside that sandbox without asking. The gateway sets
this each time, whatever your own Codex configuration says, and it sends
approval requests to you, never to an automatic reviewer. Approval is always
on: the desktop has no setting to turn it off (see
[Desktop client](desktop.md#review-before-workspace-changes)), and the gateway
refuses a message sent without it (`owner_approval_required`).

When Codex asks, the review gate shows the request. For each pending request
you can choose:

| Desktop button | Android button | What the gateway sends to Codex |
|---|---|---|
| Approve | Approve once | `accept`, for this one request |
| Decline | Reject | `decline`. It carries no text, so tell the agent what to change in your next message. |
| Decline and stop | (none) | `cancel`: declines and asks Codex to stop the turn |

Some facts that matter:

- While the gateway is running, every approval request Codex sends is shown
  to you, even when it sends hundreds at once. If the gateway cannot record
  one, it declines it rather than leave Codex waiting, so nothing runs without
  your approval.
- Approvals are one request at a time. NivKode does not offer "always allow".
  The review card shows each request exactly as Codex sent it, and the gateway
  accepts only one answer per request, even if two devices answer together.
- Local models can propose file edits and supported project test and build
  commands. Each change needs your approval; commands run inside bubblewrap.
- NivKode does not run tests. The "Test results" list in the review card is
  filled from commands Codex ran whose text contains words such as `test`,
  `check`, `lint` or `verify` and that finished with an exit code. If there is
  none, the card says "No test results reported for this run."
- If the gateway or Codex restarts while a request is waiting, the request is
  marked stale and can no longer be answered. Start the run again.
- The terminal client cannot answer approval requests. Use the desktop client
  or the Android app.
- Codex can also ask you a question during a run. The desktop cannot answer
  it in 0.2.0-beta.7: it shows the question, says it can't answer it, and offers
  **Stop**. If you use only the desktop, press **Stop** to end the turn. If you
  use the Android app, you can answer the question there instead.
- Local models can propose file changes for your approval.

## Artifacts

An artifact is a file that Codex reported while working: an image it saved or
a file it changed, inside the workspace. The gateway registers each one with a
name, media type, size, SHA-256 and where it came from. You can open text,
JSON, XML and source files, and PNG, JPEG, WebP, GIF and BMP images, up to 5 MiB.
Source files are always shown as plain text, never run as a web page. SVG files,
archives and other binaries are not shown. Files outside the workspace, links
that point out of it, files with more than one hard link and files over 5 MiB
are not served. A file with more than one hard link is never registered
either, because it may be a file from outside the workspace.

Local-model runs produce no artifacts. The gateway registers artifacts when the
review card loads them, so they appear once the card has been opened.

## Notes

A note is your own text, saved by the gateway and attached to either a run or
an artifact. You write it, you can edit or delete it, and it is limited to
4,000 characters.

- **Notes are not prompts.** Nothing sends a note to a provider on its own.
  The button **Add to message** copies a note into the message box with a line
  such as `[Context from note on run 1a2b3c4d, 6 Oct 2026, 09:14]` above it.
  You read it, change it if you like, and send it yourself.
- **Notes stay on your gateway.** They are stored as plain text in the
  gateway database and are not included in evidence exports.
- **Editing keeps the original time.** An edited note still shows the time it
  was first saved.
- The desktop shows notes in the review card of the latest run. The Android
  app has a Notes tab in its review screen.

## Worker roster

The **Workers** view lists the runs the gateway has recorded for the current
workspace. It is read only. It does not start, stop or probe anything, and it
does not tell you that a worker is alive. Each row is a recorded run.

| Field | Where it comes from |
|---|---|
| Task | The conversation title |
| Repository | The workspace name from your config |
| Branch | The branch recorded when the conversation was created |
| Session | The provider's session ID, if one was recorded |
| State | Derived from the run status and events (table below) |
| Delivery | `unknown` or `delivered` (below) |
| Last event | The most recent recorded event and its time |

Where NivKode has no record, it shows the word `UNKNOWN`. That is a statement
about the record, not an error. For example, a local run has no provider
session, so its session is `UNKNOWN`.

| State | When it is shown |
|---|---|
| queued | The run status is `DISPATCHING`. |
| accepted | The run status is `ACCEPTED` and no later provider event has been seen. |
| active | Accepted, and a Codex `turn/started` event was recorded. |
| responding | Accepted, and Codex reply text started arriving. |
| completed | The run status is `COMPLETED` or `FAILED`. The outcome field says which. |
| uncertain | The status is `OUTCOME_UNKNOWN`, `INTERRUPTED`, or not recognised. |

Local models answer in one piece, so a local run goes from accepted straight
to completed.

**Delivery** is a second, separate value. It is `delivered` only when the
gateway stored an event that proves the provider received the work (for Codex,
`turn/started`). Gateway acceptance and a successful network send do not
count. Local runs stay `unknown`, because Ollama gives no such signal. There is
no `validated` value, because none of the supported providers reports one.

The roster shows at most 100 conversations per workspace.

## Switching engines (SOS)

If a provider fails, hits a limit or gets stuck, the **SOS** button in the
desktop header can move a conversation to another engine. You choose from the
engines the gateway reports as responding, and you confirm. The gateway
saves a summary and the last 20 messages for the new engine. It refuses while
any run in that conversation is starting, accepted or of unknown outcome.
See [Recovery](recovery.md).

## Director panel (optional)

When the gateway is set up for it, the sidebar shows a **Director** button. It
opens a chat with a separate service that runs on the same computer as the
gateway. NivKode does not include that service, and a default install does not
show the button. If you do run it, the gateway holds the credential in a file
you control, and the browser never sees it. Any paired device can send messages to that service through your gateway.
A message shown as "sent (accepted)" means the service took it, not that a
reply has arrived. The operator notes are in `docs/director-chat.md` in the
source tree.

## Pairing and devices

A device (the CLI, the desktop client or the phone) becomes trusted by
pairing:

1. You ask the gateway for a one-time code. It is valid for 10 minutes and for
   one use, and asking again cancels the previous unused code.
2. The device sends the code to the gateway and receives a device token.
3. The device sends that token with every request. The gateway stores only a
   hash of it.

Tokens last 90 days unless you change `device_token_ttl_seconds`. The desktop
client gets its token from the CLI through a one-use link that expires after 45
seconds. Details and limits are in
[Privacy and security model](privacy-and-security-model.md).

## Where your data lives

Everything NivKode keeps is on the computer that runs the gateway:
conversations, runs, events, notes, artifact records and device hashes. The
config file and state directory are owner-only. What a provider sees depends
on the provider you choose for each run. See
[Privacy and security model](privacy-and-security-model.md) and
[Privacy and provenance](PRIVACY_AND_PROVENANCE.md).
