# 0.2 design: local models get hands

Status: design note only. This describes a future Ollama write-proposal flow; the current local turn in `gateway/src/local_turn.rs` is explicitly read-only (`tools()` exposes only `list_workspace_files` and `read_workspace_file`). No write or command capability exists there today.

## Proposal contract

Request Ollama with `format: {"type":"object","properties":...,"required":[...],"additionalProperties":false}` (Ollama's JSON Schema mode). The response is exactly:

```json
{"summary":"...","reads":["src/a.rs"],"edits":[{"path":"src/a.rs","unified_diff":"--- a/src/a.rs\n+++ b/src/a.rs\n@@ ..."}],"commands":[{"argv":["cargo","fmt"],"cwd":"."}]}
```

All fields are required; arrays may be empty. Reject unknown keys, non-string paths/summary/argv items, empty argv, absolute paths, traversal, duplicate edit paths, binary or oversized diffs, malformed unified diffs, and edits to paths outside the declared `reads`/workspace policy. Do not repair malformed model output. Validate the schema again in Rust after decoding: provider-side schema mode is a generation aid, not a trust boundary.

## Validation and review

Resolve each path relative to the selected workspace root. Reuse `local_turn.rs::checked_file` policy (relative normal components only, no symlink components, canonical path under canonical root, sensitive names refused); for new files, validate the parent directory with equivalent descriptor-based checks. `read_file` already calls `checked_file` and `fd_open::read_beneath` via `read_workspace_file`; use that same bounded read path for context and ensure diff base bytes still match at approval time. Do not validate then later reopen by an unchecked pathname. Extend `fd_open.rs` with descriptor-relative write/replace primitives or an equivalent race-resistant helper; `local_turn.rs` currently has no safe write helper.

Render proposals through the existing desktop request/approval machinery. The exact Codex protocol request kinds to reuse are `item/fileChange/requestApproval` and `item/commandExecution/requestApproval`, handled in `main.rs::respond_request` and `main.rs::handle_app_server_request`. The desktop already renders pending file changes and command approvals in `desktop.js::liveRequestCard`, `requestDetails`, and `renderReview`; preserve those card components and response endpoint. These are JSON-RPC method strings stored in pending requests, not Rust `FileChange`/`CommandApproval` enum variants: the gateway stores generic event payloads (`db.rs::EventRecord`). For local proposals, add a source/provider discriminator and local proposal payload, but do not pretend to have a Codex upstream request id or send a response to Codex. Gate both accept and decline with the same conversation/run binding and owner decision semantics.

Before applying anything, create a stash-free snapshot for this turn under a hidden ref such as `refs/nivkode/undo/<turn-id>`. Build a temporary Git index from the current `HEAD`, add the workspace's tracked and non-ignored untracked files into that index, write a tree, create a snapshot commit, then atomically update the ref. Never stage through the user's real index. Record the changed path set and pre-apply blob ids. Apply only after snapshot creation, after rechecking every base blob and after `git apply --check`; use descriptor-safe replacement. A successful apply receipt keeps the ref and changed-path set. Turn-scoped Undo restores only journaled paths from the snapshot and removes only files created by this turn, after checking that their current blob still matches the applied blob. If a person edited a touched path since, stop and explain which path needs manual recovery. Retain refs until explicit cleanup; cleanup must not delete the user's branches or refs.

## Commands, stop, and local-only

Commands are proposals, never automatic work. Show `argv` as separate escaped arguments, the validated workspace-relative `cwd`, and the exact executable resolution; require an explicit per-command click. Do not invoke a shell, concatenate a command string, or grant remote shell authority. Apply one approved command at a time with a bounded environment, timeout, output cap, and cancellation token; record exit status and bounded stdout/stderr. If the executable cannot be resolved safely, say so and do not run it.

Stop mid-turn cancels the Ollama HTTP future and any running child process, closes pending cards as cancelled, and records an interrupted outcome, following `local_turn.rs::{register_run,request_stop}` and the existing stop route. A stop before apply means no workspace mutation. A stop during apply must finish or roll back the atomic file replacement before acknowledging stop. Cancellation does not imply undo of already approved changes; Undo remains explicit.

The local-only switch is a hard routing rule: proposal generation, workspace reads, validation, approvals, application and command execution stay on the configured computer and use Ollama only. Do not offer Codex as a fallback when local generation fails. If the owner explicitly switches provider, the new turn uses the existing external-provider disclosure/choice flow; never silently transfer proposal text or workspace contents.

Malformed JSON, schema violations, unsafe paths, stale bases, unsupported diff forms, or proposals with no valid action yield the calm user message **“It suggested nothing usable.”** Keep detailed reason codes in the local receipt/log for diagnosis. A mixed proposal should be rejected as a whole rather than partially applied.

## Receipt

Persist an auditable receipt per proposal: `receipt_id`, `conversation_id`, `run_id`/`turn_id`, `workspace_id`, `provider` (`ollama`), model name, schema version, created time, summary, validated reads, proposed edit paths, diff hashes, decision per card, approver identity, snapshot ref and tree id, applied paths and resulting blob ids, command argv/cwd and approval/result, stop/interruption status, undo status, and stable failure code. Redact file contents, secrets, and command output before any export; the receipt must not claim a change or command happened unless its result was observed.

## Tests to write first (failing-first)

1. Strict schema: valid empty proposal; missing/extra keys, wrong types, invalid JSON, overlong fields, and provider output that ignores JSON Schema.
2. Path guard parity: traversal, absolute paths, symlink parents, root replacement, hard links, sensitive names, missing-file parent, and a path swap between validation and use.
3. Diff safety: malformed/context mismatch, duplicate path, binary patch, oversized patch, stale base, rename/delete policy, and atomic failure leaves original bytes intact.
4. Approval contract: local file and command proposals render the same cards; accept/decline is conversation-bound; stale, duplicate, stopped, or cross-workspace decisions fail closed; no Codex RPC response is attempted.
5. Snapshot/undo: user index unchanged; tracked and non-ignored untracked bytes restored; created files removed; unrelated work preserved; concurrent edit makes Undo refuse; ref lifecycle survives restart.
6. Commands: argv remains distinct (including spaces/metacharacters), no shell, exact cwd/executable, timeout/output limits, refusal without approval, and stop kills the child.
7. Stop and privacy: cancel Ollama mid-response, stop before/during apply, local-only forbids network/provider fallback, and receipts/export contain no file bytes or secrets.
8. Desktop states: empty proposal, malformed response, validation failure, offline/reconnect, pending approval, applied, interrupted, and undo conflict; keyboard and screen-reader labels for each card.

## Five-day build plan

| Day | Deliverable |
|---|---|
| 1 | Freeze schema and receipt contract; land failing validation/path/diff tests; implement strict decoding and proposal-only Ollama request. |
| 2 | Descriptor-safe path validation and atomic diff application; no command execution yet. Pass path, stale-base, and atomicity tests. |
| 3 | Temporary-index snapshot refs, apply receipt, conflict-safe turn-scoped Undo; restart and unchanged-user-index coverage. |
| 4 | Adapt pending request/card flow for local source; add explicit command approval and bounded argv execution; cancellation and local-only checks. |
| 5 | Complete desktop waiting/error/offline/accessibility states, receipt redaction, adversarial integration suite, review and 0.2 acceptance evidence. |

## Main risks

- Path TOCTOU and symlink/hard-link races: ordinary canonicalize-then-write is insufficient; descriptor-relative operations are a release gate.
- Git index/ref mistakes could capture secrets or clobber user state. Use a private index, exclude ignored files, never touch the real index, and test interrupted snapshot creation.
- Unified-diff parsers can disagree about paths and offsets. Whitelist supported patch forms and check base hashes immediately before apply.
- Reusing Codex UI can make local actions look like Codex actions. Keep provider/source explicit on cards and receipts, and do not forge upstream events.
- Command approval remains a high-risk boundary even when local. No shell, exact argv, owner click, bounded execution, visible output, and cancellation are mandatory.
- JSON Schema support and model compliance vary by Ollama/model version. Treat all output as hostile and ensure failure says only that nothing usable was suggested.
- Undo cannot safely overwrite edits made after apply. Refuse on changed blobs and explain the recovery path; do not promise unconditional rollback.
