# Desktop client

The desktop client is a web page that your own gateway serves at `/desktop`.
It runs in your browser, talks only to the gateway that served it, and needs no
internet connection of its own. For the words used here, see
[Concepts](concepts.md).

## Open it

1. Install the Linux package and pair the CLI. See [Install](install.md).
2. In a graphical session, run `nivkode open`. It asks the gateway for a
   one-use handoff link that expires after 45 seconds, and opens your browser.
3. The page connects by itself. If it shows **Not connected**, run
   `nivkode open` again.

Do not share the handoff link or a pairing code. Opening `/desktop` directly
does not pair a device, and reloading the page disconnects it: the page keeps
your device token only in memory. After a reload it says **Reconnect this
window**. Run `nivkode open` again, or paste your device token again.

The **Getting started** button in the sidebar opens a four-step tour.

## Your first conversation

1. Choose a workspace, then create a conversation.
2. Next to **Send**, leave **Use** on **Configured route** to use a local model,
   or choose **Provider** to use Codex.
3. Type a small, read-only request, such as "Explain what the files in this
   workspace are for", and press **Send**.
4. When the reply arrives, open **Details** in the **Latest run** panel to see
   which provider, model and route answered.
5. With Codex, if the agent asks to change a file, the review card shows the
   request. Read it, then choose **Approve**, **Decline** or **Decline and stop**.

A local model can only read, and it can list at most 64 files. In a larger
workspace, name the file you want it to read.

## Find your way around

| Where | What is there |
|---|---|
| Sidebar, top | **Getting started**, then the **Local gateway** card with the connection state and a **Disconnect** button |
| Sidebar, middle | **Director** (optional, see below), the workspace picker, a button to create a conversation, and the conversation list |
| Sidebar, bottom | Display settings (**Reading & colour**): colour palette, reading font and text size |
| Header | The conversation title, a rename button, **SOS**, and the connection and run status |
| **Conversation** view | Messages, the latest run's details, the review card and the message box |
| **Workers** view | The read-only list of recorded runs |

Switching workspace clears the conversation view first: the title, messages,
latest run, activity and review of the conversation you leave are removed, and
its stream stops, before the new workspace's conversations load.

What you type in the message box belongs to the conversation it was typed in.
If you open another conversation or switch workspace before sending it, it
stays in this window's memory and comes back when you return to that
conversation. Closing or reloading the window drops it.

A message you already sent is not a draft. **Send** takes it out of the message
box at once, and that conversation offers no **Send** until the gateway
answers; you can type your next message meanwhile. If you open another
conversation or switch workspace before the answer, it still belongs to the
conversation you sent it in: an accepted message shows there as sent, with its
run, and never comes back in the message box. If the gateway refuses it, it
goes back in that conversation's message box, above anything you typed since;
if you had moved on, a short message names the conversation. If NivKode cannot
confirm the message arrived, it does not put it back by itself: **Check saved
state** puts it back only when the saved conversation does not have it. The
same goes for an approval decision that fails after you switch. The Workers view
shows only the workspace you are in, and is empty while it loads.

The status area shows two things in separate words: whether you are connected
(Connected, Reconnecting to gateway…, Offline) and the state of the latest run
(for example "Run: Completed").

## Send a message

Next to **Send**, the **Use** menu chooses where the message goes:

- **Configured route** sends it to a local model through a route such as
  `text.general` or `code.explain`.
- **Provider** lets you pick Ollama or Codex, and a model. The local engine is
  listed first.

A new conversation starts on a local model when one is installed. It never
takes over Codex from the conversation you used before, though a local choice
carries over. If no local model is installed, nothing is chosen for you: the
composer says "Choose an engine below before you send." Codex is used only in
a conversation where you choose it. When you open a conversation, **Use**
follows the engine that conversation last used, so a Codex conversation stays
on Codex.

If what you type looks like pasted code and **Use** points to a local model, a
hint appears under the message box: "Local models often misread pasted code.
Describe the change in words, or name the file you mean." If Codex is signed
in, the hint also offers **Use an external provider for this conversation (Codex)** and says where
Codex sends the conversation, for example "Codex sends this conversation to
OpenAI." The destination is the one the gateway reports for your Codex
account, such as OpenAI or Amazon Bedrock; when it cannot be stated safely, the
hint says "Codex sends this conversation off this computer." That button switches the conversation to
Codex, which it then keeps, and does not send your message: the composer says
"This conversation now uses Codex. Your message has not been sent yet." The
hint never changes the engine by itself, and it goes away when you send.

If no local model is installed and Codex is not available, the message box is
disabled and says: "No route or model is available for this workspace yet."
See [Troubleshooting](troubleshooting.md).

Local replies arrive all at once when the model finishes. Check the chips in
the **Latest run** panel to see which provider, model and route answered. Open
**Details** for the full record, including any fallback reason.

## Review before workspace changes

Every Codex session started from the desktop is read-only with no network
access. Codex must ask before it changes files or runs a command that needs
more than that; read-only commands can run inside that sandbox without asking.
This is always on. The message box says "NivKode asks before it changes your
workspace", there is no setting to turn it off, and the gateway refuses a
message sent without it.

The review card for the latest run shows:

- the file changes the run reported, each with a diff you can expand;
- any approval requests that are still waiting, as **Proposed file changes** or
  **Command approval requested**;
- a question Codex asked you, as **Codex asked a question**, with up to three
  of its questions. This version of the desktop cannot answer it: the card
  says "This version of the NivKode desktop can't answer this question yet. To
  end the run, press Stop. If you use the NivKode phone app, you can answer it
  there.";
- "Test results", filled from commands the run executed whose text looks like a
  test or check and that returned an exit code. If there are none, the card says
  "No test results reported for this run.";
- artifacts and notes.

For a pending request, **Approve** accepts it, **Decline** declines it, and
**Decline and stop** declines it and asks Codex to stop the turn. Decline sends
no text, so tell the agent what to change in your next message. These buttons answer the provider's
request. Local models answer questions and read workspace files; proposing file
file changes for approval and supported test and build commands for review and confirmation. Check the real
workspace before you rely on a change.

These buttons are for approvals only. The desktop cannot answer a question
from Codex in 0.2.0-beta.7. If you use only the desktop, press **Stop** to end the
turn. If you use the Android app, you can answer the question there instead.

The card does not run tests and does not infer success from a completed run.
If a run is interrupted or its outcome is unknown, inspect the workspace and
the provider's state before you retry.



## Stop a running turn

While the latest run of a conversation is running, a **Stop** button sits at
the end of the activity bar, for a Codex turn and for a local model's reply.
Pressing it shows **Stopping…**.

- For Codex, the gateway asks Codex to end the turn, and the final outcome
  comes from Codex. The run ends as **Run stopped**: "You stopped this run
  before it finished. Check the conversation and your workspace before you
  continue."
- For a local model, the gateway drops its request to Ollama, which stops
  generating. The run ends as **Run stopped**: "You stopped this reply before
  it finished. You can send a new message now."

While it is stopping, the button keeps keyboard focus and the status line says
what is happening. When the run has ended, focus moves to the message box.

## Notes

The review card has one **Notes** panel after the artifacts. It lists notes
about the run and about each file together, each tagged **About this run** or
**About** and the file name. To add one, choose what it is about (the picker
appears when the run has files, and each file has an **Add note** button), write
the note, then **Save note**. Each note shows when it was saved and has
**Edit**, **Delete** (with a confirmation) and **Add to message**. Add to
message puts the note in the message box, headed by a line such as
`[Context from note on run 1a2b3c4d, 6 Oct 2026, 09:14]`, so you can read and
change it before you send. Notes are never sent on their own. They are plain text, up to 4,000
characters, and stored on your gateway.

## Workers

Press **Workers** to see the runs the gateway recorded for the current
workspace. Each card shows the task (the conversation title), the provider, a
state, a delivery value, the repository, branch and session, and the last
recorded event. Where NivKode has no record, it says `UNKNOWN`. The view is
read only and does not show whether anything is still running. See
[Concepts](concepts.md#worker-roster).

## Reconnecting and working offline

The page checks the gateway every 3 seconds, and each check gives up after 5
seconds. If the gateway stops answering, even without an error, the header
changes to "Reconnecting to gateway…" within about 8 seconds and to "Offline"
about 4 seconds later. When it returns, the page restores the event order,
removes duplicates and reloads the conversation from saved history.

While the page is reconnecting or offline, a request waiting for your approval
keeps its **Approve**, **Decline** and **Decline and stop** buttons switched off
and says why. They come back when the connection returns. If a decision cannot
be confirmed because the connection dropped as you sent it, the page says so
and asks you to refresh.

A message you send while offline waits in that browser tab. It is sent once
when the connection returns, for the conversation you have open. Keep the tab
open. A message sent while online whose outcome is uncertain is **not** retried;
check the conversation first. See [Troubleshooting](troubleshooting.md).

## Switching engines (SOS)

**SOS** moves the conversation to another healthy engine and carries over a
summary and the last 20 messages. See [Recovery](recovery.md).

## Director (optional)

The **Director** button opens a chat panel for a separate local service. NivKode
does not include that service. The button appears only when the gateway is
set up for it, so a default install does not show it.

## Appearance and access

- The page follows your system light or dark setting.
- **Reading & colour** offers four palettes (Default, ColourSafe,
  TritanopiaSafe, HighContrast), three reading fonts (Default, Atkinson
  Hyperlegible, OpenDyslexic) and a text size from 90 to 145 percent. The page
  remembers these for the current tab. Both reading fonts ship with NivKode, so
  they work without installing anything.
- At up to 400 percent browser zoom (320 CSS pixels wide) the page reflows into
  one column and does not scroll sideways.
- A **Skip to conversation** link is the first item on the page. Status changes
  and new messages are announced through polite live regions.
- The Android app has matching palette, font, spacing and text-size choices, and
  TalkBack labels. See [Beta limitations](beta-limitations.md).

Automated scans (axe-core) report no violations across the desktop states we
checked, and they list some items that need a person to review. We have not
run a real screen reader against the client, so we cannot say how it sounds.
