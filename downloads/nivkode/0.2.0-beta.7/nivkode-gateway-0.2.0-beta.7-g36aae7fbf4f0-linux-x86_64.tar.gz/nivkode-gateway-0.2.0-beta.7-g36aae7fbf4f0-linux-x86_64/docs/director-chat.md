# Director chat

The desktop Director panel proxies the owner chat API of a separate local
service, the Director service, through the local NivKode gateway. NivKode does
not include that service. The browser uses its paired NivKode device token;
the service's owner credential is read only by the gateway from a host file.

Add this optional object to the private gateway config:

```json
"director_chat": {
  "factory_url": "http://127.0.0.1:8830/",
  "owner_token_file": "/home/OWNER/.config/director-chat/owner-token"
}
```

Without this object the feature is off: the desktop shows no **Director**
button (it asks `GET /v1/capabilities`, which reports `directorChat: false`),
and the gateway refuses the Director routes with `503
director_chat_not_configured`. With it, any paired device can post to the
Director service as its owner, because the gateway adds the owner credential
itself.

`factory_url` is the service's address (the key keeps this name) and must be a
loopback HTTP origin. Keep the owner token file outside
the repository and restrict it to its owner (`0600` on Unix). The gateway
rejects group/world-readable token files. Do not put the token value in config,
browser storage, a URL, or logs.

The gateway uses bounded requests to `GET /api/director-chat` and
`POST /api/owner/message`. The Director service remains responsible for
recording owner messages and for all Director replies. A successful POST means
the message was accepted, not that the Director has replied. The panel reads
lease state from the service and shows an offline state when no live lease
exists.

Director chat remains a host-local capability. The desktop never receives the
service's owner credential and does not call the service directly.
