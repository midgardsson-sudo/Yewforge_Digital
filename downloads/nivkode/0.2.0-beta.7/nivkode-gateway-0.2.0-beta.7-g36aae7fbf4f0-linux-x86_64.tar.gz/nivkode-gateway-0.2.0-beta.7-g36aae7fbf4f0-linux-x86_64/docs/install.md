# Install the Linux desktop package

This guide describes installing the Linux-only NivKode 0.2.0-beta.7 package. Use the
exact archive name supplied with an approved release. Verify its signature
before installing.
The package installs into your home directory and does not need Rust, Cargo or
`sudo`. Python 3.9 or newer is
needed by the installer and the bundled Doctor. A browser is needed for the
desktop; `nivkode open` also needs `xdg-open` and a graphical session.

## 1. Verify and unpack

When a release is available, keep the archive, its `SHA256SUMS` and the
signature `SHA256SUMS.minisig` together in one folder. The checksum detects a
change to the archive when checked against `SHA256SUMS`; it does not identify
who produced the checksum file. The signature on `SHA256SUMS` verifies its
origin with the NivKode release key (pinned key ID `50825CE20DD52D93`). The
installer refuses an archive without a valid signature. See the
[release signing guide](RELEASE_SIGNING.md) for the verification details.

On a first install, that check is made by the installer inside the archive you
just downloaded, so it cannot protect you from an archive that was replaced as
a whole. Check the signature yourself first, with
[minisign](https://jedisct1.github.io/minisign/) and the release public key,
also pinned in `share/nivkode/install.sh`:

Install minisign first:

```sh
# Debian or Ubuntu
sudo apt install minisign
# Fedora
sudo dnf install minisign
# Arch Linux
sudo pacman -S minisign
# macOS with Homebrew
brew install minisign
```

```sh
minisign -Vm SHA256SUMS -P RWSTLdUN4lyCUF75ANlaa4La4nvfZC8wvtuEeYLx0AxjR2sibpTjQmee
```

Then verify the checksum and unpack:

```sh
sha256sum -c SHA256SUMS
tar -xzf nivkode-gateway-0.2.0-beta.7-gXXXXXXXXXXXX-linux-x86_64.tar.gz
cd nivkode-gateway-0.2.0-beta.7-gXXXXXXXXXXXX-linux-x86_64
```

The trusted comment it shows must name the archive and its version. The
signature uses minisign's file format (Ed25519 over a BLAKE2b-512 hash). This
command was tested with minisign 0.12. NivKode's own
`scripts/release/release-signing.py verify --public-key FILE SHA256SUMS` checks
the same signature. The release public key is pinned in the installer.
Unsigned installs require `--insecure-allow-unsigned` (see below).

## 2. Install for your user

The installer checks the release signature and the archive checksum before
it changes anything, then places the gateway, CLI/TUI, Doctor and support files
under `$HOME`. Use the exact archive filename; keep `SHA256SUMS` and
`SHA256SUMS.minisig` in the same folder as the archive:

```sh
bash share/nivkode/install.sh ../nivkode-gateway-0.2.0-beta.7-gXXXXXXXXXXXX-linux-x86_64.tar.gz ../SHA256SUMS
export PATH="$HOME/.local/bin:$PATH"
```

The `export` line only affects this terminal. Run it in each terminal where
you use NivKode commands, including the second terminal used below, or add it
to `~/.profile` (or `~/.bashrc` or `~/.zshrc`) and open new terminals.

The installer writes only into real folders. If one of the folders it uses,
such as `~/.local/bin` or `~/.local/share/nivkode`, is a symbolic link, it stops
before changing anything and names the link.

If your browser saved the download under another name, such as `... (1).tar.gz`,
the installer still accepts it: it matches the archive to the signed `SHA256SUMS`
by its content. Do not edit `SHA256SUMS`; that breaks the signature.

`--insecure-allow-unsigned` is for developers installing an archive they built
themselves. It installs an unsigned archive (checking only that `SHA256SUMS`
lists it under its exact filename), prints a warning that nothing proves who
made it, and records `signature=none` in `~/.local/share/nivkode/installed-release`.
It never accepts an archive whose signature by the release key fails. Never use
it for a download. For an unsigned beta.7 development archive, unpack it and
keep the archive and `SHA256SUMS` beside the unpacked directory. From inside
that directory, use:

```sh
bash share/nivkode/install.sh --insecure-allow-unsigned ../nivkode-gateway-0.2.0-beta.7-gXXXXXXXXXXXX-linux-x86_64.tar.gz ../SHA256SUMS
```

This is an insecure developer install and does not authenticate who built the
archive. Use the signed command above for approved signed releases.

An optional systemd user-service template is installed but not enabled; see
[Run the gateway as a user service](#optional-run-the-gateway-as-a-user-service).
Installing again upgrades the programs in place, even while a gateway is
running (restart it to use the new version). Files you edited, such as the
example config or the unit template, are never overwritten: a newer copy is
saved next to them with a `.new` suffix.

## 3. Configure the gateway

Create a workspace and a private state directory. The gateway's default
loopback listen address uses port `8789`; a second gateway on the same machine
needs a different free listen address. This example uses `8789`.

```sh
mkdir -p "$HOME/workspace" "$HOME/.local/share/nivkode"
cp "$HOME/.config/nivkode/gateway.example.json" "$HOME/.config/nivkode/gateway.json"
python3 - "$HOME/.config/nivkode/gateway.json" "$HOME" <<'PY'
import json, pathlib, sys
path, home = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
data = json.loads(path.read_text())
data["listen"] = "127.0.0.1:8789"
data["state_dir"] = str(home / ".local/share/nivkode")
data["workspaces"] = [{"id": "workspace", "name": "Workspace", "path": str(home / "workspace")}]
path.write_text(json.dumps(data, indent=2) + "\n")
PY
chmod 600 "$HOME/.config/nivkode/gateway.json"
```

Keep the configuration private. It defines which workspace the gateway can
access. The example file holds placeholder paths (`/home/CHANGE-ME/...`); if you
edit the config by hand instead, replace every one of them.

## 4. Run Doctor and start the gateway

Doctor is a read-only preflight. It checks the config and local prerequisites
and prints PASS, WARN or FAIL for each. Warnings about Rust, Cargo, Java or the
Android SDK only matter if you build from source; ignore them for this package.
An invalid config or a missing or unreachable pinned model is a failure. Doctor
checks `qwen2.5-coder:7b` by default; pass `--model MODEL` to check another
installed model. The default download is about 4.7 GB and can take a while on
a slow connection. It is licensed under Apache-2.0. The project model notes
list `qwen2.5:3b` and `qwen2.5-coder:3b` as smaller research-only models;
they are not the default. Download sizes do not specify RAM requirements. If you do not use Ollama, its checks fail; that does not
prevent using Codex. Doctor is meant to run before you start the gateway. If
the configured port is already held by a running NivKode gateway, Doctor says
so and does not count it as a failure; if another program holds it, Doctor
fails the port check and you should pick another port in the config.

```sh
export PATH="$HOME/.local/bin:$PATH"
export NIVKODE_GATEWAY_CONFIG="$HOME/.config/nivkode/gateway.json"
nivkode-doctor
nivkode-gateway serve "$HOME/.config/nivkode/gateway.json"
```

The gateway is quiet while it runs normally. To see a start-up line, run
it as `RUST_LOG=info nivkode-gateway serve ...`; to check it, open a second
terminal, export the installed command path there, and run
`curl http://127.0.0.1:8789/health`, which answers `"status":"ok"`. Leave the
gateway running. In that second terminal, issue a one-time code and pair the
CLI:

```sh
export PATH="$HOME/.local/bin:$PATH"
nivkode-gateway pair-code "$HOME/.config/nivkode/gateway.json"
nivkode --gateway http://127.0.0.1:8789 pair YOUR_ONE_TIME_CODE
```

A pairing code works once and expires after ten minutes, and issuing a new code
cancels any unused earlier one. If `nivkode pair` says the code was not accepted,
issue a new one. Treat the code and paired device token as secrets.
The CLI stores its token in your user config with restrictive permissions.

## 5. First task with a local engine

Install [Ollama](https://ollama.com/download), start it, and pull the default
local model (about 4.7 GB to download once). Smaller research-only models are
available but are not the default; download sizes do not specify RAM
requirements:

```sh
ollama pull qwen2.5-coder:7b
```

Then start a conversation in the desktop and select the installed model for
the Ollama local model provider. The local model answers in text; it does not
run commands or write files.

## 6. Open the desktop and try a turn

After pairing, open the one-use browser handoff:

```sh
nivkode open
```

This uses `xdg-open` and requires a graphical session. If no browser can be
started, `nivkode open` says so and prints the one-use link; paste it into a
browser on this computer within 45 seconds. The `/desktop` page by itself is
not a pairing-code form, and reloading the desktop tab disconnects it, so run
`nivkode open` again after a reload. Create a conversation in the desktop and
choose a provider you have configured.

The included local model adapter returns generated text; it does not run
commands or write files. During a turn it can list and read text files in the
workspace you configured (read-only, size-limited, and skipping names that look
like keys, tokens or credentials), so point a workspace only at folders you are
willing to let the local model read.

For terminal use, see [CLI and TUI](cli-tui.md). A `text.general` local route
is bundled for the Linux package; route selection and provider requirements
are described in [providers](providers.md).

## If the gateway stops during a turn

Restart it with the same command. The desktop reconnects by itself and shows
the history. A run that was in flight when the gateway stopped is marked
**Outcome unknown**, because NivKode cannot tell whether the provider finished;
nothing that run produced afterwards is recorded. A Codex run may have changed
files before the gateway lost track of it, so check the workspace before you
carry on.

The conversation is not blocked. Send the next message in it, or start a new
conversation. From a terminal, `nivkode list` shows the conversation's id and
`nivkode resume CONVERSATION_ID "your message"` continues it; use that if
**Send** stays disabled in the desktop. See also
[troubleshooting](troubleshooting.md).

## Optional: run the gateway as a user service

The installed template is `~/.config/systemd/user/nivkode-gateway.service`. To
start it now and at every login:

```sh
systemctl --user daemon-reload
systemctl --user enable --now nivkode-gateway
journalctl --user -u nivkode-gateway -f
```

Stop the manually started gateway first: run one gateway per state directory,
whatever its port. NivKode refuses to start a second gateway on a state
directory that another gateway is already serving, and names the process that
holds it. Do not work around that by giving the service another port or a copy
of the config with the same `state_dir`. The
template is sandboxed: the gateway can write only to `~/.local/share/nivkode`,
and your home directory is read-only to it. That is enough for local-model
turns. Codex turns also need `~/.codex` and your workspace to be writable, so
add `ReadWritePaths=` lines for them with `systemctl --user edit --full
nivkode-gateway`. A service does not read your shell profile, so set
`codex_bin` in the gateway config to the absolute path of the Codex program.
To keep the service running after you log out, run `loginctl enable-linger
"$USER"`.

## Upgrade

Download the new archive, its `SHA256SUMS` and `SHA256SUMS.minisig` into one
folder, and run the installer that your current install keeps:

```sh
bash ~/.local/share/nivkode/install.sh nivkode-gateway-NEW-VERSION-linux-x86_64.tar.gz SHA256SUMS
```

That installer came with the version you already trust, so it checks the new
archive against the release key it pins, not against anything in the new
download. It refuses an archive that is unsigned, signed by another key or
changed after signing, and an older version than the one installed. The
installer replaces the programs, the Doctor script, the installer and the
uninstaller, and says what it changed. It does not touch your gateway config, this computer's pairing or your
conversations. A template you edited, such as the unit file, is kept, and the
new version is saved next to it with a `.new` suffix.

A gateway that is already running keeps the old version until you restart it:
stop it and start it again with the same command. The gateway brings the
conversation database to its own version the first time it starts. To be able
to return exactly to how things were, copy `~/.local/share/nivkode` before you
start the new one.

## Go back to an earlier version

Installers from this version on refuse to install an older version over a
newer one, because an older gateway may not read what a newer one wrote. They
compare versions (`0.1.0` < `0.2.0-beta.1` < `0.2.0`), not build names; another
build of the same version is not a downgrade. To go back on purpose, copy
`~/.local/share/nivkode` first, stop the gateway, run the installer with
`--allow-downgrade`, and start the gateway again with the same command:

```sh
bash ~/.local/share/nivkode/install.sh --allow-downgrade nivkode-gateway-OLDER-VERSION-linux-x86_64.tar.gz SHA256SUMS
```

The 0.1.0 release candidates predate this check, so their own installers do
not refuse a downgrade. Your config, this computer's pairing
and your conversations stay where they are. Between the 0.1.0 release
candidates, the earlier gateway opened the database that the later one had
updated, kept every conversation and took new turns, and upgrading again
afterwards worked. Release notes for a later version will say if going back
from it is not supported.

A 0.1.0 release candidate does not record which version is installed. After
going back to one, `~/.local/share/nivkode` still holds the later version's
uninstaller and version record. That uninstaller keeps the earlier programs
and lists them as changed, so to uninstall, run the earlier package's own
`share/nivkode/uninstall.sh` afterwards, or remove the programs it lists.

If you copied `~/.local/share/nivkode` before upgrading, you can return exactly
to that state instead: stop the gateway, move the current folder aside, put the
copy in its place and start the earlier version. Conversations from after the
upgrade are not in that copy; keep the folder you moved aside until you are
sure you no longer need them.

## Uninstall

From the extracted package directory, or later from the installed copy if you
have deleted that folder, remove the installed programs and service template:

```sh
bash share/nivkode/uninstall.sh
bash ~/.local/share/nivkode/uninstall.sh
```

Run one of the two. The uninstaller stops and disables the user service if you
enabled it and warns if a gateway is still running. It removes the files the
installer placed, each only at its own place in the install's folders, and
keeps any of them that you edited or replaced afterwards. It never follows a
symbolic link: a link, and anything inside a linked folder, is left in place
and reported. If `~/.local/bin` is itself a link, remove the three `nivkode`
programs there yourself. It keeps your
configuration and conversation data, and they hold secrets: this computer's
pairing token (`cli.json`), the gateway config, and the gateway's state folder
with your conversations and paired devices. The uninstaller lists each one it
kept, including a pairing under `$XDG_CONFIG_HOME/nivkode`, a config named by
`NIVKODE_GATEWAY_CONFIG` and a `state_dir` outside `~/.local/share/nivkode`.
NivKode reads a relative `XDG_CONFIG_HOME` or `NIVKODE_GATEWAY_CONFIG` from the
folder it runs in, so run the uninstaller from that folder; it says when a
setting is relative. An empty `XDG_CONFIG_HOME` counts as unset (`~/.config`).
A `state_dir` can be any folder, so for one outside
NivKode's own folders it names the gateway's files in it (`nivkode.sqlite3`,
its `-wal` and `-shm` files, `gateway.lock`), not the folder.

To delete them as well, run the uninstaller with `--remove-data`:

```sh
bash ~/.local/share/nivkode/uninstall.sh --remove-data
```

Before it changes anything, it lists every folder and file it will delete and
what each one holds, then asks you to type `delete`. Any other answer, or no
answer, cancels it, and nothing is removed, not even the programs. It refuses
while a gateway is serving from one of the state folders (stop the gateway
first). It deletes NivKode's own folders (`~/.config/nivkode`,
`~/.local/share/nivkode`, `$XDG_CONFIG_HOME/nivkode`) and, in a `state_dir`
shared with other files, only the gateway's files listed above. It never
deletes a workspace, never follows a symbolic link, and lists each path it
deleted and anything it had to keep. Deleted data cannot be recovered.

The gateway listens on loopback. A phone needs a private HTTPS route to it,
which the package does not configure; [Phone setup](PHONE_SETUP.md) shows how
to set one up with Tailscale Serve, and what not to do.
