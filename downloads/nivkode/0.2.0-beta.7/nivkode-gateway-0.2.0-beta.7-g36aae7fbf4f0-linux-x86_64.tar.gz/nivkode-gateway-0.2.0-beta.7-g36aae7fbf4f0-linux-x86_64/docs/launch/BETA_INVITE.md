# Beta.7 review note — not an invitation to install

This copy describes an unsigned 0.2.0-beta.7 review candidate. No release has
been approved or published.

## Public beta — Updates post / README

NivKode 0.2.0-beta.7 is an unsigned Linux x86_64 review candidate. We are checking it before making a release decision.

## Invite version — only if the owner invites people

We are preparing NivKode 0.2.0-beta.7 for review. It is not a published release, and this note is not an invitation to install it.

**Tested:** Automated checks use fake providers. They do not establish live-provider behavior on this candidate.

**Not yet tested:** A live run through an external AI provider (e.g. Codex, Claude, Grok) on this candidate. Earlier runs do not establish this candidate's behavior.

If a release is approved later, we will provide reporting instructions with it. When you use an external AI provider (e.g. Codex, Claude, Grok), what you send goes to that provider under its terms.

Day 7 reminder: When you have a moment, please send us your `nivkode-doctor` output and tell us what you tried and expected.

Security: Please do not report a suspected vulnerability in a public issue. Private vulnerability reporting will be enabled when we approve publication. When reporting, include the affected version or commit, impact, and steps to reproduce. Do not include real credentials or unrelated personal data. [OWNER DECISION: enable private security reporting before launch]
