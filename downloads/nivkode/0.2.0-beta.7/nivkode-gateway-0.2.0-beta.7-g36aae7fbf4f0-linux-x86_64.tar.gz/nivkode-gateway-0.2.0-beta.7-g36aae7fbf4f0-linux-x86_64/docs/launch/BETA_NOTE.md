# Beta.7 review candidate

We are preparing NivKode 0.2.0-beta.7 as an unsigned Linux x86_64 review
candidate. It is not a release announcement or an invitation to install. No
release has been approved or published.

## What we have tested

**Tested:** Automated checks use fake providers. They do not establish live
provider behavior on this candidate.

**Not yet tested:** A live run through an external AI provider (e.g. Codex,
Claude, Grok) on this candidate. Earlier runs do not establish this
candidate's behavior.

## Install and verify

This candidate is unsigned and has no download link. Do not install it as a
release. If we approve a release later, use that release's archive, checksum
list and signature, and follow the [release signing guide](../RELEASE_SIGNING.md).

## Reporting

If we approve a release, we will provide reporting instructions with it. When
you use an external AI provider (e.g. Codex, Claude, Grok), what you send goes
to that provider under its terms.
