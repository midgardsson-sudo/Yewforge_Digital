# Historical 0.1.1 launch copy — do not use for 0.2

This material is retained as dated 0.1.1 history. It is superseded by
[`RELEASE_DRAFT.md`](../RELEASE_DRAFT.md) and must not be published for 0.2.

## Internal header — not for publication

Owner approval is required before any of this copy is queued. Friday 13 November 2026 is a target and may move if testing finds issues. This is not a publication or release notice.

Open owner decisions are marked inline where they affect wording.

Hold until: signed 0.1.1 archive exists; PUBLIC_CLAIMS row 13 and the release-notes header are updated to the published state; owner approves publication.

## Claim sources

| ID | Copy claims covered | Approved sources |
|---|---|---|
| C1 | Release approval is required; 13 November is a target that may move. | `docs/PUBLIC_CLAIMS.md`, status and date rows 13–14 |
| C2 | 0.1 beta (version 0.1.1); Linux desktop package; Android source preview. | `docs/RELEASE_NOTES_0.1.1.md`, opening status; `docs/PUBLIC_CLAIMS.md`, platform and status rows |
| C3 | Ollama — local model provider and experimental Codex are available choices; avoid positioning that implies local use is the primary mode. | `docs/GETTING_STARTED.md`; `docs/PUBLIC_CLAIMS.md` |
| C4 | Experimental Codex; Ollama tested on Linux desktop; Codex tested on earlier builds but not live on candidate 0.1.1; Claude and Grok not yet tested and unavailable. | `docs/PUBLIC_CLAIMS.md`, provider rows 1–3; `docs/providers.md` |
| C5 | Android preview is source-built and not in the public download. | `docs/PUBLIC_CLAIMS.md`, Android platform row; `docs/RELEASE_NOTES_0.1.1.md`, opening status |
| C7 | NivKode workspace, engine choices and approval requests naming actions. | `docs/RELEASE_NOTES_0.1.1.md`, Changes; `nivkode-rusty/README.md` |

--- PUBLIC COPY BELOW ---

## Updates page

NivKode is a desktop workspace for working with an AI engine, either a local model on your computer or an external AI provider, and reviewing the commands and file changes it asks your approval for. Version 0.1 beta (version 0.1.1) for a Linux desktop package, with an Android preview built from source. Friday 13 November is our target date; it may move if testing finds issues, and a person must approve any release.

We designed NivKode to start with a local model when one is installed. A new conversation uses that local default when available; otherwise, you choose an engine. An external AI provider is another choice for a conversation.

The 0.1 beta (version 0.1.1) offers experimental Codex. **Ollama — local model provider** is tested on Linux desktop, but has not yet been run from a phone. Codex is labelled Tested based on bounded runs on earlier builds; it has not had a live run in this release. Claude and Grok are labelled Not yet tested and are unavailable in this build.

The Android app is a preview that you build from source, and it is not included in the public download.

## Social posts

### Short post — Bluesky / Mastodon

NivKode is a desktop workspace for working with an AI engine, with commands and file changes reviewed before approval. Version 0.1 beta (version 0.1.1) for Linux desktop; the Android preview is built from source. Friday 13 November is our target, subject to testing and release approval.

### Short post — Bluesky / Mastodon

NivKode is a desktop workspace for working with an AI engine and reviewing the commands and file changes it asks your approval for. It is designed to start with a local model when one is installed. For a new conversation, use that local default when available or choose an engine.

### Short post — Bluesky / Mastodon

NivKode is a desktop workspace for working with an AI engine, with commands and file changes reviewed before approval. It offers experimental Codex. Ollama is tested on Linux desktop; Codex is Tested on earlier builds; Claude and Grok are Not yet tested and unavailable.

### Short post — Bluesky / Mastodon

NivKode is a desktop workspace for working with an AI engine and reviewing the commands and file changes it asks your approval for. The Android app is a preview you build from source. It is not included in the public download.

### Longer post — LinkedIn

NivKode is a desktop workspace for working with an AI engine and reviewing the commands and file changes it asks your approval for. Version 0.1 beta (version 0.1.1) for a Linux desktop package and an Android preview built from source. Friday 13 November is a target date, not a promise: testing may move it, and a person must approve any release.

NivKode is designed to start with a local model when one is installed. A new conversation uses that local default when available; otherwise, you choose an engine. An external AI provider is also a choice for a conversation. The 0.1 beta (version 0.1.1) offers experimental Codex. Ollama is tested on Linux desktop; Codex is Tested based on bounded runs on earlier builds; Claude and Grok are Not yet tested and unavailable in this build.

The Android preview is built from source and is not included in the public download.

## What NivKode is

NivKode is a desktop workspace for working with an AI engine, either a local model on your computer or an external AI provider, and reviewing the commands and file changes it asks your approval for. Version 0.1 beta (version 0.1.1) for a Linux desktop package and an Android preview built from source. It is designed to start with a local model when one is installed, while letting you choose an external AI provider for a conversation. The 0.1 beta (version 0.1.1) offers experimental Codex; **Ollama — local model provider** is tested on Linux desktop, and Claude and Grok are not yet tested and are unavailable in this build.

## FAQ

### What is NivKode?

NivKode is a desktop workspace for working with an AI engine and reviewing the commands and file changes it asks your approval for. Version 0.1 beta (version 0.1.1) for a Linux desktop package and an Android preview built from source.

### Does NivKode start with a local model?

NivKode is a desktop workspace for working with an AI engine and reviewing the commands and file changes it asks your approval for. It is designed to start with a local model when one is installed. A new conversation uses that local default when available; otherwise, choose an engine.

Ollama local models are tested on Linux desktop; they have not yet been run from a phone.

### Which external providers can I use?

NivKode is a desktop workspace for working with an AI engine and reviewing the commands and file changes it asks your approval for. This release offers one external provider, experimental Codex, which is Tested on earlier builds. Claude and Grok are Not yet tested and unavailable in this build.


### How do I report a problem?

Run `nivkode-doctor`, read its output, remove anything private, and email it to support@yewforge-digital.co.uk with what you did and what you expected.

### What does it cost?

[OWNER DECISION: price wording]

### Where can I get it?

[OWNER DECISION: download link]
