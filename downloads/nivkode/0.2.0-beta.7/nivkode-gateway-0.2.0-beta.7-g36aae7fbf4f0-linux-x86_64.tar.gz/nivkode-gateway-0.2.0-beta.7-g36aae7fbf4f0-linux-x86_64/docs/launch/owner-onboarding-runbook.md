# Internal owner phone onboarding and rollback runbook

This runbook is for the private reviewed-candidate session. It is excluded from
the public export. The owner performs the phone taps; the operator prepares and
checks the artifacts on the computer. No candidate install, Tailscale Serve
walk, physical update or rollback is claimed complete by these instructions.
Use the general [phone setup guide](../PHONE_SETUP.md) for the gateway, route,
pairing and first local task.

## Candidate and rollback handoff

Before the owner installs anything, record the reviewed candidate decision,
source commit, gateway version and executable SHA-256, and the exact APK file,
package name, versionName/versionCode, SHA-256 and signer certificate SHA-256.
Record the same identity and gateway compatibility for the approved previous
APK. Run `nivkode-gateway --version`,
`sha256sum "$(command -v nivkode-gateway)"`, `sha256sum APK_FILE`,
`apksigner verify --print-certs APK_FILE` and `aapt dump badging APK_FILE` for
each applicable file. Keep the reviewed APK bytes; do not substitute a fresh
build with the same version label. If approval, identity, compatibility or the
retained rollback APK is missing, stop before the owner install.

Store the handoff under `EVIDENCE/launch/onboarding/` only after redaction.
Keep raw device IDs, pairing codes, tokens and unredacted session material in
a mode-0700 private staging directory under
`~/.local/share/nivkode/onboarding-review/`; never commit them. The handoff
records identifiers and hashes, never the code or token value.

## Show the computer's ADB key fingerprint

Before connecting USB, the operator runs `adb start-server` and then displays
the MD5 fingerprint of the computer's ADB public key:

```sh
set -o pipefail
cut -d' ' -f1 "$HOME/.android/adbkey.pub" | base64 -d | md5sum
```

Stop if the public key file is missing or either command fails. Android may
display the same hexadecimal bytes with colons between pairs. Show the
expected fingerprint directly to the owner before they connect the cable.
They compare the full fingerprint on **Allow USB debugging?**, tap **Allow**
only on an exact match, and leave **Always allow from this computer** unticked.
Never approve an unknown computer to make the transfer proceed.

## Transfer and install the reviewed candidate

1. Owner: open **Settings → About phone → Software information → Build
   number**, tap seven times and enter the screen lock when asked. Turn on
   **Settings → Developer options → USB debugging**. Connect to the approved
   computer and compare its ADB fingerprint as above.
2. Operator: from the folder with the exact reviewed APK, run:

   ```sh
   adb devices
   adb push REVIEWED-CANDIDATE.apk /sdcard/Download/NivKode-reviewed.apk
   adb shell sha256sum /sdcard/Download/NivKode-reviewed.apk
   ```

   `adb devices` must show `device`, and the phone-side hash must equal the
   candidate APK SHA-256 in the handoff. Stop on `unauthorized`, a failed push,
   missing `sha256sum` or a mismatch. The transfer does not install the app.
3. Owner: open **My Files → Downloads → NivKode-reviewed.apk**, allow **Install
   unknown apps** for My Files if prompted, then tap **Install** and **Open**.
   Let Play Protect scan; stop on a block or unresolved warning. Turn **Install
   unknown apps** off again.
4. Operator: check the installed package/version with
   `adb shell dumpsys package co.yewforge.nivren.nivkode` against the handoff.
   The transfer hash, installed version and source APK signer are separate
   identity checks. Owner: turn off USB debugging and disconnect USB.

The S20 tap order and Tailscale route have not been physically rechecked for
this candidate. On the phone, install or update Tailscale from Play Store,
complete **Get Started**, the VPN prompt and sign-in, then confirm the same
tailnet and `/health` page as in the public guide. Stop on a DNS failure after
updating and reconnecting; never substitute a public URL or IP workaround.

## Pairing and first-task evidence

Pause screen and terminal capture before issuing `nivkode-gateway pair-code`.
Show the code and checked private URL directly to the owner at the pairing
screen, clear the terminal view, and record only `issued`, `used` or `expired`.
An expired or failed code needs a fresh private handoff.

After the first local task settles, the owner takes a screenshot with
**Power + Volume Down** that shows the prompt, answer and local identity. The
operator follows the read-only [CAP-1 run and event lookup](../ON_DEVICE_CAPABILITY.md#operator-run-and-event-lookup)
and reviews its redacted export. A screenshot alone does not establish the
run ID or completion. A missing event or uncertain match remains `OPEN`.
The lookup and export commands must run in the same terminal so `REVIEW_DIR`
still names the private staging directory.

## Return to the approved Android APK

Use the rollback APK named by SHA-256 in the reviewed handoff, never an
arbitrary older download. Before changing the phone, record the candidate
package/version, APK hash and signer, gateway version, and approved rollback
package/version, APK hash and signer. Identify the current phone's device token
with [the admin device list](../PHONE_SETUP.md#a-lost-or-replaced-phone). Stop
if it cannot be identified unambiguously; never revoke a guessed device.
Check that no turn is in flight. An older same-signer APK may be rejected as
a downgrade, so this procedure uninstalls and reinstalls. This clears app
data and requires pairing again; unsent drafts and phone-only state may be
lost, while conversations remain on the gateway.

1. **Transfer and verify while the candidate remains installed.** The owner
   turns on USB debugging and compares the approved computer's fingerprint
   using the displayed value above. The operator checks `adb devices` shows
   `device`, then runs:

   ```sh
   adb push APPROVED-ROLLBACK.apk /sdcard/Download/NivKode-rollback.apk
   adb shell sha256sum /sdcard/Download/NivKode-rollback.apk
   ```

   The phone-side SHA-256 must equal the approved rollback hash in the handoff.
   Stop on a failed transfer, missing `sha256sum` or mismatch. Leave the
   candidate installed if verification has not passed.
2. **Uninstall only after verification.** Owner: open **Settings → Apps →
   NivKode → Uninstall** and confirm. If the candidate was already absent or
   the uninstall fails, stop and record that state.
3. **Install the checked rollback file.** Owner: open **My Files → Downloads
   → NivKode-rollback.apk**. If Android still shows NivKode as installed,
   stop; do not attempt a same-signer downgrade. Otherwise tap **Install** and
   **Open**. Handle **Install unknown apps** as above, turn that permission
   off afterwards, and stop on a Play Protect block.
4. **Verify and re-pair.** Operator: run
   `adb shell dumpsys package co.yewforge.nivren.nivkode` and compare the
   installed package/version to the approved rollback. Owner: use the private
   pair-code handoff, then open the prior conversation to check reconnect and
   local identity. Operator: revoke only the old phone token identified before
   uninstalling through the admin device list and check its `revokedAt` field.
   Record before/after APK hash, version, signer, pairing and result. Owner:
   turn off USB debugging and disconnect the cable.

If signer verification, install, pairing, safe revocation or prior-conversation
recovery fails, leave the recovery result `OPEN` and preserve evidence. This
procedure is an app-version rollback; the separate physical update and
rollback gate still needs its own proof.
