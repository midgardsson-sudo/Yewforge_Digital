# Privacy and security model

This page says what NivKode keeps, what leaves your computer, who holds which
credential, and where the protections stop. It describes NivKode 0.2 as
built. It is not a guarantee, and it is not legal advice. Terms for providers
are in the provider documentation.

## The short version

- Everything NivKode stores is on the computer that runs the gateway.
- The gateway listens on loopback only, and it refuses to start otherwise.
- NivKode makes no outbound connections of its own except to Ollama and to the
  optional Director service, and both must be on loopback.
- If you use Codex, your prompts and whatever Codex reads leave your computer
  under your own account's terms. Ollama receives prompts and workspace context
  on the configured local service.
- Provider credentials stay with the provider's own program on your computer.
  NivKode does not read or store them.
- By default, Codex starts read-only and asks before it changes anything.
- NivKode has not had an independent review of everything added since 3
  October. See [Where the protections stop](#where-the-protections-stop).

## What stays on your computer

| Item | Where | Protection |
|---|---|---|
| Gateway config (`gateway.json`) | Path you choose, for example `~/.config/nivkode/` | You set it to owner-only. Doctor fails if group or others can read it. |
| State directory | `state_dir` in the config | Created with mode `0700` |
| Database `nivkode.sqlite3` | Inside the state directory | Created with mode `0600` |
| Conversations, messages, runs, events | The database | Stored as plain text |
| Notes | The database | Stored as plain text, never sent unless you send them |
| Artifact records | The database | Name, type, size, SHA-256 and origin only. File contents stay in your workspace. |
| Pairing codes and device tokens | The database | Only hashes are stored |
| CLI token | `~/.config/nivkode/cli.json` | Mode `0600`. The CLI refuses to run if the mode is looser. |
| Desktop client token | Browser page memory | Not written to storage. Reloading the page disconnects it. |
| Android token | Phone | Encrypted with an Android Keystore key |

The desktop client also keeps a few things in your browser: the last workspace
and conversation IDs and scroll positions (local storage), and, for the current
tab only, the gateway address, your display settings and any message waiting
to be sent while you are offline (session storage, plain text). Closing the tab
discards the queued message.

By default the gateway logs only errors, and its logs do not contain message
text or authorization headers. To see startup and Codex status messages, start
it with `RUST_LOG=info`.

## What leaves your computer

It depends on the provider you pick for each run. Check the selection next to
the **Send** button every time.

| You choose | What is sent, and to whom |
|---|---|
| Codex | Your message, up to the last 16 messages of the conversation (each cut to 2,000 characters), and any images you attach. Codex also sees whatever it reads in the workspace during the run. All of it goes through Codex to the provider your Codex account uses (OpenAI for a ChatGPT sign-in or an API key, Amazon Bedrock for a Bedrock account), under your account and its terms. |
| A local route or Ollama model | Your message and the same recent history, sent to Ollama on loopback. If the model asks to read a workspace file, the file's text goes to the model in Ollama. Nothing leaves your computer unless your own Ollama setup connects elsewhere. |
| Director panel | Your message goes to the Director service on loopback. |

The default Codex mode starts a fresh provider session for every turn and
passes the recent history as context. It does not rely on the provider
remembering earlier turns.

Local models answer questions and read workspace files. Proposing file edits
Local models can propose file changes for approval and supported test and build commands for review and confirmation. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made. The local-only switch
refuses external AI providers (e.g. Codex, Claude, Grok) at the gateway. Local models cannot change files in
this build.

Local models are not private from your own files. A local model can list and
read text files in the workspace you configured, subject to the limits in
[Concepts](concepts.md#providers). The block list is a filter on names; it is
not a secret scanner. A file that holds a password but is called `notes.txt`
can be read. Keep private material out of the workspace, or choose a different
workspace folder.

## Deleting your data

NivKode has no command to delete a conversation or a run. You can delete a note.
To remove everything NivKode stored, stop the gateway and delete its state
directory (the `state_dir` in your config). Delete the gateway config and
`~/.config/nivkode/cli.json` too if you want to remove your pairing. Local
Ollama keeps its own data, and anything sent to Codex stays under your
provider's terms. See [Install](install.md#uninstall) for the uninstaller, which
keeps your data unless you remove it yourself.

## Credentials stay on the host

- **Codex.** NivKode starts the `codex` program you installed and lets it use
  the sign-in you made with `codex login`. NivKode does not read or copy that
  credential.
- **Claude.** The beta.7 route is present, but no live run is verified (**Not yet tested**); the app labels Claude "in development". The adapter boundary in the source contains no field
  for credentials, and its design says NivKode must never read or pass them.
- **Director.** The gateway reads an owner token from a file named in your
  config. The file must be owner-only, and it is read on each request. The
  browser never receives it. Because the gateway adds that token itself, any
  paired device can post messages to the Director service as its owner. This
  bridge is off unless you configure it, and the desktop shows the
  **Director** button only when it is on.
- **Gateway admin token.** Optional, kept in your config (at least 32
  characters). It allows listing and revoking devices. The gateway refuses to
  start if other users can read a config that holds it. Where those requests
  are accepted depends on the build. With the admin-socket change, only on an
  owner-only socket file on the gateway computer
  ([below](#listing-and-revoking-devices)). Without it (r6f and earlier), on
  the gateway's port from a loopback address. A proxy on the computer, such as
  Tailscale Serve, also connects from loopback, so with such a route on, the
  token is the only thing that stops a request from another device. A loopback
  address does not show where a request came from.

## Pairing

1. You run `nivkode-gateway pair-code CONFIG` on the gateway computer. It
   prints a random one-time code.
2. The code works for 10 minutes and one use. Asking for a new code cancels any
   earlier unused one. A wrong code does not use up the current one.
3. A device sends the code and a name to the gateway and gets back a device
   token, once. The gateway stores only a hash and compares it in constant
   time.
4. Every later request carries `Authorization: Bearer TOKEN`. Every route
   needs a valid token except `/health`, `/v1/pair`, the desktop page files and
   the one-use handoff claim. The admin routes use the admin token and the
   admin socket instead (below). <!-- REQUIRES-ADMIN-PROXY -->

Tokens expire after 90 days. You can change that with
`device_token_ttl_seconds` in the config. A device can rotate its own token
(`POST /v1/device/rotate`); the old token stops working at once.

### The desktop handoff

`nivkode open` asks the gateway for a handoff code, then opens
`http://127.0.0.1:PORT/desktop#handoff=CODE` in your browser. The page removes
the code from the address bar and exchanges it, once, for an access token. The
code expires after 45 seconds. The gateway gives the token only to a browser
running as the same local user who ran `nivkode open`; a claim from another
user on the computer is refused like an expired code.

The browser receives the same device token the CLI holds. There is no
separate browser identity. Revoking the CLI's device also ends the browser
session.

### Listing and revoking devices

<!-- REQUIRES-ADMIN-PROXY: true only with the admin-socket change; see the
marker at the top of PHONE_SETUP.md. -->
**Requires the admin-socket change**, as described in
[Phone setup](PHONE_SETUP.md).

Set `admin_token` in the gateway config and restart the gateway. It then
serves the admin routes on a socket file that only your user can open:
`admin.sock` in its state directory (`~/.local/share/nivkode` unless your
config says otherwise). A socket path can be at most 107 bytes, so when the
state directory's path is too long the socket goes in a private `nivkode`
folder of your runtime directory (`$XDG_RUNTIME_DIR`, usually
`/run/user/UID`) instead. The gateway makes that folder, and refuses to start
if it, or the runtime directory, is a link, belongs to another user or is open
to other users. Every folder above the socket, from `/` down, must belong to
root or to you and be closed to writing by others, so that nobody else can
swap a folder on the path. In a container or sandbox that shows `/` or one of
those folders as user 65534 (an owner from outside it, whom the gateway cannot
identify), the gateway refuses to start while `admin_token` is set.
`nivkode-gateway admin-socket` prints where the socket is. The
gateway also checks that the program on the other end runs as the gateway's
own user. Send the requests on the gateway computer, as that user, with the
header `Authorization: Bearer ADMIN_TOKEN`:

| Request | What it does |
|---|---|
| `GET /v1/admin/devices` | Lists every device: its id, name, when it paired, when it was last seen, and whether it is revoked |
| `DELETE /v1/admin/devices/DEVICE_ID` | Revokes that device |

```sh
curl --unix-socket "$(nivkode-gateway admin-socket)" -H "Authorization: Bearer $ADMIN_TOKEN" http://localhost/v1/admin/devices
curl --unix-socket "$(nivkode-gateway admin-socket)" -X DELETE -H "Authorization: Bearer $ADMIN_TOKEN" http://localhost/v1/admin/devices/DEVICE_ID
```

[A lost or replaced phone](PHONE_SETUP.md#a-lost-or-replaced-phone) gives the
exact commands. They create the token, then read it from the config and pass
it to `curl` through a pipe, so it is never shown on screen, kept in shell
history or put on a command line that other users could see.

The gateway's port never serves the admin routes; it answers every
`/v1/admin/` request with `403`. A proxy on the computer, such as Tailscale
Serve, connects to that port from `127.0.0.1`, so the gateway cannot tell a
forwarded request from your own. A request on the socket that carries a
proxy's forwarding headers is refused as well.

There is no CLI command for this in 0.2.0-beta.7.

Revoking a device ends its open event streams. So does its token expiring or
being replaced. A revoked phone forgets its token, stops reconnecting and shows
the pairing screen.

## Approvals and authority

- NivKode has no remote shell and no endpoint that runs a command you typed.
- NivKode never runs commands a model suggests. When Codex runs a command or
  edits a file, Codex does it, inside the sandbox mode the gateway requested.
- Every Codex session and turn is read-only with no network access, and
  approval requests go to you, never to an automatic reviewer. The gateway sets
  this each time, so your own Codex configuration cannot loosen it. Approval
  cannot be turned off: the desktop has no such setting, and the gateway
  refuses a message sent without it (`owner_approval_required`).
- You see each request exactly as Codex sent it. You answer one request at a time
  with Approve, Decline or Decline and stop (on the phone, Approve once or
  Reject), and only one answer per request is
  accepted. There is no "always allow". Requests NivKode does not understand
  are declined or rejected.
- A workspace whose project `.codex` folder holds executable settings is refused
  for Codex unless you list it in `codex_project_config_workspaces`.
- An approval is not an undo. See [Concepts](concepts.md#approvals-and-the-review-gate).
- The terminal client cannot answer approvals. Use the desktop client or the
  Android app.
- A local model can only read. It has no way to change a file.

## Browser protections

- The desktop page is served with a strict content security policy. Scripts,
  styles, images, fonts and network requests are limited to the same origin, and
  framing is blocked.
- Responses are marked `no-store` and `nosniff`, and the page sends no referrer.
  Responses that carry a token are `no-store`.
- The API accepts a browser request only when its `Sec-Fetch-Site` is
  `same-origin` or `none` and any `Origin` header names the gateway's own
  address. Everything else is refused (`cross_site_request_refused`),
  including requests a browser marks as cross-site or same-site (for example
  a page served from another port on this computer) and requests from an
  opaque origin. A request that repeats `Origin`, `Host` or `Sec-Fetch-Site`
  is refused too.
- The gateway holds at most 32 pending desktop handoffs, then answers
  `desktop_handoff_limit_reached`.
- Artifacts are served as inert plain text or images. A file with more than one
  hard link is never registered or served as an artifact.
- The page refuses to talk to any gateway other than the one that served it.
- The page builds its content from text nodes rather than HTML, so message text
  and Director replies are shown as plain text.

## Evidence exports

`nivkode-gateway evidence-export` copies one conversation's ordered events and
artifact metadata (not file contents) into a JSON file, and runs redaction
passes that remove common credential shapes. Paths inside the conversation's
workspace are written as `<workspace>/…` and other paths in a home folder as
`<home>/…` (Linux, macOS, Windows `C:\Users\<name>` and `~<name>/` forms); your
user name elsewhere in a path, as in `/tmp/<name>/`, becomes `<user>`. So your user
name is not in the file's paths. Notes are not included. Redaction
cannot promise to find every secret. Read an export before you share it.

A Learning Curve case (`nivkode-gateway lc`) is redacted the same way: its
`case.json` and `bundle.md` name workspace files as `<workspace>/…` and other
home-folder paths as `<home>/…`, including the database path. Every other file in
the case folder, the intake reply and a Doctor draft pull request
get the same rewrite. Only the Doctor's own `state.json` (which must name the real
repair worktree to undo it) and the exact patch files keep real paths. Doctor's
preflight report writes your home folder as `~` and any other home-folder path,
including a workspace ID that looks like one, as `<home>/…`.

## Where the protections stop

These are the limits we know about. Plan around them.

1. **Loopback is not a wall against your own account.** Any program that runs
   as you can read your CLI token and database. Any local program can try the
   gateway's port, though it needs a valid token to do anything. Use full-disk
   encryption if the computer could be lost or shared.
2. **Every paired device has the same power.** There are no per-device
   permissions. Whoever holds a token can do everything a device can do,
   including approving changes. A proxy on the gateway computer makes its
   requests come from loopback, which is why device admin is only on the
   owner-only admin socket and never on the gateway's port.
   <!-- REQUIRES-ADMIN-PROXY -->
3. **Remote access is yours to secure.** The Android app needs an HTTPS address
   you set up. NivKode does not create a tunnel, proxy or firewall rule. A
   public endpoint in front of the gateway is your responsibility.
4. **Data on disk is not encrypted by NivKode.** Messages, notes and events are
   plain text in the database. Only the owner-only file modes protect them.
5. **The download checksum is not a signature.** `SHA256SUMS` comes from the
   same place as the archive, so it catches corruption but not a tampered pair
   of files. Release signing is an open owner decision.
6. **Review is not a sign-off.** The first written review (SEC-1) covers the
   gateway as of 3 October. A second review on 6 October covered the gateway
   source of that day, with fixes, using tests and a scripted Codex app-server.
   A third, later on 6 October, read everything merged up to the final tree and
   found no open P0 or P1 issues; it listed seven lower-severity items, six of
   which are still open. AI agents wrote
   all three, and none exercised a live provider, a phone or a proxy. The
   owner's security sign-off is still pending. A dependency audit on 6 October
   found no vulnerabilities and replaced one yanked crate. It left two
   advisories, in libraries used only by the terminal view, where they get no
   untrusted input; the fix needs a breaking upgrade.
7. **The service sandbox is unproven on a real service manager.** The optional
   systemd unit template has sandbox settings, but the startup check has not
   been recorded on a machine with a user systemd session.
8. **Redaction and filters are best effort.** Evidence redaction and the local
   file name filter will miss things.
9. **Provider behaviour is the provider's.** What Codex or OpenAI does with
   your data, how long they keep it, and what they charge are set by their
   terms, which can change.
10. **Codex folder trust still matters.** Codex keeps its own list of trusted
    folders. A broad entry such as `/` in your Codex configuration makes every
    workspace trusted. Trust only repositories you own.
11. **There is no Host allowlist.** A page on another site that rebinds a DNS
    name to your computer could reach the pairing and handoff-claim routes, but
    both need a one-use random code.
12. **There are no per-device rate limits or event retention limits.** The event
    history grows until you delete it, and the gateway does not limit how often a
    paired device calls it.

If you find a vulnerability, report it privately through the repository's
Security tab, as described in `SECURITY.md`. Do not post it in a public issue.
