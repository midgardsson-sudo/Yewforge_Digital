# Providers and accounts

## Local only

The paired-device `local_only` setting defaults to off and persists in gateway state. When enabled, the gateway refuses Codex dispatches server-side; clients also mark external engines unavailable. Read or update it through the authenticated `/v1/settings/local-only` endpoint. Any external AI provider (e.g. Codex, Claude, Grok) must use the same gateway dispatch guard.

The local-only switch is enforced at the gateway: when it is enabled, external
provider dispatch is refused there. Stale proposals cannot be approved.
Choose **Ollama — local model provider** or an external AI provider (e.g.
Codex, Claude, Grok) when local-only is off. Codex is **Tested on earlier
builds (experimental); live use on beta.7 is Not yet tested**. Claude has a
beta.7 route, but no live run is verified (**Not yet tested**); the app labels
Claude "in development". Grok is not supported.
NivKode is a client for services you choose. We do not provide provider
accounts, pay provider charges or increase your account limits. Sign in
yourself, review the provider's current terms and privacy information, and
manage your own usage and billing.

| Provider | Status in 0.2.0-beta.7 |
|---|---|---|
| Ollama local models | **Tested** on earlier builds; beta.7 automated coverage is in `nivkode-rusty/gateway/src/main.rs` |
| Codex (external) | **Tested** on earlier builds (experimental); live beta.7 use is **Not yet tested** |
| Claude | Route present; **Not yet tested** (no live run verified; app label is "in development") |
| Grok | **Not yet tested**; not supported |

Local models answer questions, read workspace files, propose file changes for approval, and propose supported test and build commands for review and confirmation. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made.

## Codex external provider

The CLI starts a new conversation on an installed local route when one is
available; `--route codex` explicitly selects Codex. Install the Codex CLI, sign in on the
computer running the gateway, and use the account whose terms you accept:

```sh
codex login
```

The gateway starts `codex app-server` and hands it the turns you send. Codex
processes them under the account and service terms that apply to you. NivKode
sends your message, up to the last 16 messages of the conversation as context,
and any images you attach. Codex may also read your workspace during the run.

Things to know:

- **It is experimental.** The app-server protocol is marked experimental by
  Codex and changes between versions. We wrote the adapter against Codex CLI
  `0.155.0-alpha.16.3` and have no recorded test of another version. A phone
  completed live text and image turns and an artifact preview on 30 September,
  against an earlier build. On 6 October a four-turn desktop session on the
  2 November branch ran through the review gate, with approvals for a command
  and a file change, and a live run on the 6 October candidate passed after a
  clean install. A few sessions on one machine are not wide testing.
- **Sessions are read-only.** Every session and turn is read-only with no
  network access, and Codex must ask before it changes files or runs a command
  that needs more than that. Read-only commands, such as checking the current
  folder, can run inside that sandbox without asking.
  The gateway sets this itself, so your own Codex configuration cannot loosen
  it. You answer in the desktop client or the Android app, not in the terminal.
  See [Concepts](concepts.md#approvals-and-the-review-gate).
- **Project Codex configuration is refused.** A project `.codex` folder can hold
  settings that run code without asking, such as hooks and tool servers. If
  the workspace (or its repository) has a `.codex` folder with anything beyond
  `skills`, `prompts`, a README or a `.gitignore`, the gateway refuses Codex
  runs there and answers `workspace_codex_config_requires_owner_opt_in`. To
  allow it for a workspace you trust, add its ID to `codex_project_config_workspaces`
  in the gateway config. Codex's own folder trust still applies, so trust only
  repositories you own.
- **Finding Codex.** The gateway looks for `codex` on its `PATH`. If you start
  the gateway from a service or another shell where that fails, set `codex_bin`
  in the gateway config to the full path.
- **Status is approximate.** `nivkode status` and the desktop report whether the
  Codex helper process is running. That does not distinguish a missing program
  from a signed-out account.

## Ollama local models

The gateway can send prompts to an Ollama service on your computer. The
default address is `http://127.0.0.1:11434`, and it must be a loopback address.
Install Ollama, then pull a model, for example:

```sh
ollama pull qwen2.5:3b
```

When Ollama runs on your computer, prompts and responses stay there unless
your Ollama setup or the model separately connects elsewhere.

Local models answer questions, read workspace files, propose file changes for approval, and propose supported test and build commands for review and confirmation. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made. See [Privacy and
security model](privacy-and-security-model.md).
- Tool use depends on the model. In our check, `qwen2.5:3b` used the tools and
  `qwen2.5-coder:3b` printed the tool call as text instead.

Local file fixes are a preview. The gateway config key `local_fix_preview`
(default `false`) turns on edit proposals on the local model; while it is off,
an edit request gets a plain message and no approval. Commands, chat and file
reading are unchanged, and external providers are unaffected.

### Local routes

A local route maps a task type to a model, with fallbacks. The order comes from
a small check (eight prompts per route, scored by keywords, run once) and is not
a ranking of answer quality. The release bundles two:

| Route | First choice | Then, in order |
|---|---|---|
| `text.general` | `qwen2.5:1.5b` | `qwen2.5-coder:3b`, `qwen2.5-coder:7b`, `qwen2.5:3b`, `qwen3:8b` |
| `code.explain` | `qwen2.5:3b` | `qwen2.5-coder:7b`, `qwen3:8b`, `qwen2.5-coder:3b`, `qwen2.5:1.5b` |

The gateway uses the first model on the list that is installed and records any
fallback. If none is installed, the run fails and nothing else is substituted.
You can override the table with `route_bindings` in the gateway config.

In the terminal, choose a route with `--route text.general` or
`--route code.explain`. Without `--route`, a new conversation starts on the
first of these routes with an installed model, and never on Codex;
`--route codex` chooses Codex for that one conversation. The CLI cannot choose
an Ollama model directly; it uses the first installed one only when no route
has an installed model. The desktop can.

Doctor checks for `qwen2.5-coder:7b` by default. Pass your own model name with
`nivkode-doctor CONFIG --model NAME`.

## Claude

Claude has a route in beta.7, but no live run is verified (**Not yet tested**).
The beta.7 app labels Claude "in development". The route and adapter are
present in the gateway source; neither establishes a successful provider run.

Documentation we read when choosing that design:

- [Claude Code CLI reference](https://docs.anthropic.com/en/docs/claude-code/cli-usage)
- [Claude Code SDK and stream-json format](https://docs.anthropic.com/en/docs/claude-code/sdk)
- [Claude Code permissions and plan mode](https://docs.anthropic.com/en/docs/claude-code/iam)

## Phone and remote access

Phone or remote access needs a private route that you set up. NivKode does not
create a network proxy, firewall rule or public address.

## Responsibility

Provider services, account terms, availability, data handling, usage limits
and charges are controlled by their providers and may change. Choose where each
request goes, and do not send data you are not willing to share with that
service. For terms and a statement of responsibilities, see
the provider documentation.
