# SOS: switch a conversation engine

SOS moves a conversation to another engine when the current one has failed,
hit a usage limit, stopped responding or seems stuck. Only a paired device can
use it, and you confirm each switch.

## Switch an engine

1. Open the conversation and press **SOS** in the header.
2. The **Switch engine** dialog names the current engine and lists the engines
   the gateway reports as healthy. Choose one.
3. Press **Switch engine**. That press is your confirmation. **Cancel** or the
   Escape key closes the dialog without switching.

If the switch works, a short message says which engine you switched to. If it
fails, the dialog stays open and says the engine was not switched, and why. If
no engine is healthy, the desktop says so instead of opening the dialog.

The list includes Codex models when Codex answers, and local Ollama models when
the configured Ollama address answers. The phone offers the same choices.

## What happens

- The gateway checks again that the engine you chose still responds. Availability
  can change between listing and confirming, so the switch can fail safely.
- For Codex, it also checks again that Codex is signed in on the computer
  running NivKode. A signed-out Codex still lists its models, so the list alone
  cannot tell.
- It changes the conversation's provider and model in one step and adds a
  `conversation/engineSwitched` event to its history.
- The event records that you made the switch, and a bounded handoff: the
  conversation title, up to the last 20 saved messages, the workspace identity,
  any review items still open, and the old and new engine. A conversation that
  had no engine yet records `none` as the old one.
- Existing review state stays visible in the conversation history.

## When it is refused

| You see | Why |
|---|---|
| `conversation_missing_or_driver_busy` | A run in the conversation is starting, accepted or of unknown outcome. Only one engine drives a conversation at a time. |
| `ollama_unavailable` | Ollama is not running or did not answer the health check in time. Start or check Ollama, then retry the switch. |
| `engine_not_signed_in` | Codex is not signed in on the computer running NivKode, or did not say within 5 seconds that it is. |
| `engine_not_configured` | The request named no engine, or the engine is not Codex or a local Ollama model. |
| `owner_confirmation_required` | The request did not carry your confirmation. |
| **No healthy engines** | The gateway reports no working provider. Fix Codex or Ollama first. |

If an unknown outcome blocks the switch, see
[Troubleshooting](troubleshooting.md#outcome-unknown).

## What SOS does not do

- It does not start a remote shell or wake a provider process.
- It does not infer provider quotas. It reports only the health it observes.
- It is not a full recovery workflow. A fuller one is not part of 0.2.0-beta.7.
