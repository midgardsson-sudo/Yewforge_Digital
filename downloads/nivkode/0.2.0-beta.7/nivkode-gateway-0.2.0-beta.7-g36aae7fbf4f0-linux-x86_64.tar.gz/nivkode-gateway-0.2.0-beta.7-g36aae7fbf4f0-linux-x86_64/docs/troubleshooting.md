# Troubleshooting

Find the message you see, read what it means, and follow the steps. The
messages are the ones NivKode prints or shows. The desktop shows gateway
errors as plain sentences; the CLI and the API return the codes listed here. For the words used here, see
[Concepts](concepts.md). For things that are not built yet, see
[Beta limitations](beta-limitations.md).

On this page, `CONFIG` is the path to your gateway config, and `PORT` is the
port in its `listen` setting. The default is `127.0.0.1:8789`. The install
guide's example uses `18789`.

## Start here

1. **Run Doctor.** It checks your setup, changes nothing and never prints
   credentials.

   ```sh
   nivkode-doctor CONFIG
   ```

   Every line starts with `PASS`, `WARN` or `FAIL`, and a `FAIL` includes a fix.
   Warnings about `cargo`, `rustc` and the Android tools do not matter if you
   installed the prebuilt package. Doctor exits with an error if any line is a
   `FAIL`. Today that includes a missing Ollama or a missing checked model
   (`qwen2.5-coder:7b` by default), even if you only use Codex. In that case
   you can go on. To check a different model, give the config path first:
   `nivkode-doctor CONFIG --model NAME`. Run Doctor before you start the
   gateway. While the gateway is running, the port check reports `FAIL`,
   because the port is in use.

2. **Ask the gateway for its status.**

   ```sh
   nivkode status
   ```

   It prints four lines: `Gateway: ok`, a Codex line, the installed Ollama
   models, and the engine new conversations start on. On the Codex line, "signed in yes" means the gateway's own check found
   a signed-in Codex account; "no" means it did not, even if the Codex helper
   process is running.

3. **See the gateway's messages.** By default the gateway logs almost nothing.
   Stop it and start it again with logging on:

   ```sh
   RUST_LOG=info nivkode-gateway serve CONFIG
   ```

4. **Check that it is alive.** This needs no token:

   ```sh
   curl http://127.0.0.1:PORT/health
   ```

   `"status":"ok"` means the gateway is up. `"codexConnected":false` means the
   Codex helper is not running.

## The gateway will not start

| You see | What it means | What to do |
|---|---|---|
| `could not read config file …` | The path is wrong. With no path, the gateway uses the same default as the CLI and Doctor: `$NIVKODE_GATEWAY_CONFIG`, else `$XDG_CONFIG_HOME/nivkode/gateway.json`, else `~/.config/nivkode/gateway.json`. | Pass your config path as the last argument. |
| `the gateway config … holds admin_token but other users can read it (mode …); make it private with: chmod 600 …` | The config contains `admin_token`, and other users on this computer could read it. The gateway refuses to start rather than expose the token. | Run the `chmod 600` command it prints, then start the gateway again. The message never shows the token. |
| `invalid gateway JSON config` | The file is not valid JSON, or a field has the wrong type. | Fix the JSON. A missing comma is the usual cause. |
| `state_dir must be absolute` or `workspace path for … must be absolute` | A path starts with `~` or is relative. | Write full paths that start with `/`. |
| `workspace … does not exist` or `… is not a directory` | A workspace path is wrong. | Create the folder or fix the path. |
| `configure at least one explicit workspace root` | `workspaces` is empty. | Add at least one workspace. |
| `workspace IDs must be unique` or `workspace roots must be unique` | Two entries share an ID or a folder. | Remove the duplicate. |
| `Ollama endpoint must be a credential-free loopback HTTP origin` | `ollama_endpoint` is not plain `http://127.0.0.1:PORT`. | Use the default, or another loopback address with no path or login. |
| `gateway must bind to loopback; expose it only through the configured private HTTPS proxy` | `listen` is not a loopback address. | Use `127.0.0.1:PORT`. For phone access, put your own HTTPS route in front. |
| `admin_token must contain at least 32 characters` | The admin token is too short. | Use 32 or more random characters, or remove it. |
| `… exists and is not a socket; …` or `could not create the admin socket …` | With `admin_token` set, the gateway serves its device admin routes on a socket: `admin.sock` in the state directory, or, when that path is longer than the 107 bytes a socket path holds, a socket in `$XDG_RUNTIME_DIR/nivkode`. Something else is at that path. The gateway never deletes a file it did not make. | Move that file away, or set `admin_token` to `null`. `nivkode-gateway admin-socket` prints the path. |
| `the admin socket path … would be … bytes, more than the 107 …` | The state directory's path is too long for a socket, and there is no safe short place for it: `XDG_RUNTIME_DIR` is not set (for example under `sudo -u` or a system service) or not an absolute path. Doctor reports this before the start. | Start the gateway from a login session or a systemd user service, choose a shorter `state_dir`, or set `admin_token` to `null`. |
| `the runtime directory (XDG_RUNTIME_DIR) …` or `the admin socket directory … is a symbolic link / belongs to another user / is mode …` | The gateway makes the long-path socket only in a real directory that belongs to you and is closed to other users. | Use `chmod 700` on the folder it names, or remove a link or a folder you did not make; the gateway makes `nivkode` itself. |
| `admin socket ancestor … is a symbolic link / is writable by other users / belongs to an untrusted user (uid …)`, or Doctor's `admin socket` `FAIL` with the same words | Every folder above the admin socket, from `/` down, must be a real folder that belongs to root or to you and that no one else can write to. Otherwise another user could swap a folder on the path. Shared folders such as `/tmp` and `/var/tmp` are writable by everyone, so a `state_dir` inside one is refused even though its path is short. In a container or sandbox, `uid 65534` is how it shows an owner from outside it, which the gateway cannot identify. | Follow the step after the message (Doctor's `Fix`). For a socket in the state directory: choose a `state_dir` under a folder only you and root can change, such as one in your home folder. For a socket in `XDG_RUNTIME_DIR`: start the gateway from a login session or a systemd user service. In a sandbox, run the gateway outside it. Or set `admin_token` to `null`. |
| `nivkode-gateway admin-socket`: `no gateway has started with this config yet: … does not exist` | The gateway makes its state directory, and the socket in it, on its first start. | Start the gateway with the `nivkode-gateway serve CONFIG` command it prints, then run `admin-socket` again. |
| `nivkode-gateway admin-socket`: `no gateway is running with this config: …` | The gateway is not running. "Left from a gateway that has stopped" means the socket file is still there; the next start replaces it. "In this login session" means the socket would be in this shell's `XDG_RUNTIME_DIR`, and nothing is there. | Start the gateway with the command it prints. If the gateway runs in another login session, run `admin-socket` there. |
| `nivkode-gateway admin-socket`: `cannot find the admin socket from this shell: …` | With a long `state_dir`, the socket is in the gateway's `XDG_RUNTIME_DIR`. This shell has none (for example under `sudo -u` or a system service), so it cannot find it. The gateway may well be running. | Run the command from the login session the gateway runs in, or set `XDG_RUNTIME_DIR` to that session's value. |
| `403` `admin_routes_use_the_local_admin_socket` | The admin routes are not served on the gateway's port, because a proxy such as Tailscale Serve reaches that port from the computer itself. | On the gateway computer: `curl --unix-socket "$(nivkode-gateway admin-socket)" -H "Authorization: Bearer $ADMIN_TOKEN" http://localhost/v1/admin/devices`. |
| Doctor `Tailscale route` `WARN` "cannot tell" | Doctor could not ask Tailscale whether Serve forwards to the gateway, or Serve forwards to the gateway's port at an address Doctor cannot match to this computer (such as `0.0.0.0` or a host name other than `localhost`). It cannot see other proxies at all. | Run `tailscale serve status` and look for the gateway's port. If the route is meant for the gateway, point it at `http://127.0.0.1:PORT`, and turn Funnel off on it. |
| Doctor `Tailscale route` `FAIL` "Funnel publishes the gateway" | Tailscale Funnel puts the gateway on the public internet. | Run the `tailscale funnel … off` command Doctor prints. Use Serve (tailnet only) for the phone. |
| `nivkode-gateway: unknown command '…'`, `unknown option '…'` or `unexpected argument '…'`, followed by a usage list | The gateway does not know that command or option. | Run `nivkode-gateway --help` for the list. `--help` and `--version` work before any config exists. Start the gateway with `nivkode-gateway serve CONFIG`; print a pairing code with `nivkode-gateway pair-code CONFIG`. |
| `could not listen on …`, or Doctor's `gateway port` `FAIL` | Another program is using the port. The message says what holds it when it can tell. | If it is another NivKode gateway, stop it first. Otherwise pick a free port in `listen`, and use the same port in `--gateway`. |
| `another NivKode gateway (process …) is already serving the state directory …` | A gateway is already running on this state directory, on some port. | Stop that gateway first. A second gateway needs its own `state_dir`; do not share one between configs. |
| `the state directory lock … is a symbolic link, which the gateway never follows; remove … and start the gateway again; it recreates the file` (or `… is not a regular file` or `… belongs to another user`) | Something other than the gateway's own lock file is at `gateway.lock` in the state directory. The gateway stops before it writes anything. | Remove that `gateway.lock` and start the gateway again. If you did not put it there, check who else can write to your state directory. |
| Doctor `config permissions` `FAIL` | Others can read the config. If it holds `admin_token`, Doctor also says the gateway will not start. | `chmod 600 CONFIG` |
| Doctor `state directory` or `device token store` `FAIL` | The state directory or database is too open. | `chmod 700` the directory and `chmod 600` the `nivkode.sqlite3` file. |

## Pairing and connecting

| You see | What it means | What to do |
|---|---|---|
| `nivkode pair` prints a usage error | It needs a code argument. | On the gateway computer run `nivkode-gateway pair-code CONFIG`, then `nivkode pair CODE`. |
| `not paired or pairing expired; run nivkode pair <one-time-code>` | The gateway rejected your token (HTTP 401): never paired, expired (tokens last 90 days), or revoked. | Get a new code and pair again. |
| `nivkode-gateway pair-code` prints `database is locked` | The running gateway was busy writing for more than 5 seconds, for example while it stored a large burst of events. Nothing was changed. | Run the same command again. |
| `invalid_or_expired_pair_code`, or a message that the pairing code **was not accepted** | The code is wrong, was used, is older than 10 minutes, or was replaced by a newer code. | Run `nivkode-gateway pair-code CONFIG` again and use the new code once. Each device needs its own code. |
| A message that the gateway **is down or unreachable** | The gateway is not running, or the CLI is using another address. Newer builds name the address that failed. | Start the gateway. Pass `--gateway http://127.0.0.1:PORT` or set `NIVKODE_GATEWAY`. After a successful pairing, the CLI remembers the address. |
| `CLI credentials have unsafe permissions; run chmod 600 …` | The CLI config file is readable by others. | Run the `chmod 600` command it prints. |
| `not paired; run nivkode pair <one-time-code> first` | `nivkode open` has no token. | Pair first. |
| `nivkode open only launches the loopback desktop client` | The saved gateway address is not loopback. | Use a loopback address, or open the page yourself. |
| A message about `xdg-open`, such as `could not open a browser` | `nivkode open` needs `xdg-open` and a graphical session. | Install it, or run the command from a desktop session. If the message prints a one-use link, paste it into a browser on this computer within 45 seconds. |
| `nivkode open` says "Opened NivKode in your browser", but nothing appears | The command cannot always tell whether a browser opened. A launcher that keeps running counts as a browser starting. | Check your default browser, then run `nivkode open` again from a graphical session. |
| **This one-time handoff has expired. Run nivkode open again.** | The link works once, for 45 seconds, and only in a browser running as the same local user. A reload, a second tab or a slow start uses it up. | Run `nivkode open` again. |
| **Paste a paired device token or launch this page with nivkode open.** | The page has no token. Reloading the page forgets it. | Run `nivkode open`. |
| **This page can connect only to the gateway it was opened from, at …** (older versions: **Open NivKode from the local gateway so requests stay same-origin.** or **For security, the desktop client only connects to the gateway that served this page.**) | The address in the form is not the one that served the page. | Press **Use this page's gateway**, or open the other gateway's own page at its address followed by `/desktop`. `nivkode open` opens the right page for the gateway it is paired with. |
| **This window is no longer signed in to the gateway.** (`unauthorized` from the CLI or API) | The token is missing, wrong, expired or revoked. | Run `nivkode open` to reconnect. If this computer was unpaired, get a new code with `nivkode-gateway pair-code CONFIG` and pair again with `nivkode pair`. |

On the phone:

| You see | What it means | What to do |
|---|---|---|
| **This phone is no longer paired with your computer.** | The gateway refused the phone's token: it was revoked, it expired, or the gateway's state was reset. The app has forgotten the token and stopped reconnecting. | On the gateway computer run `nivkode-gateway pair-code CONFIG`, then pair the phone with the new code. |
| **That pairing code is invalid or has expired.**, **That pairing code has expired.** or **That pairing code was not accepted.** | The code is wrong, was used, is older than 10 minutes, or was replaced by a newer code. | Get a new code with `nivkode-gateway pair-code CONFIG` and enter it once. |
| **This request stopped waiting before you answered it. The run ended, or another device answered it.** | The request closed without this phone's answer. | Nothing to answer. Check the conversation. |

## Offline, reconnecting and unknown outcomes

The desktop checks the gateway every 3 seconds. You may see these states:

| You see | What it means |
|---|---|
| Reconnecting to gateway… | A check failed. The page keeps trying. |
| Offline | The gateway has not answered for about 4 seconds. |
| Gateway restarted · connected | The gateway came back with a new instance. The page reloaded the conversation from saved history. |

What to do:

- Check that the gateway terminal is still running, that the port matches, and
  that `nivkode status` works.
- A message you send while offline is queued in that browser tab and sent once
  when the connection returns, with the same idempotency key, so it cannot be
  sent twice. It only sends for the conversation you have open. Keep the tab
  open. Closing it loses the message.
- A message sent while online whose result is uncertain is **not** retried.
  You see **Could not confirm the run**, **Outcome unknown** or **Still
  waiting**. Reload the conversation (press **Check saved state** if it is
  offered) and look at the workspace before you send again.

Other notices in the conversation:

| You see | What it means | What to do |
|---|---|---|
| **Choose an engine below before you send.** | No local model is installed (or Ollama has none of the models the bundled routes use), and NivKode does not pick Codex for you. | Choose an engine under **Use**: Codex, or a local model once you have pulled one with Ollama. |
| **Codex didn't answer; showing the saved state.** (after **Check again**) | Codex did not answer the check in time, or it is not running. The conversation shows what the gateway has stored. | Make sure Codex is running, then press **Check again**. |
| **Outcome unknown**: "The gateway cannot confirm whether this run finished." | See [Outcome unknown](#outcome-unknown). | Press **Check again**, then inspect the workspace. |
| **Run interrupted**: "This run stopped before a confirmed completion." | The provider stopped the turn early. | Press **Check again** and inspect the workspace before you continue. |
| **Run failed**, with a reason such as "The model returned an empty answer." or "The model read too many workspace files in one turn without answering." | The run ended with an error. For a local model the notice says why; otherwise it says "The run stopped with an error." | Follow the advice in the notice: try again, choose another model, or name the files you mean. Open **Details** for the full record. |

### Outcome unknown

It means NivKode cannot tell whether the provider finished. This happens when
the gateway or Codex restarts mid-run, or when a Codex request times out or
loses its connection. It is not the same as failed: work may have happened.
Look at the conversation and the workspace, then decide whether to continue.
Local models cannot change files in this build. Proposing file edits and
Local models can propose supported test and build commands for review and confirmation.

After a restart, or when Codex refused to start the turn, the gateway accepts
new messages in that conversation again, and the desktop offers **Send** again:
the notice keeps **Outcome unknown** and says the run is no longer running.
After a timeout or a lost connection while the gateway kept running, the
gateway refuses them with `idempotency_or_active_driver_conflict` until it
restarts, and the desktop keeps **Send** off in that conversation and says the
run may still be running. To carry on:

1. For a Codex run, make sure Codex is running, then press **Check again**.
   NivKode asks Codex for the thread's history and updates the run if Codex
   shows how the turn ended. We have not seen this work in a recorded run, so do
   not count on it.
2. If **Send** stays off, start a new conversation in the same workspace. The
   old one stays readable, and other conversations are not affected.

After a restart, requests that were waiting for your approval are marked stale
and can no longer be answered. Send the task again.

## Codex is unavailable

In the desktop you may see **Codex is not running for this gateway.** From the
terminal you may see `codex_unavailable`, **Codex is unavailable. Install Codex and
sign in with your own account: `codex login`**, `codex_thread_start_failed`,
`codex_request_failed` or `provider_session_unavailable`.

If Codex is restarting, a message is refused with `codex_unavailable` and
nothing is sent. Send it again once Codex is back; the same message is then
accepted.

1. Install the Codex CLI on the computer that runs the gateway.
2. Run `codex login` there, with your own account.
3. Make sure the gateway can find the program. It looks for `codex` on its
   own `PATH`. If it does not, set `codex_bin` in the config to the full path
   and restart the gateway.
4. Run `curl http://127.0.0.1:PORT/health`. When `codexConnected` is `true`,
   the helper is running. The gateway retries every 3 seconds, so you do not
   need to restart it after installing Codex.
5. If it still fails, remember that the Codex helper protocol is experimental.
   We have only checked it against Codex CLI 0.155.0-alpha.16.3. See
   [Beta limitations](beta-limitations.md#codex-support-is-experimental).

Other codes:

| You see | What it means | What to do |
|---|---|---|
| **NivKode always asks before it changes your workspace, so the gateway refused a message sent without that safeguard.** (`owner_approval_required` from the CLI or API) | A message arrived without the approval safeguard, for example from a desktop page opened before an update, or from your own API call. NivKode always asks before it changes your workspace, so the gateway refused it. The desktop says this in plain words. | Reload the desktop page, then send again. |
| **This workspace has its own Codex settings, so NivKode will not send it to Codex.** (`workspace_codex_config_requires_owner_opt_in` from the CLI or API) | The workspace, or the repository around it, has a project `.codex` folder with settings beyond `skills`, `prompts`, a README or a `.gitignore`. Such settings can run code without asking. | Remove them, or add the workspace ID to `codex_project_config_workspaces` in the gateway config if you trust the repository, then restart the gateway. |
| **That model is not available.** (`model_not_available` from the CLI or API) | The model is not in Codex's list. | Pick a listed model. |
| **This model does not offer that reasoning effort.** / **Choose a model before setting the reasoning effort.** (`effort_not_supported`, `model_required_for_effort` from the CLI or API) | A reasoning effort the model does not offer. | Leave the effort unset, or pick a model that offers it. |
| **This model can't read images.** (`image_not_supported` from the CLI or API) | The model takes no images. | Send text only, or pick another model. |

## A local model is missing or fails

| You see | What it means | What to do |
|---|---|---|
| **No route or model is available for this workspace yet.** | The composer is disabled because there is no installed local model and Codex is not available. | Install and start Ollama and pull a model, or set up Codex. |
| **Ollama is not running, or did not answer in time.** (`ollama_unavailable` from the CLI or API) | The gateway could not reach Ollama within 2 seconds. | Start Ollama. Check `curl http://127.0.0.1:11434/api/tags`. If you changed the address, check `ollama_endpoint`. |
| **Ollama answered with something NivKode could not read.** (`ollama_catalog_invalid` from the CLI or API) | Ollama answered with something unexpected. | Update or restart Ollama. |
| **That model is not installed in Ollama.** (`model_not_installed` from the CLI or API) | The model you chose, or every model of the route, is not installed. A route never substitutes a model that is not on its list. | Run `ollama list`, then `ollama pull MODEL`. See the route lists in [Concepts](concepts.md#local-routes). |
| **That route is not set up on this gateway.** / **That route works only with local models.** (`mos_route_unknown`, `mos_route_requires_local_provider` from the CLI or API) | The route name is not `text.general` or `code.explain`, or you paired a route with Codex. | Pick a listed route with a local model. |
| **Local models take text only.** (`local_capability_not_supported` from the CLI or API) | You sent an image or a reasoning effort to a local model. | Local models take text only. |
| **Choose a model or a route first.** (`model_required` from the CLI or API) | A local request named no model and no route. | Choose a route, or a model. |
| The run ends as **Failed** (`local_model_failed`) | Ollama returned an error, stopped answering, timed out after 180 seconds, or the model was removed mid-run. | Check `ollama list` and `ollama ps`, read Ollama's own log, and try a smaller model. |
| The reply is a JSON snippet such as `{"name":"read_workspace_file", …}` | The model wrote its tool call as text instead of using it. | Use another model. In our checks `qwen2.5:3b` used the tools and `qwen2.5-coder:3b` did not. |
| A reply says the listing or a file could not be read | The local file tools have limits: 64 files, 32 KiB per file, no private-looking names. | See [Concepts](concepts.md#providers). Name the file you want read. |
| The run record says "Fallback: primary model … is not installed" | Expected when only a later model of the route is installed. | No action. The record shows which model answered. |

## Reviews, approvals and notes

| You see | What it means | What to do |
|---|---|---|
| **This request is no longer waiting for a decision.** (`request_not_pending` from the CLI or API) | The run ended, another device answered first, or the request went stale after a restart. | Nothing to approve. Send the task again if you still want it done. |
| **That decision was not recognised.** (`invalid_decision` from the CLI or API) | The decision was not accept, decline or cancel. | This should not appear in the desktop. Report it. |
| A Codex run started in the terminal seems stuck | It may be waiting for an approval, which the terminal client cannot answer, or for an answer to a question. | Open the conversation in the desktop client (`nivkode open`) and answer the approval there. The desktop cannot answer a question in 0.2.0-beta.7: if it shows **Codex asked a question**, press **Stop** to end the turn. If you use the Android app, you can answer the question there instead. |
| **Codex asked for something this version of NivKode can't handle.** (`unsupported_request` from the CLI or API) | Codex asked for a kind of decision NivKode cannot pass back to it. No device can answer it, the Android app included. | Press **Stop this run** in the notice, or **Stop**, to end the turn. |
| **Codex asked a question**: "This version of the NivKode desktop can't answer this question yet. To end the run, press Stop. If you use the NivKode phone app, you can answer it there." | Codex is waiting for an answer. This version of the desktop cannot answer it; the Android app can. | Press **Stop** to end the turn. If you use the Android app, you can answer it there instead. |
| **No test results reported for this run.** | The provider ran no command that looks like a test, or none finished with an exit code. NivKode does not run tests. | Run the tests yourself. |
| **Notes must be 1 to 4,000 characters.** (`note_text_invalid` from the CLI or API) | The note is empty or longer than 4,000 characters. | Shorten it. |
| **That note no longer exists.** / **This file is no longer listed for the run.** / **That run no longer exists.** (`note_not_found`, `artifact_not_found`, `run_not_found` from the CLI or API) | The note, artifact or run does not exist in this conversation. | Reload the conversation. |
| **Offline. Reconnect before saving this note.** | The gateway is not reachable. | Reconnect, then save again. Your text stays in the box. |
| **Notes could not be loaded** | The gateway returned an error. | Press **Retry loading notes**. |
| No artifacts in the review card | Only Codex runs create artifacts, and only for images and changed files inside the workspace. | Nothing is wrong with a local run. |
| **NivKode can't preview this kind of file.** / **This file is no longer in the workspace.** (`artifact_type_not_supported`, `artifact_unavailable` from the CLI or API) | The file is a type NivKode does not show (SVG, archives and other binaries), is over 5 MiB, or is outside the workspace. | Open it from your file manager. |

## The Workers view

- **No worker runs recorded for this workspace.** You have not sent anything
  in this workspace yet. The roster only lists runs NivKode recorded.
- **Could not load worker activity.** Press **Refresh**. If it repeats, check
  the gateway.
- `UNKNOWN` in a field is normal where NivKode has no record. A local run has
  no session ID, and a conversation with no recorded branch has none either.
- A row marked `uncertain` is a run whose outcome is unknown or interrupted.

## The Director panel

- The desktop shows the **Director** button only when the gateway is set up
  for the separate Director service. From the CLI or the API,
  `director_chat_not_configured` means it is not set up; ignore it if you do
  not use that service.
- `director_chat_unavailable` means the gateway could not use the service. Check
  that the service is running on this computer, that `factory_url` in the
  `director_chat` block is a plain `http://127.0.0.1:PORT/` address, and that
  the owner token file is a regular file with mode `0600`. The desktop does not
  show more detail, on purpose.
- "sent (accepted)" means the service took your message. A reply may take a
  while.

## Stopping a run

| You see | What it means | What to do |
|---|---|---|
| **Stopping…**, then "Still stopping. Codex has not confirmed the stop yet." | Codex has not ended the turn yet. The final outcome always comes from Codex. | Wait. The run then ends as **Run stopped**, or as finished if it got there first. |
| **Run stopped**: "You stopped this run before it finished." | Codex ended the turn after you pressed **Stop**. | Check the conversation and your workspace before you continue. |
| **Stopping…**, then "Still stopping. The gateway has not confirmed the stop yet." | A local model's reply is being stopped, and the gateway has not recorded the end yet. | Wait. The run then ends as **Run stopped**, or as finished if it got there first. |
| **Run stopped**: "You stopped this reply before it finished. You can send a new message now." | The gateway stopped the local model's reply after you pressed **Stop**. | Send a new message when you are ready. |
| **Nothing is running to stop.** (`no_active_turn` from the CLI or API) | The run had already ended, or it is a local reply that this gateway process is not running, for example one from before a restart. | Nothing to do. |
| **The run is still starting, so it can't be stopped yet.** (`turn_not_started` from the CLI or API) | Codex has not reported the turn yet. | Try again in a moment. |

## Switching engines (SOS)

| You see | What to do |
|---|---|
| **A reply in this conversation is still starting, running or unconfirmed.** (`conversation_missing_or_driver_busy` from the CLI or API) | A run in this conversation is starting or accepted, or has an unknown outcome while the gateway may still be running it. Wait for it to finish. After a gateway restart an unknown outcome no longer blocks the switch. |
| **Ollama is not running, or did not answer in time.** (`ollama_unavailable` from the CLI or API) | Start Ollama, check `ollama_endpoint` in the gateway config, then retry the switch. |
| **Codex is not signed in on the computer running NivKode.** (`engine_not_signed_in` from the CLI or API) | Run `codex login` there, then try again, or keep using a local model. |
| **That engine is not set up on this gateway.** (`engine_not_configured` from the CLI or API) | The engine is not one NivKode knows, or no engine was named. |
| **This change needs your confirmation.** (`owner_confirmation_required` from the CLI or API) | Confirm the switch. |
| **No healthy engines** | The gateway reports no working provider. Fix Codex or Ollama first. |
| **The engine was not switched.**, followed by a reason | The gateway refused the switch, or the engine stopped answering between listing and switching. Read the reason, then try again or choose another engine. |

## Missing history

- The list shows only the 100 most recently updated conversations in the
  workspace. Older ones are stored but not listed.
- Check the workspace selector. Conversations belong to one workspace.
- The state directory holds everything. Do not delete `nivkode.sqlite3` unless
  you mean to erase your history.

## Other messages

| You see | What it means |
|---|---|
| **That workspace is no longer configured on this gateway.** (`workspace_not_found` from the CLI or API) | The ID is not in your config. |
| **A different message was already sent with this request.** (`idempotency_key_conflict` from the CLI or API) | The same key was reused for a different request. |
| **Another reply is still in progress in this conversation.** (`idempotency_or_active_driver_conflict` from the CLI or API) | A run in this conversation is still starting, accepted or of unknown outcome. Wait, or see [Outcome unknown](#outcome-unknown). |
| **The message is too long.** (`input_limit_exceeded` from the CLI or API) | The message is empty, is over 32,000 bytes, or comes with more than 4 images. |
| **That image is too large.** / **That image type is not supported.** (`image_too_large`, `unsupported_image_type` from the CLI or API) | Images must be small raster files (8 MiB limit). |
| **The gateway refused a request that came from another site.** (`cross_site_request_refused` from the CLI or API) | A browser marked the request as anything other than same-origin (for example a page served from another port on this computer), or it carried an `Origin` other than the gateway's own address (including an opaque origin), or it repeated the `Origin`, `Host` or `Sec-Fetch-Site` header. NivKode's own pages do not do this. Use the desktop page that `nivkode open` opened. |
| **Too many sign-in links are waiting.** (`desktop_handoff_limit_reached` from the CLI or API) | The gateway holds at most 32 unexpired links across all paired devices, each for 45 seconds. If this device already has a link waiting, running `nivkode open` again replaces its oldest link. Otherwise, wait up to 45 seconds for a link to expire, then run `nivkode open` again. |
| **The gateway could not read or save its data.** (`storage_error` from the CLI or API) | The gateway could not read or write its database. Check disk space and the permissions of the state directory. |

## Still stuck?

Open an issue and include: the NivKode version, your Linux distribution, the
Doctor output, the exact message, and what you did. Leave out tokens, pairing
codes, your config file and your conversation text. If you think you found a
security problem, report it privately as described in `SECURITY.md`, and do not
post it in a public issue.

For setup help see [Install](install.md), and for accounts see
[Providers](providers.md).
