# NivKode phone/gateway API R0

The full R2 protocol contract for conversation, activity, diff, command-result
and artifact data is maintained in the source repository.

All routes except `/health` and `/v1/pair` require a device bearer token, except
the administrative device routes. Those are not served on the gateway's TCP
listener at all (it answers them `403 admin_routes_use_the_local_admin_socket`):
a proxy such as Tailscale Serve connects from `127.0.0.1`, so a loopback peer
proves nothing. They are served only on the owner-only Unix socket
`STATE_DIR/admin.sock`, which exists while `admin_token` is set. When that path
is longer than a socket address holds (107 bytes on Linux), the socket is
`$XDG_RUNTIME_DIR/nivkode/admin-<first 16 hex digits of SHA-256 over state_dir>.sock`
instead, in a directory the gateway creates 0700 and checks (not a link, owned
by the gateway's user, no group or other access; the runtime directory itself
likewise). Every ancestor, `/` included, must be a real directory owned by
root or the gateway's user and not writable by other users; shared paths such
as `/tmp` are refused. Whoever owns `/` gets no trust of its own: inside a user
namespace (a container or sandbox) an owner from outside shows as uid 65534,
which every unmapped host user shares, so where `/` or an ancestor shows as
65534 the gateway refuses the admin socket and does not start. An abstract socket is never used. `nivkode-gateway admin-socket [CONFIG]`
prints the path only when it connects to a live socket owned by the gateway
user. A different `XDG_RUNTIME_DIR` or a stopped gateway fails clearly. The
routes need the admin bearer token, a peer running as the gateway's own user, and no proxy
headers (`Forwarded`, `X-Forwarded-*`, `X-Real-IP`, `Via`, `Tailscale-*`):
`curl --unix-socket "$(nivkode-gateway admin-socket)" -H "Authorization: Bearer $ADMIN_TOKEN" http://localhost/v1/admin/devices`.
Configure `admin_token` in the private gateway config; use
at least 32 random characters. Device tokens expire after 90 days by default;
set `device_token_ttl_seconds` to change the lifetime.
Pairing consumes a one-time, expiring code and returns a device token once;
The gateway persists only the token hash. The Android client encrypts the token with
an Android Keystore AES key. Production phone requests use the private HTTPS
route. The gateway binds to loopback by default.

| Method | Route | Purpose |
|---|---|---|
| GET | `/health` | Sanitized gateway/Codex process status |
| POST | `/v1/pair` | Consume pairing code; issue a scoped device token |
| POST | `/v1/device/rotate` | Rotate the current device token; the previous token stops working |
| GET | `/v1/admin/devices` | List device metadata, including creation, expiry, and last use (admin socket only) |
| DELETE | `/v1/admin/devices/{id}` | Revoke a device token (admin socket only) |
| GET | `/v1/workspaces` | Return configured workspace IDs and labels |
| GET | `/v1/threads?workspace_id=…` | List Codex threads in one approved workspace |
| POST | `/v1/threads` | Start a Codex thread in an approved workspace |
| GET | `/v1/threads/{id}` | Read thread, turns, and timeline items |
| POST | `/v1/threads/{id}/turns` | Idempotently submit text and bounded images |
| POST | `/v1/threads/{id}/interrupt` | Interrupt the active Codex turn |
| GET | `/v1/threads/{id}/events?since=N` | Replay durable normalized events after sequence N |
| GET | `/v1/threads/{id}/requests` | Read pending Codex approval/input requests |
| POST | `/v1/requests/{id}/respond` | Answer only the stored upstream request's allowed choices |
| POST | `/v1/threads/{id}/turns/{turn}/undo` | `{id}` is the conversation or local thread ID. Undo approved local-model file changes for this turn when the saved file state still matches. Errors: `404 local_snapshot_not_found` (nothing applied), `409 local_turn_already_undone`, or `409 local_undo_refused`. This does not undo commands. |
| GET | `/v1/threads/{id}/artifacts` | List artifacts under approved roots |
| GET | `/v1/artifacts/{id}` | Read metadata for a registered artifact |
| GET | `/v1/artifacts/{id}/content` | Read bounded text/image content for a registered artifact |
| GET | `/v1/capacity` | Return optional provider-neutral capacity; unknown by default |
| POST | `/v1/conversations/{id}/interrupt` | Stop the conversation's running turn: records `run/stopRequested` and answers `202 {"runId", "status":"STOPPING"}`. For Codex it asks Codex to end the turn, and the final status comes from Codex. For a local model it drops the in-flight Ollama request and ends the run with `run/interrupted` (`reason: "stopped_by_owner"`). Refuses with `409 no_active_turn` (nothing running, or a local run this gateway process is not running) or `turn_not_started` |
| GET | `/v1/providers` | Lists Ollama (`kind: "local"`), Codex, and Claude Code (`kind: "hosted"`) with model and sign-in status. A listed provider is not a claim that its route has completed a live test: Codex is Tested (experimental); Claude has a beta.3 route, but no live run is verified (**Not yet tested**), and the app labels Claude "in development". Ollama model rows include `sizeBytes` from Ollama's local tags API. Codex `available` only means the app-server listed models, including when Codex is signed out; `signedIn` fails closed (an unrecognised account, an error, or no answer within 5 seconds is false). A custom Codex model provider is not detected. `sendsTo` identifies OpenAI or Amazon Bedrock where detected. No Codex account details are exposed. Claude's entry is always listed with one default model; only `signedIn` reflects the host CLI. |
| GET | `/v1/settings/local-only` | Return whether Local only is enabled (`localOnly`). |
| PUT | `/v1/settings/local-only` | Set `{"enabled":true|false}`. While enabled, the gateway refuses external-provider turns and second opinions. Enabling it stops active external-provider runs. If they cannot be stopped, the gateway sets Local only back to off and answers 503. |
| GET | `/v1/capabilities` | Paired devices only. Returns `{"directorChat": bool}`: whether this install has Director chat configured. Sent with `Cache-Control: no-store`. The desktop shows the Director panel only when it is `true` |

## Conversation events

`GET /v1/conversations/{id}` includes a `receipt` on each run, assembled from
that run's recorded route and event metadata. It reports engine residency/name,
route and fallback, distinct file paths read, applied and declined file paths,
command exit statuses, and elapsed milliseconds. `localOnly` and `undoHandle`
are present as nullable fields for client compatibility. Receipts contain no
prompt, message, diff, command, or file contents; a missing command exit status
is `null`.

Undo applies only to approved local-model file changes recorded for that turn.
It restores the saved file state and refuses if a file changed after the
approved edit. It never undoes commands.

`GET /v1/conversations/{id}/events?since=N` returns the conversation's events
after sequence `N`, oldest first, at most 500 per call. Each answer also has
`nextSince` (the last returned sequence) and `hasMore` (whether later events
exist): ask again with `since=nextSince` until `hasMore` is false. Run
events carry the run's `runId`. Kinds a client should handle include:

| Kind | Meaning | Payload |
|---|---|---|
| `run/dispatching`, `run/accepted` | The run is being sent; the gateway recorded it as accepted (this does not prove delivery) | status and routing details |
| `run/completed` | The run finished, for local and Codex runs alike | `status: "COMPLETED"`, the final reply as `text` |
| `run/failed` | The run ended with an error | `status: "FAILED"`, `error`, `reason`, and for local runs a plain `message`. Local reasons: `empty_answer`, `tool_limit`, `unknown_tool`, `provider_error`; Codex failures use `error: "codex_turn_failed"` and may have reason `provider_error` or `storage_error`. `storage_error` means the gateway could not store part of the reply: the run fails, the partial reply is not kept, and earlier messages remain unchanged. |
| `run/interrupted` | The run ended before finishing: a Codex turn, for example after Stop or an app-server crash, or a local reply the owner stopped | `status: "INTERRUPTED"`; a crashed Codex run with saved reply text has `partial: true` and `reason: "codex_restart"` or `"gateway_restart"`; a stopped local reply has `reason: "stopped_by_owner"` |
| `run/nativeHistoryInterrupted` | A final Codex history page marked a previously running turn interrupted; recovery checks its saved reply before settling it | `status: "INTERRUPTED"` |
| `run/stopRequested` | The owner asked to stop the run (`POST /v1/conversations/{id}/interrupt`) | `status`, and `turnId` for Codex |
| `run/outcomeUnknown` | The gateway cannot tell whether the run finished | `status: "OUTCOME_UNKNOWN"` |
| `run/driverReleased` | An uncertain run no longer holds the conversation | `status`, `reason` |
| `run/modelLoading`, `run/modelLoaded` | A local model that was not loaded is being loaded before the turn | `model`; then `model`, `loaded`, `ms` |
| `artifact/registered` | Files an approved command created or changed were registered as artifacts | `threadId`, `turnId`, `itemId`, `count`, `provenance: "command_execution"` |
| `artifact/registrationIncomplete` | Command artifact registration hit a read deadline; the listed files may be incomplete | `threadId`, `turnId`, `itemId`, `reason: "artifact_busy"`, `retry: true`, `provenance: "command_execution"` |

A Codex run that ends gets exactly one of `run/completed`, `run/failed` or
`run/interrupted`. On a provider crash, a turn may have no `turn/completed`;
the gateway promotes already saved reply deltas to one assistant message and
ends that run as an interrupted partial. A run with no saved reply remains
`OUTCOME_UNKNOWN`. A local reply that the owner stops gets exactly one
`run/interrupted`. Codex notifications such as `turn/*` and `item/*` are
also passed through.

While the gateway is running, it stores Codex's notifications and requests
without loss and in the order Codex sent them. When it falls behind (4,096
messages or 16 MiB of Codex's output waiting), it stops reading from Codex
until it catches up, so Codex waits and nothing is dropped; meanwhile other
conversations' events wait too. Every approval request becomes a
`request/pending` event for the owner. A request the gateway cannot record is
refused, an approval as declined, and recorded on the thread as
`request/unsupported` with `reason: "not_recorded"`. When the Codex app-server
exits, recovery first waits until everything it sent is stored: a finished
turn keeps its one outcome, an unfinished turn with saved reply text becomes
an interrupted partial, one without saved reply text becomes `OUTCOME_UNKNOWN`,
and a request it raised is marked stale. If the store has not caught up within
120 s, recovery drops the rest of that output and proceeds (fail closed). One
known exception: if the gateway exits, messages still queued in memory (up to
4,096 messages or 16 MiB) are lost, and the affected runs become
`OUTCOME_UNKNOWN` at the next start.

`/v1/*` accepts `Sec-Fetch-Site` only as `same-origin` or `none`. Any other
value (`cross-site`, `same-site`, a comma-joined list, or an unknown or
unreadable value) is refused with `403 cross_site_request_refused`. A present
`Origin` must be the gateway's own (the origin of the request's `Host`),
whatever the fetch metadata says, and `Origin: null` is refused. A request
that repeats `Origin`, `Host` or `Sec-Fetch-Site` is refused the same way.
Clients that send neither header, such as the CLI and the Android app, are not
affected. This guards against browser pages; the bearer token remains the
authentication.

Conversation routes include `GET /v1/conversations`, `POST /v1/conversations`,
authenticated `GET /v1/conversations/{id}`, and
`POST /v1/conversations/{id}/rename`. A new conversation has no engine: its
`provider` and `accountId` are empty strings until its first run or an SOS
switch sets them, and the gateway never chooses one. A turn
(`POST /v1/conversations/{id}/turns`) or an SOS switch
(`POST /v1/conversations/{id}/sos`) that names no `provider` is refused with
`400 engine_not_configured`. A confirmed switch to Codex reads Codex's account
again first and is refused with `503 engine_not_signed_in` unless an account is
signed in, by the same rule as `signedIn`. The switch's
`conversation/engineSwitched` event names the engine it leaves
(`fromProvider`, and `handoff.sourceProvider` in the response), or `"none"`
when the conversation had none. Before it answers, `GET
/v1/conversations/{id}` can repair a Codex conversation from Codex's own
history. An ordinary read waits at most about 3 s for Codex in total; past
that, it answers from what the gateway has stored. A full restore of the
history, and a read with `?check=native`, wait for Codex, up to 120 s per
call; a full restore makes up to five calls (one thread read and up to four
history pages), so against a stalled app-server it can wait about 10 minutes.
Each answer has `nativeHistory`: `"synced"` (Codex answered), `"unanswered"`
(Codex was needed but did not answer in time, or no Codex app-server is
running, for example during a restart) or `"skipped"` (no repair was
needed). The rename endpoint accepts
`{"title":"New title"}` and returns the updated `conversation`. The title is
trimmed and must contain 1–120 Unicode characters with no control characters;
invalid titles return `400`, while unknown conversation IDs return `404`.
Renaming to the current title is idempotent and does not append another event.
Each actual rename commits the title and one durable
`conversation/renamed` event together. Its payload contains `conversationId`
and `title`; event clients can apply the title without reconnecting or
reloading unrelated conversation data.

Phone sends include an `Idempotency-Key` UUID. Reusing the same key with the
same canonical request returns the original command receipt; a different body
with the same key is a conflict. A timeout after dispatch returns an
`OUTCOME_UNKNOWN` receipt, which the gateway does not blindly resubmit.

Only workspace IDs in the gateway's explicit allowlist cross the API. The phone never
sends a filesystem path to choose a thread workspace. Request bodies are JSON
with strict media type and size limits. Text and approval answers are not
written to logs. Secret-marked user-input answers are sent upstream without
being persisted in NivKode events.

Approval cards show the request before a decision. Command requests use two
steps: review the command and working directory, then confirm that it should
run. Local project commands are limited to supported test and build commands,
run inside bubblewrap, and are refused if bubblewrap is unavailable. File
change approvals apply file changes only; they do not approve commands.
Codex approval choices are restricted to one-time accept, decline, or cancel.
Session-persistent approval and policy amendments are not offered. A worker
event cannot create approval authority. Unknown upstream server requests fail
closed and are journaled as unsupported. User-input answers are mapped to
the exact question IDs and the upstream `{ "answers": { "id": { "answers": ["…"] } } }`
shape; secret-marked answers are never included in NivKode events or logs.

Artifact discovery reads only Codex-emitted image/file-change paths, canonicalizes
each candidate, and rejects any path outside that thread's configured workspace.
The content route accepts only registered artifact IDs and serves bounded text
or raster images; unsupported binary files remain metadata-only.

Artifact reads have a two-second deadline across the shared read slot and the
blocking read. If a deadline expires, `GET /v1/artifacts/{id}/content` and
`GET /v1/threads/{id}/artifacts` return `503 {"error":"artifact_busy"}` with
`Retry-After: 1`; retry the same request. The listing returns no `data` on
deadline, so clients must not treat it as an empty or complete list. A path
refusal (missing, changed, linked, or outside the workspace) still returns
`404 artifact_unavailable` from the content route. If a command's background
registration hits the deadline, it emits `artifact/registrationIncomplete`
instead of silently treating unprocessed files as absent. Already registered
files remain listed; the command's files may need to be inspected in the
workspace or the command rerun when read capacity returns.
