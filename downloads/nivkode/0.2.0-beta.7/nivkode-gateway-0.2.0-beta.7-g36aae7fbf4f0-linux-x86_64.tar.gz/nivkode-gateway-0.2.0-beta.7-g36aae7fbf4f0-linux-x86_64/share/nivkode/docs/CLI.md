<!-- SPDX-License-Identifier: AGPL-3.0-only -->
<!-- Copyright (C) 2026 Jake Evans -->
# NivKode CLI

`nivkode` is a small authenticated client for the gateway API. It uses the
configured gateway (default `http://127.0.0.1:8789`) and never launches a
provider or connects to a device. Set `NIVKODE_GATEWAY` or pass `--gateway URL`
to select another gateway.

Pair once using the one-time code issued by the gateway operator:

```sh
nivkode pair ONE_TIME_CODE
nivkode open
```

The device token is saved in `${XDG_CONFIG_HOME:-~/.config}/nivkode/cli.json`.
The directory is mode `0700` and the file is mode `0600` on Unix. The CLI
rejects a token file that is readable by group or other users, and pairing
refuses a `nivkode` config directory that is a symbolic link.

```sh
nivkode status
nivkode chat "Explain this change" --route code.explain --workspace WORKSPACE_ID
nivkode run "Summarize the project" --route text.general
nivkode run "Inspect the current task" --route codex
nivkode run --live "Inspect the current task"
nivkode watch CONVERSATION_ID
nivkode watch CONVERSATION_ID --plain
nivkode watch CONVERSATION_ID --no-color
nivkode list --workspace WORKSPACE_ID
nivkode show CONVERSATION_ID
nivkode rename CONVERSATION_ID "A useful title"
nivkode resume CONVERSATION_ID "Continue with the next step"
nivkode doctor ~/.config/nivkode/gateway.json
```

`chat` and `run` create a conversation, submit the prompt, and stream normalized
gateway events until the run completes or fails. `resume` submits another prompt
to an existing conversation; a prompt may instead be read from stdin.
`code.explain` and `text.general` use the gateway's configured local route
bindings. Without a route, `chat` and `run` start the conversation on the first
local route whose model is installed, else on the first installed Ollama model,
and never on Codex; with no local model they create and send nothing and exit
with status 2. `resume` without a route keeps the engine the conversation
already uses, Codex included. `--route codex` chooses Codex for that one
conversation, only while the gateway reports Codex as signed in (otherwise
exit status 2, nothing sent). Each send first prints its engine on stderr, for
example `Engine: code.explain on this computer`. Provider/model/fallback
provenance is included in the final result. `--json` emits machine-readable
JSON on stdout; diagnostics go to stderr. `docs/cli-tui.md` has the exact
messages.

`rename` updates a conversation title through the authenticated gateway API. Titles must contain 1 to 120 printable characters.

`watch [conversation]` attaches to the selected conversation, or the newest
conversation when omitted. `run --live` creates a conversation, submits the
task, and opens the same live view. The terminal view reads conversation
metadata and durable events through the authenticated REST API, then follows
the replaying event stream from its last sequence after reconnects. It does not
open provider or device connections. Non-terminal output and `--plain` produce
a timestamped event log; `--no-color` keeps labels and symbols readable without
terminal colours. In the interactive view, `q` quits, `d` detaches, `r` renames,
arrow keys scroll the focused pane, and Tab cycles pane focus.

`open` launches the bundled desktop client in the default Linux browser. It requests a 45-second, one-use handoff from the paired gateway. The handoff code is placed in the URL fragment, removed by the page before API use, and exchanged for the device token; the token stays in page memory and is never written to browser storage or sent in a URL. Direct visits can connect by pasting a paired token, which is cleared from the input after connection.

`status` reports gateway health, whether Codex is installed (its model catalog
is available) and signed in (the gateway's own `signedIn` check, never the
helper process merely running), installed Ollama models, and the engine a new
conversation would start on. On a Codex run failure, install Codex and sign in
to your own account with `codex login`.

The `doctor` command delegates to the existing read-only desktop preflight at
`nivkode-rusty/tools/doctor`. It uses
`~/.config/nivkode/gateway.json` by default; set `NIVKODE_GATEWAY_CONFIG` or
pass a config path to override it. `NIVKODE_DOCTOR` can select a custom doctor
script. The release tarball includes the script beside both binaries.

All API traffic reuses the gateway's device bearer-token authentication and
canonical conversation, turn, and event endpoints described in `API.md`.
# Live terminal view

`nivkode watch --demo` replays the bundled, labelled TUI walkthrough without a
gateway task. It runs at roughly one event per second; press `q` to close.

Choose a terminal palette with `--palette
default|cb-safe|tritan|high-contrast|none`, or set `NIVKODE_PALETTE` to one of
those values. The command-line option takes precedence over the environment.
`--no-color` remains an alias for `--palette none` on `run` and `watch`.
