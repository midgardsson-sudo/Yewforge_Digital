# Codex app-server compatibility

## Heavy observation

Collected before binding the Rust adapter on 2026-09-29:

- Installed executable: VS Code bundled Codex CLI on Heavy.
- `codex --version`: `codex-cli 0.155.0-alpha.16.3`.
- `codex app-server --listen stdio://` completed `initialize` / `initialized`
  and a read-only `thread/list` request.
- Schema source: generated from that installed executable with
  `codex app-server generate-json-schema --out <temporary-directory>`.
- The generated schemas contain v1 and v2 protocol definitions. Rusty uses
  JSON-RPC over stdio and the v2 thread/session methods.

The app-server is version-sensitive and currently marked experimental by the
installed CLI. On a Codex upgrade, regenerate the schemas and review the
adapter before claiming compatibility. The generated v2 schema snapshot is
kept in `../protocol-codex-app-server-v2-0.155.0-alpha.16.3.json`.

## Methods used

- Client handshake: `initialize` with `clientInfo`, followed by the
  `initialized` notification.
- Threads: `thread/list`, `thread/start`, `thread/resume`, `thread/read`,
  `thread/turns/list` (full item view, bounded to recent turns).
- Turns: `turn/start`, `turn/interrupt`.
- Server-initiated requests: `item/commandExecution/requestApproval`,
  `item/fileChange/requestApproval`, and `item/tool/requestUserInput`.
- Timeline notifications are stored with their original method and normalized
  sequence so newer provider event fields can be retained without changing the
  phone API.

Relevant upstream protocol sources:

- [Codex protocol v1 documentation](https://github.com/openai/codex/blob/main/codex-rs/docs/protocol_v1.md)
- [Codex user input schema](https://github.com/openai/codex/blob/main/codex-rs/protocol/src/user_input.rs)
- [Codex app-server protocol source](https://github.com/openai/codex/tree/main/codex-rs/app-server-protocol)

## Safety boundary

The gateway starts `codex app-server --listen stdio://` directly without a
shell and sets approved `cwd` values from its workspace registry. It pins the
policy on every session and turn itself, whatever the host Codex configuration
says: `thread/start` and `thread/resume` get `sandbox: read-only`,
`approvalPolicy: on-request` and `approvalsReviewer: user`, and every
`turn/start` gets the same approval policy and reviewer with
`sandboxPolicy: {type: readOnly, networkAccess: false}` (`gateway/src/main.rs`,
`with_owner_session_policy` and `with_owner_turn_policy`). Codex therefore runs
read-only commands inside that sandbox and asks the owner before anything that
needs more. There is no generic shell route. Phone disconnection does not terminate the Codex child.
On gateway restart, the event journal and command receipts survive. The
Codex child is restarted, prior in-flight command outcomes are marked
`OUTCOME_UNKNOWN`, and prior approval/input requests are marked stale because
their JSON-RPC request IDs belonged to the old child. The gateway resumes a
persisted thread before accepting its next turn. A submission whose upstream
outcome cannot be established is never retried automatically.
