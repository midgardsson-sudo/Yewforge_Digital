# Learning Curve and the Doctor

`nivkode-gateway lc …` turns a gateway run, or a MoS escalation packet, into a reviewable **Learning Curve** case. The **Doctor** then diagnoses the case and can propose a treatment. All of this runs offline, from the CLI, alongside the gateway. It never talks to the running service.

## Authority

| Action | Writes to | Approval |
|---|---|---|
| capture, bundle, classify, doctor, intake, status | the case directory only | none |
| treat | a new branch `doctor/<LC-id>`, cut from the treatment's base (default `nivkode-rusty`, or `--base`), in its own worktree under the Doctor worktree root (default `~/Nivren/worktrees/doctor/<LC-id>`). It is never inside the live checkout and never in a temp dir | **`--approve` required**. Without it the Doctor refuses (exit 3) and records the refusal. If the base already contains the fix, it reports `AlreadyLanded` and creates nothing |
| publish | pushes `doctor/<LC-id>` to the remote and opens a **draft** PR into the base, only for a treated *and verified* case | **`--approve` required**. Merging stays a human act |
| rollback | removes the Doctor's own worktree and local branch. A pushed branch and draft PR are left in place and reported, for a human to close | none |
| resume | removes the Doctor's own worktree; keeps a verified branch for review | none |
| data repair of the live DB | nothing. The Doctor only writes `data-repair.proposal.sql` | human, with a backup and the gateway idle |

The gateway database is opened with `mode=ro` and `query_only`. The Doctor never restarts services. It never changes the user's checked-out branch, and checks HEAD before and after treatment, rollback and resume. Case ids are validated, so a case cannot escape the Doctor's home directory. `treat` runs only treatments compiled into the binary. It refuses if `treatment.patch` in the case directory differs from the built-in patch, and it never executes commands read from case files.

## Commands

```sh
nivkode-gateway lc run --run <conversation-run-id>        # capture → classify → doctor in one step
nivkode-gateway lc capture --run <id> [--db PATH] [--journal-unit nivkode-rusty.service|none]
nivkode-gateway lc scan [--limit 50]                       # read-only: list recent runs with anomaly signals
nivkode-gateway lc bundle|classify|doctor|status <LC-id>
nivkode-gateway lc treat <LC-id> [--repo <canonical repo>] [--base <branch>] [--worktree-root DIR] [--approve] [--no-verify]
nivkode-gateway lc publish <LC-id> [--remote origin] [--approve]   # push + draft PR (gh); NIVKODE_GH overrides the gh binary
nivkode-gateway lc run --run <id> --treat [--approve]               # capture → … → treat in one step
nivkode-gateway lc rollback|resume <LC-id>
nivkode-gateway lc intake <doctor_handoff.json | ->       # MoS contract §6 packet → case; prints packet with learning_curve_ref
nivkode-gateway lc loop <LC-id> [--mos-bench FILE]... [--corpus FILE]...       # one bounded loop pass; proposes, never applies
nivkode-gateway lc candidates --mos-bench FILE... [--corpus FILE]...           # the curation/training candidate lane; writes nothing
```

### Evaluation and candidate data (owner directive 7b2ac40b §5)

- **Evaluation** (`lc loop`) counts only `observed` rows read from a reviewed `mos.bench` run, proven by the SHA-256 of the
  file's bytes (`corpus::REVIEWED_BENCH_RUNS`, the v1 admission). A `--corpus` file is never admissible, whatever it declares.
- **`human_reviewed`** material is never evaluation data. It is the only origin the curation/training **candidate lane**
  admits, and only with a named reviewer (the `producer`), never with the loop's own producer, and never on a task that
  is in the sealed held-out split. `lc candidates` prints the lane, what it held back and why, and the fingerprint of the
  sealed set it was checked against. It fails closed: unless every reviewed bench run is passed with `--mos-bench`
  (matched by SHA-256), the sealed set is incomplete, so it exits with an error naming the missing runs and reports
  nothing; `CandidateLane::build` likewise refuses an empty sealed set. `self_written`, `model_generated` and `unknown`
  material enters neither set.
- **The contract is versioned**: `nivren.lc.corpus_case/v0`, `nivren.lc.split/v0`, `nivren.lc.heldout_fingerprint/v1`,
  `nivren.lc.candidate_lane/v0`. A change of meaning is a new version and a new golden, never an edit in place; the
  worked example's v1 fingerprint and split counts are pinned in `decisions_tests`.
- **Deterministic routes**: when a model fails validation on a task in `intelligence::DETERMINISTIC_ROUTES` (reviewed
  letter-level/string-exact tasks), the loop proposes the deterministic MoS route (`text.string_exact` →
  `tool.string-exact`) instead of a suite-item note. A human applies it; the loop never edits routing. The tool (0.2.0)
  answers only a request that is, whole, one of its sentence templates, and declines the rest to a handoff; it is not
  a general letter-level reasoner (see `mos/tools.py` `_TEMPLATES`).

Defaults: the canonical repo is `$NIVKODE_CANONICAL_REPO` or `~/Nivren/nivren`, and Doctor worktrees live under `$NIVKODE_DOCTOR_WORKTREES` or `~/Nivren/worktrees/doctor`. The Doctor home is `~/.local/share/nivkode-rusty/doctor` (override with `--home` or `NIVKODE_DOCTOR_HOME`). The database is `~/.local/share/nivkode-rusty/state/nivkode.sqlite3`.

Factory progress is opt-in. Set `NIVKODE_FACTORYCTL=<path to factoryctl>` and `NIVKODE_FACTORY_SEAT=<seat>`, and each Doctor step then emits a redacted `phase` or `note` event. If emission fails, the Doctor carries on unaffected.

## Case directory

`<home>/LC-<YYYYMMDD of run>-<sha256(run id)[:10]>/` contains:

- `case.json`: the machine-readable case (`nivkode.learning-curve.v0`), already redacted.
- `bundle.md`: a self-contained Markdown report. It covers signals, route decision, timing, provider outcome vs canonical state, bounded conversation context, tool calls, timeline (streaming deltas collapsed), bounded journal lines and environment, and embeds `case.json`.
- `classification.json`: the primary class, out of MODEL / CONTEXT / ROUTER / TOOL / RUNTIME / UX / POLICY / UNKNOWN, plus secondary classes, confidence, rationale and a signature.
- `diagnosis.md`, `repro.json`: a reproduction that replays the captured sequence against this build's `Store` in a throwaway database.
- `treatment.json`, `treatment.patch`: the smallest proposed fix.
- `state.json`: the case state machine, with history, refusals, repository checkpoint and scratch record.
- After treatment: `repair.diff` and `evidence/verify.log`. Verification runs the whole gateway test suite in the scratch tree, with its own `CARGO_TARGET_DIR`.
- `data-repair.proposal.sql`: written when an already-damaged run needs a data repair. It is never executed by the Doctor.

States: `CAPTURED → CLASSIFIED → DIAGNOSED | TREATMENT_PROPOSED → TREATING → TREATED | TREATMENT_FAILED → ROLLED_BACK → … → RESUMED`. Illegal transitions are rejected. `resume` after an interrupted `TREATING` cleans up the partial scratch work and returns the case to `TREATMENT_PROPOSED`.

## Redaction

Redaction runs locally before anything is written. It covers bearer tokens, provider key prefixes (Anthropic, OpenAI, GitHub, GitLab, Slack, AWS, Google, Hugging Face), JWTs, PEM private keys, and `.env`- or JSON-style pairs whose key names a credential (`*TOKEN*`, `*SECRET*`, `*PASSWORD*`, `*API_KEY*`, `Authorization`, `Cookie`…). Numeric values, such as token counts, are kept. Absolute paths are then rewritten as in an evidence export: a path in the run's workspace (the provider thread's `cwd`, or an engine switch's `workspacePath`) becomes `<workspace>/…`, and any other path under a home folder (`/home/<user>`, `/Users/<user>`, `/root`, also under `/var`, a WSL `/mnt/<drive>` or an MSYS `/<drive>`; Windows `C:\Users\<user>` with either separator; `~<user>/`) becomes `<home>/…`, and this machine's user name as a segment of any other absolute path becomes `<user>` (`/tmp/<user>/…`). This covers the database path (`source.dbPath`), `route.cwd`, `environment.workspaceCwd`, messages, tool calls, timeline, logs and object keys, in `case.json` and `bundle.md` alike. System paths such as `/usr/bin/git` or `/tmp/build/…` are kept. Every file the case folder writes passes the same rewrite except `state.json` (the Doctor's record of the real repair worktree and checkout, needed to roll back) and the byte-exact `treatment.patch` and `repair.diff`; `lc intake` rewrites its `state.json` too. A Doctor draft pull request's title and body, and Factory notes, get the same rewrite. The count is in `redactions`. `case.json` is written only in its redacted form; the Doctor works from that redacted case, so a reproduction or a `data-repair.proposal.sql` uses `<workspace>/…` where the live database has the real folder. To see the real path, read the live database. `lc bundle` also rewrites paths when it re-renders a case captured before this rule, but that older `case.json` keeps its raw paths until the run is captured again. The rules are conservative pattern rules, not a guarantee. Review a bundle before sharing it outside the machine.

## First case: LC-20260930-2f0480d6e9

Codex run `5193ae2a-22fe-44ea-9db1-43600caf22d6` (thread `01a0f4b7-37df-…`) completed. Codex sent `turn/completed` with status `completed` and a final answer. The phone, however, showed the run as INTERRUPTED with no reply.

- **Cause.** `read_conversation` → `sync_native_conversation_history` read a `thread/turns/list` page while the turn was still running, and applied the page's terminal status. The run's `updated_at` equals the turn's `startedAt`×1000, which means the page had no `completedAt`. Then `complete_native_turn` skipped the real completion, because the run was "already terminal".
- **Class.** RUNTIME (high confidence), secondary UX.
- **Treatment** (`treatments/history-race.patch`). A turn page without `completedAt` may not finish a run. A live `turn/completed` supersedes an INTERRUPTED status that has no reply. The patch adds two regression tests that fail on the current code and pass with the patch. The full suite stays green with the patch applied.
- **Damaged row.** The patch does not fix the run that is already wrong. `data-repair.proposal.sql` restores it; this needs a human decision.
