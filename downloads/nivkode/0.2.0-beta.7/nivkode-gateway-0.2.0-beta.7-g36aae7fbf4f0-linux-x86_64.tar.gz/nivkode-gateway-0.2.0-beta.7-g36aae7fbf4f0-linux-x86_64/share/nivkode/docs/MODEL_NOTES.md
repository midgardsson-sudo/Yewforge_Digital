# Model notes for first run

The desktop quick-start offers two models listed in Ollama's library:

| Model | Approximate download | Licence |
| --- | ---: | --- |
| `qwen2.5-coder:7b` (recommended) | 4.7 GB | Apache-2.0 |
| `qwen2.5-coder:1.5b` (smaller) | 986 MB | Apache-2.0 |

Sizes are the library's published sizes and may differ slightly from a particular Ollama build. The 1.5b model's Ollama library page identifies its licence as Apache License 2.0 and reports 986 MB: <https://ollama.com/library/qwen2.5-coder:1.5b>. The 7b model is also listed as Apache-2.0 in the repository's existing model notes in the README and onboarding guide.

The 3b variants remain research-only in this repository. NivKode shows an `ollama pull` command and a copy button; it does not download a model.
