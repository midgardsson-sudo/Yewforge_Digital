# NivKode onboarding (Rusty)

This guide describes the checked-in source, not a preinstalled product. The
checkout does not install a gateway service, create a private HTTPS route, pair
a device, or install an APK. The gateway binds to loopback and requires an
independently configured private HTTPS proxy before a phone can reach it.

## Desktop: build and start the gateway

Prerequisites are Rust/Cargo, Ollama, and a local
workspace directory that the gateway process can read and write. The Codex CLI
(`codex`) is needed for the optional external AI provider Codex. When it is
installed, the gateway starts its app-server to report sign-in state and models. A conversation is
sent to an external AI provider only when you choose it. Claude is in
development and has not had a live test. The gateway config must list each
workspace explicitly. Local provider turns use Ollama on the gateway host.
Local models can read workspace files and propose file changes, shown in
approval cards before they are applied. Local-model file changes need the workspace to be a git repository; otherwise no proposal is made. Project test and build commands require
a review step followed by a separate confirmation; they run inside bubblewrap
and are refused when bubblewrap is unavailable. The preselected local route
uses `qwen2.5-coder:7b` first, followed by `qwen3:8b`.

1. Install the tools above and make sure they are on `PATH`. Start Ollama and
   install the pinned local model:

   ```sh
   export PATH="$HOME/.cargo/bin:$PATH" # if rustup installed Cargo here
   ollama pull qwen2.5-coder:7b
   ollama list
   ```

   The default model download is about 4.7 GB and can take a while on a slow
   connection. It is licensed under Apache-2.0. Smaller research-only models
   remain available, but they are not the default.

2. From the repository root, create a private config from the example and edit
   its workspace path and state directory. `listen` should remain loopback.

   ```sh
   cp nivkode-rusty/gateway/config.example.json nivkode-rusty/gateway/gateway.json
   chmod 600 nivkode-rusty/gateway/gateway.json
   ```

   Set `state_dir` to a private absolute directory. The gateway creates it with
   mode `0700`, creates `nivkode.sqlite3` with mode `0600`, and stores device
   token hashes there. Keep the config and state directory private. Do not
   commit `gateway.json`.

3. Build and run from the repository root:

   ```sh
   cargo build --release --manifest-path nivkode-rusty/gateway/Cargo.toml
   cargo run --release --manifest-path nivkode-rusty/gateway/Cargo.toml -- pair-code nivkode-rusty/gateway/gateway.json
   cargo run --release --manifest-path nivkode-rusty/gateway/Cargo.toml -- serve nivkode-rusty/gateway/gateway.json
   ```

   `pair-code` prints a one-time code. Keep it private and use it promptly; the
   gateway stores only its hash. Run `serve` in a separate terminal after
   obtaining the code. `/health` is unauthenticated and returns sanitized
   status. Restarting the process recovers persisted gateway state.

4. For desktop/API use, keep the returned device token private. Pairing is
   `POST /v1/pair` with `{"code":"…","device_name":"Desktop"}`. Other API
   routes require `Authorization: Bearer <token>`. See [API.md](API.md) for
   routes and request contracts. The release also bundles a local desktop
   conversation client; after pairing, run `nivkode open` to launch it.

## First local task through the API

Create a local conversation with `POST /v1/conversations` using the paired
bearer token and an allowlisted workspace ID:

```json
{"workspace_id":"workspace"}
```

Read the returned `conversation.id`, then send one text turn to
`/v1/conversations/<id>/turns`, with a fresh
`Idempotency-Key` UUID and JSON body:

Use the local account ID returned by `/v1/providers` for `account_id`.

```json
{"text":"Give me three concise shell commands for checking the Git branch, clean working tree, and latest commit.","provider":"ollama","account_id":"<local account ID from /v1/providers>","model":"qwen2.5-coder:7b","effort":null}
```

Read the conversation and its events to see the saved reply and run status.
Ollama must be reachable at the configured loopback endpoint, and the selected
model must appear in `/api/tags`. The local adapter does not accept images or
effort values. It can propose file changes and supported project test/build
commands; review and approve each request in the desktop before it proceeds.
Undo applies only to approved local-model file changes whose recorded file
state has not changed. It does not undo commands.

The Local only switch is enforced by the gateway. While enabled, external
provider turns and external second opinions are refused; enabling the switch
also stops active external-provider runs.

## Pairing and Android

The Android app accepts a **private HTTPS gateway URL** and a one-time pairing
code. It encrypts the returned device token with an Android Keystore key. A
plain loopback listener is not a phone route. The app trusts only the
certificate authorities that come with Android, so the route needs a publicly
trusted certificate. `docs/PHONE_SETUP.md` documents the route (Tailscale
Serve), how to check it from the phone, installing the APK, pairing and
recovery.

Build the debug APK from the source checkout:

```sh
cd nivkode-rusty/android
./gradlew testDebugUnitTest assembleDebug
```

The APK path is `nivkode-rusty/android/app/build/outputs/apk/debug/app-debug.apk`.
No release APK exists yet: the Android release keystore has not been created
(`docs/ANDROID_RELEASE.md`). `docs/PHONE_SETUP.md` covers installing a debug
build over USB or from a file, and the checks a release APK will need. One 6 October build
passed an acceptance run on one real phone with a scripted provider, and the
owner has not confirmed that run; see [Features and status](../../docs/FEATURES.md).
Do not infer phone acceptance from the APK build.

## Recovery

- If the gateway will not start, run the doctor below, check the JSON config,
  make sure the configured loopback port is free, and verify the workspace
  directory exists and is accessible.
- If local models are unavailable, start Ollama, check `ollama list`, ensure
  `qwen2.5-coder:7b` is present, and verify the configured Ollama loopback URL.
- If Codex turns are unavailable, check that the Codex CLI is installed and
  usable by the gateway account. Local Ollama turns are a separate route.
- If pairing says invalid or expired, generate a fresh code with `pair-code`;
  codes are one-time and expire. If a device token is lost, pair again. The API
  also supports token rotation, which invalidates the previous token.
- Preserve `state_dir` when restarting if conversations, events, or pairings
  must remain available. Do not delete the SQLite database as a troubleshooting
  step.

## Doctor preflight

Run the read-only preflight from the repository root:

```sh
python3 nivkode-rusty/tools/doctor nivkode-rusty/gateway/gateway.json
```

It reports PASS/WARN/FAIL and suggested fixes for local tool presence, config,
port, Ollama reachability/model presence, private state/token-store permissions,
and optional Android Java/SDK prerequisites. It never prints credential or
device-token values. If a deployment adds a `tailscale_route` value for the
doctor, it pings that route with the Tailscale CLI; otherwise it reports that
no route is configured. The gateway config/runtime itself does not implement
Tailscale routing.
