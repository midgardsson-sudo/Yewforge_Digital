#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Jake Evans
set -euo pipefail

# The NivKode release public keys this installer trusts: minisign public keys, one quoted base64 line each.
# The release key is made offline (docs/RELEASE_KEY_CEREMONY.md). Changing this list is a release-signing change: review it.
PINNED_RELEASE_KEYS=(
  'RWSTLdUN4lyCUF75ANlaa4La4nvfZC8wvtuEeYLx0AxjR2sibpTjQmee' # NivKode release key, owner-confirmed 2026-10-24
)

usage() {
  echo "usage: install.sh [--allow-downgrade] [--insecure-allow-unsigned] ARCHIVE.tar.gz [SHA256SUMS]" >&2
  echo "  The archive must be signed: SHA256SUMS.minisig is read from next to SHA256SUMS." >&2
  exit 2
}
ALLOW_DOWNGRADE=0
ALLOW_UNSIGNED=0
POSITIONAL=()
for arg in "$@"; do
  case "$arg" in
    --allow-downgrade) ALLOW_DOWNGRADE=1 ;;
    # Developer use only: install an archive whose publisher is not verified (a local build). Never the default.
    --insecure-allow-unsigned) ALLOW_UNSIGNED=1 ;;
    -*) echo "unknown option: $arg" >&2; usage ;;
    *) POSITIONAL+=("$arg") ;;
  esac
done
set -- ${POSITIONAL[@]+"${POSITIONAL[@]}"}
[[ $# -ge 1 && $# -le 2 ]] || usage
insecure_banner() {
  echo "WARNING: INSECURE INSTALL (--insecure-allow-unsigned): the archive's signature is NOT verified, so nothing proves" >&2
  echo "WARNING: who made it. Use this only for an archive you built yourself, never for a download." >&2
}
[[ -f "$1" ]] || { echo "archive not found: $1" >&2; exit 1; }
ARCHIVE="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
SUMS="${2:-$(dirname "$ARCHIVE")/SHA256SUMS}"
[[ -f "$SUMS" ]] || { echo "checksum file not found: $SUMS (keep SHA256SUMS next to the archive or pass its path)" >&2; exit 1; }
SUMS="$(cd "$(dirname "$SUMS")" && pwd)/$(basename "$SUMS")"
[[ -n "${HOME:-}" && "$HOME" == /* ]] || { echo "HOME must be an absolute path" >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "python3 is required to unpack and verify the archive" >&2; exit 1; }
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' || {
  echo "NivKode needs Python 3.9 or newer to install (found $(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo unknown))" >&2
  exit 1
}

ARCHIVE_NAME="$(basename "$ARCHIVE")"
ACTUAL="$(sha256sum "$ARCHIVE" | awk '{print tolower($1)}')"
# The signature check is this installer's own code, never the archive's: SHA256SUMS.minisig must be a valid
# signature of SHA256SUMS by a pinned key, its signed (trusted) comment names the archive and its version, and
# SHA256SUMS must give that archive this archive's digest. The digest, not the file name, identifies the archive,
# so a browser-renamed download ("... (1).tar.gz") still matches. Prints "signed KEY-ID ARCHIVE VERSION" or,
# only with --insecure-allow-unsigned, "unsigned".
CHECK="$(python3 - "$SUMS" "$SUMS.minisig" "$ACTUAL" "$ARCHIVE_NAME" "$ALLOW_UNSIGNED" ${PINNED_RELEASE_KEYS[@]+"${PINNED_RELEASE_KEYS[@]}"} <<'VERIFY_PY'
import base64, hashlib, re, sys
sums_path, sig_path, actual, name, allow_unsigned = sys.argv[1], sys.argv[2], sys.argv[3].lower(), sys.argv[4], sys.argv[5] == "1"
pinned_lines = sys.argv[6:]
def refuse(message):
    print(message, file=sys.stderr)
    sys.exit(1)
# Ed25519 verification, RFC 8032 section 6 (the same algorithm as scripts/release/release-signing.py).
P = 2**255 - 19
Q = 2**252 + 27742317777372353535851937790883648493
D = -121665 * pow(121666, P - 2, P) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)
def add(a, b):
    x, y = (a[1] - a[0]) * (b[1] - b[0]) % P, (a[1] + a[0]) * (b[1] + b[0]) % P
    c, d = 2 * a[3] * b[3] * D % P, 2 * a[2] * b[2] % P
    e, f, g, h = y - x, d - c, d + c, y + x
    return (e * f % P, g * h % P, f * g % P, e * h % P)
def mul(s, point):
    result = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            result = add(result, point)
        point, s = add(point, point), s >> 1
    return result
def recover_x(y, sign):
    if y >= P:
        return None
    x2 = (y * y - 1) * pow(D * y * y + 1, P - 2, P)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P:
        x = x * SQRT_M1 % P
    if (x * x - x2) % P:
        return None
    return P - x if (x & 1) != sign else x
def decompress(data):
    y = int.from_bytes(data, "little")
    x = recover_x(y & ((1 << 255) - 1), y >> 255)
    return None if x is None else (x, y & ((1 << 255) - 1), 1, x * (y & ((1 << 255) - 1)) % P)
GY = 4 * pow(5, P - 2, P) % P
GX = recover_x(GY, 0)
G = (GX, GY, 1, GX * GY % P)
def verify(public, message, signature):
    a, r = decompress(public), decompress(signature[:32])
    s = int.from_bytes(signature[32:], "little")
    if a is None or r is None or s >= Q:
        return False
    h = int.from_bytes(hashlib.sha512(signature[:32] + public + message).digest(), "little") % Q
    left, right = mul(s, G), add(r, mul(h, a))
    return (left[0] * right[2] - right[0] * left[2]) % P == 0 and (left[1] * right[2] - right[1] * left[2]) % P == 0
def b64(text, length):
    try:
        raw = base64.b64decode(text.strip(), validate=True)
    except ValueError:
        return None
    return raw if len(raw) == length else None
def key_text(key_id):
    return "%016X" % int.from_bytes(key_id, "little")
# SHA256SUMS lines are "<64-hex digest><space><space or *><name>" (sha256sum text or binary mode). The name is
# everything after column 66, so names with spaces work.
def entries(wanted):
    with open(sums_path, "rb") as handle:
        text = handle.read().decode("utf-8", "replace")
    found = []
    for line in text.split("\n"):
        line = line[:-1] if line.endswith("\r") else line
        if len(line) > 66 and line[64] == " " and line[65] in " *" and line[66:] == wanted:
            found.append(line[:64].lower())
    return found
def unsigned():
    found = entries(name)
    if len(found) != 1:
        refuse(f"SHA256SUMS must contain exactly one entry for {name} (if you renamed the archive, use the same name in SHA256SUMS)")
    if found[0] != actual:
        refuse(f"checksum mismatch: {name}")
    print("unsigned")
    sys.exit(0)
pinned = []
for line in pinned_lines:
    raw = b64(line, 42)
    if raw is None or raw[:2] != b"Ed":
        refuse("this installer's PINNED_RELEASE_KEYS holds a malformed key; nothing was installed")
    pinned.append((raw[2:10], raw[10:]))
try:
    with open(sig_path, "rb") as handle:
        lines = handle.read().decode("ascii").splitlines()
except FileNotFoundError:
    if allow_unsigned:
        unsigned()
    refuse(f"{name} is not signed: there is no {sig_path.rsplit('/', 1)[-1]} next to SHA256SUMS. NivKode installs only "
           "archives signed with the NivKode release key, so nothing was installed. Download the archive, SHA256SUMS and "
           "SHA256SUMS.minisig from the official release page into one folder and run the installer again. (For an "
           "archive you built yourself, --insecure-allow-unsigned skips this check; never use it for a download.)")
except (OSError, UnicodeDecodeError) as error:
    refuse(f"could not read the signature file {sig_path}: {error}")
signature = b64(lines[1], 74) if len(lines) >= 4 else None
if (signature is None or not lines[0].startswith("untrusted comment:") or not lines[2].startswith("trusted comment: ")
        or signature[:2] != b"ED" or b64(lines[3], 64) is None):
    refuse("SHA256SUMS.minisig is not a NivKode release signature (minisign format); nothing was installed")
key_id, sig = signature[2:10], signature[10:]
public = next((pk for kid, pk in pinned if kid == key_id), None)
if public is None:
    if allow_unsigned:
        print(f"WARNING: SHA256SUMS.minisig is signed by key {key_text(key_id)}, which is not trusted here; "
              "installing it as UNSIGNED (--insecure-allow-unsigned).", file=sys.stderr)
        unsigned()
    if not pinned:
        refuse(f"This installer has no release key pinned yet, so it cannot check the signature of {name} "
               f"(key {key_text(key_id)}). Nothing was installed.")
    refuse(f"{name} is signed by key {key_text(key_id)}, which is not trusted here (this installer trusts "
           f"{', '.join(key_text(k) for k, _ in pinned)}). Nothing was installed.")
# From here a pinned key is named: a failure is tampering, and --insecure-allow-unsigned does not excuse it.
with open(sums_path, "rb") as handle:
    sums = handle.read()
if not verify(public, hashlib.blake2b(sums, digest_size=64).digest(), sig):
    refuse("The release signature does not match SHA256SUMS: the checksum file or its signature was changed after "
           "the release was signed. Nothing was installed.")
trusted = lines[2][len("trusted comment: "):]
if not verify(public, sig + trusted.encode(), b64(lines[3], 64)):
    refuse("The signed description of this release (its trusted comment) was changed after signing. Nothing was installed.")
words = trusted.split()
fields = dict(word.split("=", 1) for word in words[1:] if "=" in word)
archive, version = fields.get("archive", ""), fields.get("version", "")
if (not words or words[0] != "nivkode-release" or not re.fullmatch(r"nivkode-gateway-[0-9A-Za-z._+-]+\.tar\.gz", archive)
        or not re.fullmatch(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z.-]+)?", version)):
    # The version must be a semantic version: one the downgrade check cannot order would switch it off.
    refuse(f"The signature does not describe a NivKode release archive (trusted comment: {trusted!r}). Nothing was installed.")
listed = entries(archive)
if len(listed) != 1:
    refuse(f"The signed SHA256SUMS does not list {archive} exactly once. Nothing was installed.")
if listed[0] != actual:
    refuse(f"checksum mismatch: {name} is not the archive this signature covers ({archive}). Nothing was installed.")
print("signed", key_text(key_id), archive, version)
VERIFY_PY
)" || exit 1
read -r SIGNATURE_STATE SIGNED_KEY SIGNED_ARCHIVE SIGNED_VERSION <<<"$CHECK"
[[ "$SIGNATURE_STATE" == signed ]] || insecure_banner
if [[ "$SIGNATURE_STATE" == signed ]]; then
  printf 'Release signature verified: %s is signed by the NivKode release key %s.\n' "$SIGNED_ARCHIVE" "$SIGNED_KEY"
fi

TMP="$(mktemp -d)"
BIN="$HOME/.local/bin"
CONFIG="$HOME/.config/nivkode"
UNIT="$HOME/.config/systemd/user"
SHARE="$HOME/.local/share/nivkode"
cleanup() {
  # fs_put removes its own temporary file if a write is interrupted; only the unpack folder remains.
  python3 -c "import shutil,sys; shutil.rmtree(sys.argv[1], ignore_errors=True)" "$TMP"
}
trap cleanup EXIT

# Verify every member before extracting. The top-level directory comes from the
# archive itself, so a browser-renamed download ("... (1).tar.gz") still installs.
PKG_NAME="$(python3 - "$ARCHIVE" "$TMP" <<'PY'
import pathlib, re, sys, tarfile
archive, destination = sys.argv[1:]
with tarfile.open(archive, "r:gz") as package:
    members = package.getmembers()
    roots = set()
    for member in members:
        path = pathlib.PurePosixPath(member.name)
        if path.is_absolute() or ".." in path.parts or not path.parts:
            raise SystemExit("archive contains an unsafe path")
        if not (member.isfile() or member.isdir()):
            raise SystemExit("archive contains a link or special file")
        roots.add(path.parts[0])
    if len(roots) != 1 or not re.fullmatch(r"nivkode-gateway-[0-9A-Za-z._+-]+", next(iter(roots))):
        raise SystemExit("archive is not a NivKode gateway release (unexpected top-level directory)")
    for member in members:
        member.mode &= 0o755  # never extract setuid/setgid/sticky or group/world-write bits
    if hasattr(tarfile, "data_filter"):
        package.extractall(destination, filter="data")
    else:  # Python without the extraction filters: members were validated above
        package.extractall(destination)
    print(next(iter(roots)))
PY
)" || exit 1
PKG="$TMP/$PKG_NAME"
[[ -x "$PKG/bin/nivkode-gateway" && -x "$PKG/bin/nivkode-doctor" && \
   -x "$PKG/bin/nivkode" && -f "$PKG/LICENSE" && \
   -f "$PKG/THIRD_PARTY_NOTICES.md" && -f "$PKG/COMMERCIAL_LICENSING.md" && \
   -d "$PKG/docs" && -d "$PKG/share/nivkode/docs" && \
   -f "$PKG/share/nivkode/tools/doctor" && -f "$PKG/share/nivkode/install.sh" && \
   -f "$PKG/share/nivkode/uninstall.sh" && -f "$PKG/README.md" && \
   -f "$PKG/share/nivkode/gateway.example.json" && \
   -f "$PKG/share/nivkode/nivkode-gateway.service" ]] || {
  echo "archive is missing required release files" >&2; exit 1;
}
# The version comes from what was signed. A signed archive must be the one its signature names, built as that version.
PACKAGE_VERSION="$(head -n 1 "$PKG/share/nivkode/VERSION" 2>/dev/null || true)"
if [[ "$SIGNATURE_STATE" == signed ]]; then
  [[ "$PKG_NAME.tar.gz" == "$SIGNED_ARCHIVE" ]] || {
    echo "The archive holds $PKG_NAME, but its signature is for $SIGNED_ARCHIVE. Nothing was installed." >&2; exit 1;
  }
  [[ -z "$PACKAGE_VERSION" || "$PACKAGE_VERSION" == "$SIGNED_VERSION" ]] || {
    echo "The archive says it is version $PACKAGE_VERSION, but it was signed as $SIGNED_VERSION. Nothing was installed." >&2; exit 1;
  }
  THIS_VERSION="$SIGNED_VERSION"
else
  THIS_VERSION="$PACKAGE_VERSION"
fi

# The installer writes only into real folders of this HOME. A folder reached through a symbolic link
# (for example a developer checkout linked as ~/.local/share/nivkode/tools) would have its files
# replaced, and the uninstaller never follows links, so refuse before anything is written.
first_link() { # first_link PATH: prints the first symbolic link from $HOME down to PATH (PATH included)
  local rel="${1#"$HOME"/}" acc="${HOME%/}" part parts
  IFS=/ read -r -a parts <<<"$rel"
  for part in "${parts[@]}"; do
    acc="$acc/$part"
    if [[ -L "$acc" ]]; then printf '%s\n' "$acc"; return 0; fi
  done
  return 1
}
for folder in "$BIN" "$CONFIG" "$UNIT" "$SHARE" "$SHARE/tools"; do
  if link="$(first_link "$folder")"; then
    echo "NivKode installs only into real folders, but $link is a symbolic link to $(readlink -- "$link")." >&2
    echo "Nothing was installed. Replace the link with a real folder (move its contents back first), then run the installer again." >&2
    exit 1
  fi
done

# An upgrade is an install over an earlier one. Note what is there before anything changes.
UPGRADE=0
if [[ -e "$BIN/nivkode-gateway" || -e "$SHARE/install-manifest.sha256" ]]; then UPGRADE=1; fi
PREVIOUS_RELEASE=""
if [[ -f "$SHARE/installed-release" && ! -L "$SHARE/installed-release" ]]; then PREVIOUS_RELEASE="$(head -n 1 "$SHARE/installed-release")"; fi
THIS_RELEASE="${PKG_NAME#nivkode-gateway-}"; THIS_RELEASE="${THIS_RELEASE%-linux-x86_64}"
# The installed version: the "version=" line this installer records, or else the version in an earlier installer's
# release name ("0.1.0-g<12 hex>"). Release names alone do not sort; versions do (semantic versioning order).
PREVIOUS_VERSION=""
if [[ -n "$PREVIOUS_RELEASE" ]]; then
  PREVIOUS_VERSION="$(sed -n 's/^version=//p' "$SHARE/installed-release" | head -n 1)"
  if [[ -z "$PREVIOUS_VERSION" && "$PREVIOUS_RELEASE" =~ ^(.+)-g[0-9a-f]{12}$ ]]; then PREVIOUS_VERSION="${BASH_REMATCH[1]}"; fi
fi
ORDER="$(python3 - "$PREVIOUS_VERSION" "$THIS_VERSION" <<'PY'
import re, sys
def key(version):
    m = re.fullmatch(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z.-]+)?", version)
    if m is None:
        return None
    pre = [] if m.group(4) is None else m.group(4).split(".")
    # A release sorts after its pre-releases; numeric identifiers sort numerically and before alphanumeric ones.
    return (tuple(int(m.group(i)) for i in (1, 2, 3)), not pre, [(0, int(p), "") if p.isdigit() else (1, 0, p) for p in pre])
previous, this = key(sys.argv[1]), key(sys.argv[2])
print("unknown" if previous is None or this is None else "older" if this < previous else "newer" if this > previous else "same")
PY
)"
if [[ "$ORDER" == older && "$ALLOW_DOWNGRADE" != 1 ]]; then
  {
    printf 'NivKode Gateway %s is older than the installed %s, so nothing was installed.\n' "$THIS_VERSION" "$PREVIOUS_VERSION"
    printf 'An older gateway may not read the conversations a newer one wrote. To go back on purpose, first copy %s\n' "$SHARE"
    printf '(see "Go back to an earlier version" in docs/install.md), then run the installer again with --allow-downgrade.\n'
  } >&2
  exit 1
fi
RUNNING=()
for exe in /proc/[0-9]*/exe; do
  target="$(readlink "$exe" 2>/dev/null || true)"
  case "$target" in
    "$BIN/nivkode-gateway" | "$BIN/nivkode-gateway (deleted)") RUNNING+=("$(basename "$(dirname "$exe")")") ;;
  esac
done

# Every write goes through fs_put, which re-checks the folders right before writing and cannot be
# redirected by a folder that is swapped for a symbolic link while the installer runs: it walks from
# $HOME opening each folder with O_NOFOLLOW relative to the one above it, creates the file with
# O_EXCL|O_NOFOLLOW inside the folder it holds open, and renames it into place within that folder. On success
# it prints the SHA-256 of the bytes it wrote, so the manifest never depends on reading a path back.
fs_put() { # fs_put MODE SOURCE DESTINATION
  python3 - "$HOME" "$1" "$2" "$3" "${SHARE#"$HOME"/}" <<'PY'
import errno, hashlib, os, sys
home, mode, source, dest, private = sys.argv[1].rstrip("/"), int(sys.argv[2], 8), sys.argv[3], sys.argv[4], sys.argv[5]
def refuse(message):
    print(message, file=sys.stderr); sys.exit(3)
if not dest.startswith(home + "/"):
    refuse(f"refusing to write outside {home}: {dest}")
parts = dest[len(home) + 1:].split("/")
if any(part in ("", ".", "..") for part in parts):
    refuse(f"refusing an unusual path: {dest}")
with open(source, "rb") as handle:
    data = handle.read()
fd = os.open(home, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
try:
    walked = ""
    for part in parts[:-1]:
        walked = f"{walked}/{part}" if walked else part
        try:
            os.mkdir(part, 0o700 if walked == private else 0o755, dir_fd=fd)
        except FileExistsError:
            pass
        try:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
        except OSError as error:
            if error.errno in (errno.ELOOP, errno.ENOTDIR):
                refuse(f"NivKode installs only into real folders, but {home}/{walked} is a symbolic link or not a folder. Stopped before writing {parts[-1]}.")
            raise
        os.close(fd); fd = child
        if walked == private:
            os.fchmod(fd, 0o700)
    name, temp = parts[-1], f".nivkode-install.{os.getpid()}.{parts[-1]}"
    out = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=fd)
    try:
        view = memoryview(data)
        while view:
            view = view[os.write(out, view):]
        os.fchmod(out, mode)
        os.fsync(out)
        os.close(out)
        os.rename(temp, name, src_dir_fd=fd, dst_dir_fd=fd)
    except BaseException:
        try: os.close(out)
        except OSError: pass
        try: os.unlink(temp, dir_fd=fd)
        except OSError: pass
        raise
finally:
    os.close(fd)
print(hashlib.sha256(data).hexdigest())
PY
}


# The installer records the digest of every file it places (install-manifest.sha256), so a
# later upgrade can refresh an untouched template and the uninstaller removes only files
# that are still exactly what was installed.
NOTES=()
MANIFEST="$SHARE/install-manifest.sha256"
NEW_MANIFEST=""
digest() { sha256sum "$1" | awk '{print $1}'; }
# The installer's decisions read files the same way it writes them: one look from $HOME with O_NOFOLLOW at every
# folder and at the file itself, so a folder swapped for a link cannot show it a decoy.
fs_look() { # fs_look digest|cat PATH: prints missing | link | other, or the file's SHA-256 (digest) or content (cat)
  python3 - "$HOME" "$1" "$2" <<'PY'
import errno, hashlib, os, stat, sys
home, mode, path = sys.argv[1].rstrip("/"), sys.argv[2], sys.argv[3]
def say(word):
    print(word if mode == "digest" else "", end="" if mode == "cat" else "\n"); sys.exit(0)
if not path.startswith(home + "/"):
    say("other")
parts = path[len(home) + 1:].split("/")
fd = os.open(home, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
try:
    for part in parts[:-1]:
        try:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
        except FileNotFoundError:
            say("missing")
        except OSError as error:
            say("link" if error.errno in (errno.ELOOP, errno.ENOTDIR) else "other")
        os.close(fd); fd = child
    try:
        info = os.stat(parts[-1], dir_fd=fd, follow_symlinks=False)
    except FileNotFoundError:
        say("missing")
    if stat.S_ISLNK(info.st_mode):
        say("link")
    if not stat.S_ISREG(info.st_mode):
        say("other")
    handle = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
    try:
        data = b""
        while chunk := os.read(handle, 1 << 20):
            data += chunk
    finally:
        os.close(handle)
    if mode == "digest":
        print(hashlib.sha256(data).hexdigest())
    else:
        sys.stdout.write(data.decode("utf-8", "replace"))
finally:
    os.close(fd)
PY
}
recorded_digest() { fs_look cat "$MANIFEST" | awk -v k="$1" '$2 == k { print $1 }'; }

# Stage next to the destination (same filesystem) and rename into place. The rename is
# atomic, so an interrupted install never leaves a half-written program, and a gateway
# that is already running keeps its old executable until it is restarted.
place() { # place MODE SOURCE DESTINATION [MANIFEST-KEY]: the manifest records the digest of the bytes written
  local written
  written="$(fs_put "$1" "$2" "$3")" || exit 1
  if [[ -n "${4:-}" ]]; then NEW_MANIFEST+="$written  $4"$'\n'; fi
}
place 0755 "$PKG/bin/nivkode-gateway" "$BIN/nivkode-gateway" bin/nivkode-gateway
place 0755 "$PKG/bin/nivkode-doctor" "$BIN/nivkode-doctor" bin/nivkode-doctor
place 0755 "$PKG/bin/nivkode" "$BIN/nivkode" bin/nivkode
place 0644 "$PKG/share/nivkode/tools/doctor" "$SHARE/tools/doctor" tools/doctor
# Keep an uninstaller that survives deleting the downloaded package folder, and this release's installer: run
# for the next update, it checks the new archive against the keys this (verified) release pins.
place 0755 "$PKG/share/nivkode/uninstall.sh" "$SHARE/uninstall.sh" uninstall
place 0755 "$PKG/share/nivkode/install.sh" "$SHARE/install.sh" installer
{
  printf '%s\n' "$THIS_RELEASE"
  [[ -n "$THIS_VERSION" ]] && printf 'version=%s\n' "$THIS_VERSION"
  if [[ "$SIGNATURE_STATE" == signed ]]; then
    printf 'signature=verified key %s\n' "$SIGNED_KEY"
  else
    printf 'signature=none (installed with --insecure-allow-unsigned; the publisher was not verified)\n'
  fi
} > "$TMP/installed-release"
place 0644 "$TMP/installed-release" "$SHARE/installed-release" installed-release

# Untouched templates shipped by earlier releases that did not record a manifest (the 0.1.0
# release candidates up to RC17), so an upgrade from them refreshes the file instead of
# treating it as edited.
previously_shipped() { # previously_shipped KEY DIGEST
  case "$1:$2" in
    unit:1c623ebe9de543f39792d8136140ae40fe822dbf6c85e190db8a93be38ad4963 | \
    unit:9e65bf1cce8acf623cc98c0b07d5f1799ae2c9b3850351ae19dc49259c3f4cb4) return 0 ;;
  esac
  return 1
}
# Files the user may edit (example config, service unit) are never overwritten.
sync_shipped() { # sync_shipped KEY SOURCE DESTINATION
  local key="$1" source="$2" destination="$3" shipped current recorded
  shipped="$(digest "$source")"
  current="$(fs_look digest "$destination")" || exit 1
  case "$current" in
    link)
      fs_put 0644 "$source" "$destination.new" > /dev/null || exit 1
      NOTES+=("$destination is a symbolic link, so it was left alone; this release's version was saved as $destination.new.")
      return ;;
    other)
      fs_put 0644 "$source" "$destination.new" > /dev/null || exit 1
      NOTES+=("$destination is not a regular file, so it was left alone; this release's version was saved as $destination.new.")
      return ;;
    missing)
      fs_put 0644 "$source" "$destination" > /dev/null || exit 1
      NEW_MANIFEST+="$shipped  $key"$'\n'
      return ;;
  esac
  recorded="$(recorded_digest "$key")"
  if [[ "$current" == "$shipped" ]]; then
    NEW_MANIFEST+="$shipped  $key"$'\n'
  elif [[ -n "$recorded" && "$current" == "$recorded" ]] || { [[ -z "$recorded" ]] && previously_shipped "$key" "$current"; }; then
    place 0644 "$source" "$destination"
    NEW_MANIFEST+="$shipped  $key"$'\n'
    NOTES+=("Updated $destination to the version shipped with this release.")
  else
    fs_put 0644 "$source" "$destination.new" > /dev/null || exit 1
    NOTES+=("A newer $(basename "$destination") was saved as $destination.new; your existing file was left unchanged.")
  fi
}
sync_shipped example "$PKG/share/nivkode/gateway.example.json" "$CONFIG/gateway.example.json"
sync_shipped unit "$PKG/share/nivkode/nivkode-gateway.service" "$UNIT/nivkode-gateway.service"
printf '%s' "$NEW_MANIFEST" > "$TMP/install-manifest.sha256"
fs_put 0644 "$TMP/install-manifest.sha256" "$MANIFEST" > /dev/null || exit 1

if [[ "$UPGRADE" == 1 ]]; then
  if [[ -n "$PREVIOUS_RELEASE" && "$PREVIOUS_RELEASE" != "$THIS_RELEASE" ]]; then
    case "$ORDER" in
      older) printf 'Replaced NivKode Gateway %s with the older %s under %s (--allow-downgrade)\n' "$PREVIOUS_RELEASE" "$THIS_RELEASE" "$HOME" ;;
      newer) printf 'Replaced NivKode Gateway %s with the newer %s under %s\n' "$PREVIOUS_RELEASE" "$THIS_RELEASE" "$HOME" ;;
      same) printf 'Replaced NivKode Gateway %s with %s, another build of the same version, under %s\n' "$PREVIOUS_RELEASE" "$THIS_RELEASE" "$HOME" ;;
      *) printf 'Replaced NivKode Gateway %s with %s under %s (their versions could not be compared)\n' "$PREVIOUS_RELEASE" "$THIS_RELEASE" "$HOME" ;;
    esac
  elif [[ -n "$PREVIOUS_RELEASE" ]]; then
    printf 'Reinstalled NivKode Gateway %s under %s\n' "$THIS_RELEASE" "$HOME"
  else
    printf 'Replaced an earlier NivKode Gateway with %s under %s (the earlier install did not record its version)\n' "$THIS_RELEASE" "$HOME"
  fi
  printf 'Replaced: the nivkode, nivkode-gateway and nivkode-doctor programs, the Doctor script, the installer and the uninstaller.\n'
  KEPT_DATA=()
  [[ -e "$CONFIG/gateway.json" ]] && KEPT_DATA+=("your gateway config ($CONFIG/gateway.json)")
  [[ -e "$CONFIG/cli.json" ]] && KEPT_DATA+=("this computer's pairing ($CONFIG/cli.json)")
  [[ -e "$SHARE/nivkode.sqlite3" ]] && KEPT_DATA+=("your conversations ($SHARE)")
  for ((i = 0; i < ${#KEPT_DATA[@]}; i++)); do printf 'Not changed: %s\n' "${KEPT_DATA[$i]}"; done
  if [[ -e "$SHARE/nivkode.sqlite3" ]]; then
    printf 'The gateway brings the conversation database to its own version when it next starts. To be able to return exactly to the current state, copy %s before starting it.\n' "$SHARE"
  fi
else
  printf 'Installed NivKode Gateway %s under %s\n' "$THIS_RELEASE" "$HOME"
fi
printf 'Example config: %s/gateway.example.json (copy and edit as gateway.json)\n' "$CONFIG"
printf 'Unit template: %s/nivkode-gateway.service (not enabled)\n' "$UNIT"
printf 'Uninstaller: bash %s/uninstall.sh\n' "$SHARE"
printf 'To update later: bash %s/install.sh NEW-ARCHIVE.tar.gz (it checks the new archive against the release key this version trusts)\n' "$SHARE"
for ((i = 0; i < ${#NOTES[@]}; i++)); do printf '%s\n' "${NOTES[$i]}"; done
if [[ ${#RUNNING[@]} -gt 0 ]]; then
  printf 'A gateway is still running the previous version (process %s). Stop it (Ctrl-C in its terminal) and start it again to use this version.\n' "${RUNNING[*]}"
fi
case ":${PATH:-}:" in
  *":$BIN:"*) ;;
  *)
    printf '\nNote: %s is not on your PATH, so `nivkode` and `nivkode-gateway` will not be found yet.\n' "$BIN"
    # shellcheck disable=SC2016
    printf 'For this terminal run:  export PATH="$HOME/.local/bin:$PATH"\n'
    # shellcheck disable=SC2016
    printf 'To keep it in new terminals, add that line to ~/.profile (or ~/.bashrc / ~/.zshrc) and open a new terminal.\n'
    ;;
esac
[[ "$SIGNATURE_STATE" == signed ]] || insecure_banner
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -e "$CONFIG/gateway.json" ]]; then
  # shellcheck disable=SC2016
  printf 'Next: start the gateway with your existing config: nivkode-gateway serve "$HOME/.config/nivkode/gateway.json"\n'
elif [[ -f "$SELF/../../docs/install.md" ]]; then
  printf 'Next: configure and start the gateway (step 3 onward in %s).\n' "$(cd "$SELF/../../docs" && pwd)/install.md"
fi
