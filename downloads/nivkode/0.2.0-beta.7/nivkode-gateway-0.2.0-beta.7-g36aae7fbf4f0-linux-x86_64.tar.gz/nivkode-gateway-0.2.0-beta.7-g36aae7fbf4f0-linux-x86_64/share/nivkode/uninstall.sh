#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
# Copyright (C) 2026 Jake Evans
#
# Removes the programs and files the installer placed, each only at its exact place in the
# install's own folders. It never follows a symbolic link (a link, and anything behind a linked
# folder, is left in place and reported), keeps anything you edited, and by default never touches your
# configuration, device token or conversation data: it names where each one is kept.
#
#   uninstall.sh                 remove the programs; keep your settings, pairing and conversations
#   uninstall.sh --remove-data   also delete them, after listing exactly what goes and asking you to type "delete"
set -euo pipefail
REMOVE_DATA=0
for arg in "$@"; do
  case "$arg" in
    --remove-data) REMOVE_DATA=1 ;;
    *) echo "usage: uninstall.sh [--remove-data]" >&2; echo "unknown option: $arg (nothing was removed)" >&2; exit 2 ;;
  esac
done
[[ -n "${HOME:-}" && "$HOME" == /* ]] || { echo "HOME must be an absolute path" >&2; exit 1; }
HOME="${HOME%/}"; [[ -n "$HOME" ]] || { echo "HOME must not be /" >&2; exit 1; }

BIN="$HOME/.local/bin"
CONFIG="$HOME/.config/nivkode"
UNIT_DIR="$HOME/.config/systemd/user"
SHARE="$HOME/.local/share/nivkode"
UNIT="$UNIT_DIR/nivkode-gateway.service"
EXAMPLE="$CONFIG/gateway.example.json"
MANIFEST="$SHARE/install-manifest.sha256"
KEPT=()

# A gateway that is still running keeps serving from memory after its program is removed.
RUNNING=()
for exe in /proc/[0-9]*/exe; do
  target="$(readlink "$exe" 2>/dev/null || true)"
  case "$target" in
    "$BIN/nivkode-gateway" | "$BIN/nivkode-gateway (deleted)") RUNNING+=("$(basename "$(dirname "$exe")")") ;;
  esac
done

# What stays holds secrets: the CLI's device token, the gateway config (it may hold an admin token) and the
# gateway's state (paired-device records and conversations). Each is found the way the CLI and the gateway find
# it, so a pairing kept under XDG_CONFIG_HOME or a state_dir outside ~/.local/share is named too.
LEFT=()       # "what: path" lines for the user
LEFT_DIRS=()  # NivKode's own folders the user may delete; never a folder that merely holds a named config file
LEFT_FILES=() # config files outside NivKode's own folders, and NivKode's own files in a state_dir that is not
NOTES=()      # relative settings, resolved from this folder
STATE_DIRS=() # gateway state folders: a serving gateway holds a lock on each
add_dir() { local d; for d in ${LEFT_DIRS[@]+"${LEFT_DIRS[@]}"}; do [[ "$d" == "$1" ]] && return 0; done; LEFT_DIRS+=("$1"); }
seen_left() { local l; for l in ${LEFT[@]+"${LEFT[@]}"}; do [[ "$l" == *": $1" ]] && return 0; done; return 1; }
# The CLI and the gateway accept a relative XDG_CONFIG_HOME or NIVKODE_GATEWAY_CONFIG and read it from the folder
# they run in. Resolve it from this one, and say so: NivKode may have run somewhere else.
HERE="$(pwd)"
setting() { # setting NAME VALUE: VALUE as a full path, noting a relative one
  if [[ "$2" == /* ]]; then printf '%s' "$2"; else printf '%s' "${HERE%/}/$2"; fi
}
note_relative() { # note_relative NAME VALUE
  [[ "$2" == /* ]] || NOTES+=("$1=$2 is relative: NivKode reads it from the folder it runs in, so from here that is $(setting "$1" "$2"). If NivKode ran from another folder, look there too.")
}
XDG_BASE=""
if [[ -n "${XDG_CONFIG_HOME:-}" ]]; then
  XDG_BASE="$(setting XDG_CONFIG_HOME "$XDG_CONFIG_HOME")"; XDG_BASE="${XDG_BASE%/}"; note_relative XDG_CONFIG_HOME "$XDG_CONFIG_HOME"
fi
CLI_CONFIG="${XDG_BASE:-$HOME/.config}/nivkode/cli.json"
if [[ -e "$CLI_CONFIG" ]]; then LEFT+=("this computer's pairing token: $CLI_CONFIG"); add_dir "$(dirname -- "$CLI_CONFIG")"; fi
GATEWAY_CONFIGS=()
if [[ -n "${NIVKODE_GATEWAY_CONFIG:-}" ]]; then
  GATEWAY_CONFIGS+=("$(setting NIVKODE_GATEWAY_CONFIG "$NIVKODE_GATEWAY_CONFIG")"); note_relative NIVKODE_GATEWAY_CONFIG "$NIVKODE_GATEWAY_CONFIG"
fi
[[ -n "$XDG_BASE" ]] && GATEWAY_CONFIGS+=("$XDG_BASE/nivkode/gateway.json")
GATEWAY_CONFIGS+=("$CONFIG/gateway.json")
for gateway_config in "${GATEWAY_CONFIGS[@]}"; do
  [[ -f "$gateway_config" ]] && ! seen_left "$gateway_config" || continue
  LEFT+=("gateway config: $gateway_config")
  case "$gateway_config" in
    "$CONFIG/gateway.json" | "$XDG_BASE/nivkode/gateway.json") add_dir "$(dirname -- "$gateway_config")" ;;
    *) LEFT_FILES+=("$gateway_config") ;;
  esac
  state_dir="$(python3 -c 'import json,sys
try: value = json.load(open(sys.argv[1])).get("state_dir", "")
except Exception: value = ""
print(value if isinstance(value, str) and value.startswith("/") else "")' "$gateway_config" 2>/dev/null || true)"
  state_dir="${state_dir%/}"
  if [[ -n "$state_dir" && -e "$state_dir/nivkode.sqlite3" ]] && ! seen_left "$state_dir"; then
    LEFT+=("conversations and paired-device records: $state_dir"); STATE_DIRS+=("$state_dir")
    # The gateway needs state_dir absolute, not its own: it may be ~/Documents. Unless it is inside NivKode's own
    # folders (named whole below), name the gateway's files in it, never the folder.
    case "$state_dir/" in
      "$SHARE"/* | "$CONFIG"/*) ;;
      *) for state_file in nivkode.sqlite3 nivkode.sqlite3-wal nivkode.sqlite3-shm nivkode.sqlite3-journal gateway.lock; do
           [[ -e "$state_dir/$state_file" || -L "$state_dir/$state_file" ]] && LEFT_FILES+=("$state_dir/$state_file")
         done ;;
    esac
  fi
done
if [[ -e "$SHARE/nivkode.sqlite3" ]] && ! seen_left "$SHARE"; then LEFT+=("conversations and paired-device records: $SHARE"); STATE_DIRS+=("$SHARE"); fi
[[ -d "$SHARE" ]] && add_dir "$SHARE"
[[ -d "$CONFIG" ]] && add_dir "$CONFIG"
REMOVE=(${LEFT_DIRS[@]+"${LEFT_DIRS[@]}"} ${LEFT_FILES[@]+"${LEFT_FILES[@]}"})

# --remove-data: decide before anything changes. Nothing is stopped or removed unless the user confirms, and never
# while a gateway serves from one of the state folders (it holds a lock on each; deleting under it would lose or
# resurrect data). Workspaces are never on the list.
state_in_use() { # state_in_use DIR: a serving gateway holds an exclusive lock on its state folder (or gateway.lock)
  python3 - "$1" <<'PY'
import errno, fcntl, os, sys
for path in (sys.argv[1], os.path.join(sys.argv[1], "gateway.lock")):
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except OSError:
        continue
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError as error:
        if error.errno in (errno.EWOULDBLOCK, errno.EAGAIN):
            sys.exit(0)
    finally:
        os.close(fd)
sys.exit(1)
PY
}
if [[ "$REMOVE_DATA" == 1 && ${#REMOVE[@]} -gt 0 ]]; then
  BUSY=()
  for state_dir in ${STATE_DIRS[@]+"${STATE_DIRS[@]}"}; do if state_in_use "$state_dir"; then BUSY+=("$state_dir"); fi; done
  if [[ ${#RUNNING[@]} -gt 0 || ${#BUSY[@]} -gt 0 ]]; then
    {
      if [[ ${#RUNNING[@]} -gt 0 ]]; then echo "A NivKode gateway is running (process ${RUNNING[*]})."; fi
      if [[ ${#BUSY[@]} -gt 0 ]]; then echo "A NivKode gateway is using ${BUSY[*]}."; fi
      echo "Stop it first (Ctrl-C in its terminal, or: systemctl --user stop nivkode-gateway), then run this again. Nothing was removed."
    } >&2
    exit 1
  fi
  echo "uninstall.sh --remove-data removes the NivKode programs and also permanently deletes:"
  for target in "${REMOVE[@]}"; do
    if [[ -d "$target" && ! -L "$target" ]]; then echo "  $target (folder, with everything in it)"; else echo "  $target"; fi
  done
  echo "Among them:"
  for ((i = 0; i < ${#LEFT[@]}; i++)); do echo "  ${LEFT[$i]}"; done
  echo "Your workspace folders and any other files are not touched. This cannot be undone."
  printf 'Type delete and press Enter to delete them; anything else cancels: '
  answer=""
  IFS= read -r answer || true
  echo
  if [[ "$answer" != delete ]]; then
    echo "Cancelled: nothing was removed (programs, settings and conversations are as they were)." >&2
    exit 1
  fi
fi
# Deletes one confirmed data path without following a symbolic link anywhere on the way: the path must be absolute
# and already resolved (no linked component), a folder must be NivKode's own ("nivkode") and goes with the
# link-safe rmtree, and anything else must be a regular file. Exit status: 0 deleted, 3 refused, 4 already gone.
purge() { # purge PATH
  python3 - "$1" <<'PY'
import os, shutil, stat, sys
path = sys.argv[1]
if not os.path.isabs(path) or os.path.normpath(path) != path or path == "/":
    sys.exit(3)
try:
    info = os.lstat(path)
except FileNotFoundError:
    sys.exit(4)
if os.path.realpath(os.path.dirname(path)) != os.path.dirname(path) or stat.S_ISLNK(info.st_mode):
    sys.exit(3)
if stat.S_ISDIR(info.st_mode):
    if os.path.basename(path) != "nivkode" or not shutil.rmtree.avoids_symlink_attacks:
        sys.exit(3)
    shutil.rmtree(path)
elif stat.S_ISREG(info.st_mode):
    os.unlink(path)
else:
    sys.exit(3)
PY
}

# If the user enabled the service, stop and disable it first. This only acts when the running
# user manager loaded exactly the unit file in this HOME, so another unit of the same name
# (or a different HOME, such as a test home) is never touched.
SERVICE_STOPPED=0
if command -v systemctl >/dev/null 2>&1 && [[ -e "$UNIT" || -L "$UNIT" ]]; then
  fragment="$(systemctl --user show -p FragmentPath --value nivkode-gateway.service 2>/dev/null || true)"
  if [[ -n "$fragment" && "$(readlink -f -- "$fragment")" == "$(readlink -f -- "$UNIT")" ]]; then
    systemctl --user disable --now nivkode-gateway.service >/dev/null 2>&1 || true
    SERVICE_STOPPED=1
  fi
fi

# Everything removed must be a regular file at its exact place in the install's own folders. A path
# counts only if no component below $HOME is a symbolic link (the file itself included) and its real
# location is $HOME_REAL plus the same relative path. A symbolic link is never followed: the uninstaller
# does not create links, so it leaves any link in place, removes nothing behind it, and reports it.
# Matching bytes are not enough; a recorded file must also still be exactly what was installed.
HOME_REAL="$(cd -- "$HOME" 2>/dev/null && pwd -P)" || { echo "HOME does not exist: $HOME" >&2; exit 1; }
first_link() { # first_link PATH: prints the first symbolic link from $HOME down to PATH (PATH included)
  local rel="${1#"$HOME"/}" acc="$HOME" part parts
  IFS=/ read -r -a parts <<<"$rel"
  for part in "${parts[@]}"; do
    acc="$acc/$part"
    if [[ -L "$acc" ]]; then printf '%s\n' "$acc"; return 0; fi
  done
  return 1
}
own_regular_file() { # own_regular_file PATH: a regular file at its own place below $HOME, no link on the way
  local path="$1" real
  [[ "$path" == "$HOME"/* ]] || return 1
  if first_link "$path" >/dev/null; then return 1; fi
  [[ -f "$path" ]] || return 1
  real="$(realpath -e -- "$path" 2>/dev/null)" || return 1
  [[ "$real" == "$HOME_REAL/${path#"$HOME"/}" ]]
}
recorded() { if own_regular_file "$MANIFEST"; then awk -v k="$1" '$2 == k { print $1 }' "$MANIFEST"; fi; }
report_link() { # report_link PATH LINK
  if [[ "$2" == "$1" ]]; then
    KEPT+=("$1 (a symbolic link to $(readlink -- "$1"); the installer creates no links, so it was left in place)")
  else
    KEPT+=("$1 (inside $2, a symbolic link to $(readlink -- "$2"); links are never followed, so nothing behind it was removed)")
  fi
}
# The checks above give the reasons the user sees; fs_remove is what actually deletes, and it re-checks
# at that moment in a way a racing folder swap cannot redirect: it walks from $HOME opening each folder
# with O_NOFOLLOW relative to the one above it, opens the file itself with O_NOFOLLOW, requires a regular
# file (and the recorded digest, when one is given), and unlinks it within the folder it holds open.
# Exit status: 0 removed, 3 refused (a link, not a regular file, or changed), 4 already gone.
fs_remove() { # fs_remove PATH [SHA256] | fs_remove --empty-dir PATH | fs_remove --dangling-link PATH
  python3 - "$HOME" "$@" <<'PY'
import errno, hashlib, os, stat, sys
home, args = sys.argv[1].rstrip("/"), sys.argv[2:]
kind = "file"
if args[0] in ("--empty-dir", "--dangling-link"):
    kind, args = args[0][2:], args[1:]
path, want = args[0], (args[1] if len(args) > 1 else "")
if not path.startswith(home + "/"):
    sys.exit(3)
parts = path[len(home) + 1:].split("/")
if any(part in ("", ".", "..") for part in parts):
    sys.exit(3)
fd = os.open(home, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
try:
    for part in parts[:-1]:
        try:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
        except FileNotFoundError:
            sys.exit(4)
        except OSError as error:
            sys.exit(3 if error.errno in (errno.ELOOP, errno.ENOTDIR) else 1)
        os.close(fd); fd = child
    name = parts[-1]
    try:
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
    except FileNotFoundError:
        sys.exit(4)
    if kind == "empty-dir":
        if not stat.S_ISDIR(info.st_mode):
            sys.exit(3)
        try:
            os.rmdir(name, dir_fd=fd)
        except OSError:
            sys.exit(3)
        sys.exit(0)
    if kind == "dangling-link":
        if not stat.S_ISLNK(info.st_mode):
            sys.exit(3)
        try:
            os.stat(name, dir_fd=fd)  # follows the link: it must not lead anywhere
            sys.exit(3)
        except FileNotFoundError:
            os.unlink(name, dir_fd=fd)
            sys.exit(0)
    try:
        handle = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
    except OSError:
        sys.exit(3)
    try:
        opened = os.fstat(handle)
        if not stat.S_ISREG(opened.st_mode) or (opened.st_dev, opened.st_ino) != (info.st_dev, info.st_ino):
            sys.exit(3)
        if want:
            digest = hashlib.sha256()
            while True:
                chunk = os.read(handle, 1 << 20)
                if not chunk:
                    break
                digest.update(chunk)
            if digest.hexdigest() != want:
                sys.exit(3)
    finally:
        os.close(handle)
    os.unlink(name, dir_fd=fd)
finally:
    os.close(fd)
PY
}
remove_checked() { # remove_checked PATH [SHA256]: delete through fs_remove; a refusal is reported, never retried by path
  local rc=0
  fs_remove "$@" || rc=$?
  case "$rc" in
    0 | 4) ;;
    3) KEPT+=("$1 (it changed while the uninstaller was running, so it was left in place)") ;;
    *) KEPT+=("$1 (could not be removed)") ;;
  esac
}
remove_installed() { # remove_installed PATH KEY program|template
  local path="$1" key="$2" kind="$3" link want got
  [[ -e "$path" || -L "$path" ]] || return 0
  if link="$(first_link "$path")"; then report_link "$path" "$link"; return 0; fi
  if ! own_regular_file "$path"; then KEPT+=("$path (not a regular file in the install's own folders)"); return 0; fi
  want=""
  if [[ -n "$key" ]]; then want="$(recorded "$key")"; fi
  if [[ -n "$want" ]]; then
    got="$(sha256sum -- "$path" | awk '{print $1}')"
    if [[ "$want" == "$got" ]]; then remove_checked "$path" "$want"; else KEPT+=("$path (changed since it was installed)"); fi
  elif [[ "$kind" == program ]]; then
    remove_checked "$path" # installed before the manifest recorded programs; its place alone identifies it
  else
    KEPT+=("$path (edited, or not recorded by the installer)")
  fi
}

remove_installed "$BIN/nivkode-gateway" bin/nivkode-gateway program
remove_installed "$BIN/nivkode-doctor" bin/nivkode-doctor program
remove_installed "$BIN/nivkode" bin/nivkode program
remove_installed "$SHARE/tools/doctor" tools/doctor program
remove_installed "$SHARE/installed-release" installed-release program
if [[ -d "$SHARE/tools" ]] && ! first_link "$SHARE/tools" >/dev/null; then fs_remove --empty-dir "$SHARE/tools" || true; fi
remove_installed "$UNIT" unit template
remove_installed "$EXAMPLE" example template
remove_installed "$UNIT.new" "" program
remove_installed "$EXAMPLE.new" "" program
# A dangling "enable" link would make the service reappear in `systemctl --user` after the unit is gone.
# The link itself is removed (never followed), and only from a real folder of this HOME.
for link in "$UNIT_DIR"/*.wants/nivkode-gateway.service; do
  if [[ -L "$link" && ! -e "$link" ]]; then
    if parent_link="$(first_link "$(dirname -- "$link")")"; then report_link "$link" "$parent_link"; else fs_remove --dangling-link "$link" || true; fi
  fi
done
if [[ "$SERVICE_STOPPED" == 1 ]]; then systemctl --user daemon-reload >/dev/null 2>&1 || true; fi

# The kept installer and the installed copy of this script go too. Unlinking it is safe even when it is the one running now:
# the shell keeps reading from the open file. The manifest goes last, because the removals above use it.
remove_installed "$SHARE/install.sh" installer program
remove_installed "$SHARE/uninstall.sh" uninstall program
if own_regular_file "$MANIFEST"; then
  remove_checked "$MANIFEST"
elif [[ -e "$MANIFEST" || -L "$MANIFEST" ]]; then
  if link="$(first_link "$MANIFEST")"; then report_link "$MANIFEST" "$link"; else KEPT+=("$MANIFEST (not a regular file)"); fi
fi

DELETED=()
if [[ "$REMOVE_DATA" == 1 ]]; then
  for target in ${REMOVE[@]+"${REMOVE[@]}"}; do
    rc=0; purge "$target" || rc=$?
    case "$rc" in
      0) DELETED+=("$target") ;;
      4) ;;
      3) if first_link "$target" >/dev/null || [[ -L "$target" ]] || [[ "$(realpath -m -- "$target")" != "$target" ]]; then
           KEPT+=("$target (a symbolic link, or inside one; links are never followed, so it and what it leads to were not deleted)")
         else
           KEPT+=("$target (not deleted: it is not NivKode's own folder or a regular file)")
         fi ;;
      *) KEPT+=("$target (could not be deleted)") ;;
    esac
  done
fi

if [[ ${#KEPT[@]} -eq 0 ]]; then
  echo "Removed NivKode Gateway executables and user unit template."
else
  echo "Removed the NivKode Gateway files that were still as installed; those listed under Kept were left in place."
fi
if [[ "$REMOVE_DATA" == 1 ]]; then
  for ((i = 0; i < ${#DELETED[@]}; i++)); do echo "Deleted: ${DELETED[$i]}"; done
else
  echo "Configuration and gateway state were preserved."
fi
if [[ "$SERVICE_STOPPED" == 1 ]]; then echo "Stopped and disabled the nivkode-gateway user service."; fi
for ((i = 0; i < ${#KEPT[@]}; i++)); do echo "Kept: ${KEPT[$i]}"; done
if [[ ${#RUNNING[@]} -gt 0 ]]; then
  echo "A NivKode gateway is still running (process ${RUNNING[*]}). Stop it with Ctrl-C in its terminal or: kill ${RUNNING[*]}"
fi
for ((i = 0; i < ${#NOTES[@]}; i++)); do echo "${NOTES[$i]}"; done
if [[ "$REMOVE_DATA" == 1 ]]; then
  # Name exactly what is still there: a confirmed path that survived is also listed under Kept above.
  STILL=()
  for target in ${REMOVE[@]+"${REMOVE[@]}"}; do if [[ -e "$target" || -L "$target" ]]; then STILL+=("$target"); fi; done
  if [[ ${#STILL[@]} -eq 0 ]]; then
    echo "Everything listed above for deletion is gone."
  else
    echo "Still on this computer:"
    for ((i = 0; i < ${#STILL[@]}; i++)); do echo "  ${STILL[$i]}"; done
  fi
  exit 0
fi
if [[ ${#LEFT[@]} -gt 0 ]]; then
  echo "Still on this computer (kept on purpose; treat them as secrets):"
  for ((i = 0; i < ${#LEFT[@]}; i++)); do echo "  ${LEFT[$i]}"; done
fi
if [[ ${#REMOVE[@]} -gt 0 ]]; then
  list="${REMOVE[0]}"
  for ((i = 1; i < ${#REMOVE[@]}; i++)); do
    if ((i == ${#REMOVE[@]} - 1)); then list+=" and ${REMOVE[$i]}"; else list+=", ${REMOVE[$i]}"; fi
  done
  echo "To delete your settings and conversations as well, remove $list yourself, or run this uninstaller again with --remove-data."
fi
# Your downloaded package folder is yours to delete.
exit 0
